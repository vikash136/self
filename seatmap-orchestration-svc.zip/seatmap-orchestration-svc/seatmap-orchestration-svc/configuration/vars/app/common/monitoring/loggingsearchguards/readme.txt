LoggingSearchGuard objects could be use to restrict access to particular fields in Kibana.

To learn how to use it, read the documentatio: http://ngp.sabre.com/tech-docs/Logging/docs/restricting.log.access.html.

This file could be deleted.
