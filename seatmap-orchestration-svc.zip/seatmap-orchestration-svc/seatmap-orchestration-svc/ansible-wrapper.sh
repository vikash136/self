#!/bin/bash

cd .ansible-wrapper && ./ansible-wrapper.sh $*
