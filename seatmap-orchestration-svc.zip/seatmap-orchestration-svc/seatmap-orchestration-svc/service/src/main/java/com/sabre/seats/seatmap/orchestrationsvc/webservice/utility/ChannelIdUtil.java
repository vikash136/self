package com.sabre.seats.seatmap.orchestrationsvc.webservice.utility;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@ConfigurationProperties("requester")
@Component
public class ChannelIdUtil {
    private List<String> requesterIds;

    public List<String> getRequesterIds() {
        return requesterIds;
    }

    public void setRequesterIds(List<String> requesterIds) {
        this.requesterIds = requesterIds;
    }
}
