package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers;

import io.grpc.health.v1.HealthCheckRequest;
import io.grpc.health.v1.HealthCheckResponse;
import io.grpc.health.v1.HealthGrpc;
import io.grpc.stub.StreamObserver;
import org.lognet.springboot.grpc.GRpcService;

@GRpcService
public class MockHealthCheckService extends HealthGrpc.HealthImplBase {
    @Override
    public void check(HealthCheckRequest request,StreamObserver<HealthCheckResponse> responseObserver) {
            String serviceName = request.getService ();

            HealthCheckResponse.Builder healthCheckResponse = HealthCheckResponse.newBuilder ();
            if ( serviceName.equals ("orchestrationService") ) {
                healthCheckResponse.setStatus (HealthCheckResponse.ServingStatus.SERVING);
            } else {
                healthCheckResponse.setStatus (HealthCheckResponse.ServingStatus.NOT_SERVING);
            }

            responseObserver.onNext (healthCheckResponse.build ());
            responseObserver.onCompleted ();
        }
    }
