package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.common.protobuf.ResponseStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Slf4j
@Component
public class FlightItemService implements RequestProcessor {

    @Autowired
    @Qualifier("flightItemProcessors")
    List<FlightItemProcessor> flightItemProcessors;

    @Override
    public void processRequest(WebServiceRequestResponseContext requestResponseContext) {

        if(ResponseStatus.SUCCESS.equals(requestResponseContext.getTransformPosRequestToProtoStatus())
                && !CollectionUtils.isEmpty(requestResponseContext.getFlightItemReqResContextMap())) {

            List<CompletableFuture<Void>> futures=requestResponseContext.getFlightItemReqResContextMap().keySet()
                    .stream()
                    .map(segmentId -> CompletableFuture.runAsync(() ->
                            flightItemProcessors.forEach(flightItemProcessor -> {
                                try {
                                    flightItemProcessor.processFlightItem(requestResponseContext, segmentId);
                                } catch (ServiceTimeOutException e) {
                                    log.error(EscapeUtil.escape("ServiceTimeOutException while processing flight item"));
                                }
                            })))
                    .collect(Collectors.toList());

            CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()])).join();
        }
    }
}
