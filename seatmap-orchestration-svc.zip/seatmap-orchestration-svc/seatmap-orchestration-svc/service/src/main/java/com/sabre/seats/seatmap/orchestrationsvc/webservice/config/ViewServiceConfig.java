package com.sabre.seats.seatmap.orchestrationsvc.webservice.config;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
public class ViewServiceConfig {

    @Value("${viewService.url}")
    private String viewServiceUrl;

    @Value("${viewService.port}")
    private int viewServicePort;

    @Value("${grpcService.channel.keepAliveTime}")
    private int keepAliveTime;

    @Bean("viewServiceChannel")
    public ManagedChannel getViewServiceManagedChannel(){
        return ManagedChannelBuilder
                .forAddress(viewServiceUrl,viewServicePort)
                .keepAliveTime(keepAliveTime, TimeUnit.MILLISECONDS)
                .usePlaintext().build();
    }
}
