package com.sabre.seats.seatmap.orchestrationsvc.webservice.config;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
public class AuthorizationServiceConfig {

    @Value("${authorizationService.url}")
    private String authorizationServiceUrl;

    @Value("${authorizationService.port}")
    private int authorizationServicePort;

    @Value("${grpcService.channel.keepAliveTime}")
    private int keepAliveTime;

    @Bean("authorizationChannel")
    public ManagedChannel getAuthorizationChannel(){
        return ManagedChannelBuilder
                .forAddress(authorizationServiceUrl, authorizationServicePort)
                .keepAliveTime(keepAliveTime, TimeUnit.MILLISECONDS)
                .usePlaintext().build();
    }

}
