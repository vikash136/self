package com.sabre.seats.seatmap.orchestrationsvc.webservice.model;

public enum ServiceTimeoutEnum {

    CONNECTIVITY,
    AUTHORIZATION,
    AUTH_TRANSFORMATION,
    CONN_TRANSFORMATION
}
