package com.sabre.seats.seatmap.orchestrationsvc.webservice.exception;

public class CoreServiceTimeOutException extends Exception{

    public CoreServiceTimeOutException(String message){super(message);}
}
