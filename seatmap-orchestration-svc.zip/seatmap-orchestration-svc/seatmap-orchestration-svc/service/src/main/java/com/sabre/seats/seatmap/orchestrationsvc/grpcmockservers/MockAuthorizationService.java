package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers;

import com.sabre.seats.authorization.protobuf.AuthorizationRequest;
import com.sabre.seats.authorization.protobuf.AuthorizationResponse;
import com.sabre.seats.authorization.protobuf.AuthorizationServiceGrpc;

import com.sabre.seats.common.protobuf.ResponseInfo;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.common.protobuf.Supplier;
import com.sabre.seats.error.protobuf.Description;
import com.sabre.seats.error.protobuf.ErrorMessage;

import com.sabre.seats.error.protobuf.MessageCode;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;
import org.lognet.springboot.grpc.GRpcService;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@GRpcService
public class MockAuthorizationService extends AuthorizationServiceGrpc.AuthorizationServiceImplBase {

    @Override
    public void authorizeRequest(AuthorizationRequest authorizationRequest, StreamObserver<AuthorizationResponse> responseObserver) {

        try{
            if(authorizationRequest.getSegmentInfo().getFlightInfo().getAirlineCode().equals("AA")){

                List<MessageCode> messageCodeList = new ArrayList<>();
                MessageCode messageCode =  MessageCode.newBuilder()
                        .setCode("CONN-2001")
                        .setCodeContext("IATAErrorCode").build();
                messageCodeList.add(messageCode);

                ErrorMessage errorMessage = ErrorMessage.newBuilder()
                        .setCategory("INTERNAL_SERVER_ERROR")
                        .setType("BUSINESS")
                        .setDescription(Description.newBuilder()
                                .setLang("UTF-11111")
                                .setMessage("Not Authorised to view seat map")
                                .build())
                        .addAllErrorCode(messageCodeList)
                        .build();

                ResponseInfo responseInfoFailure=ResponseInfo.newBuilder()
                        .setResponseStatus(ResponseStatus.FAILED)
                        .setReceivedTimestamp(authorizationRequest.getRequestInfo().getTimestamp())
                        .setResponseTimestamp(Instant.now().toString())
                        .addErrorMessages(errorMessage)
                        .build();

                responseObserver.onNext(AuthorizationResponse.newBuilder()
                        .setRequestInfo(authorizationRequest.getRequestInfo())
                        .setResponseInfo(responseInfoFailure)
                        .build());

            } else {

                Supplier mapSupplier = Supplier.newBuilder()
                        .setAirlineCode(authorizationRequest.getSegmentInfo().getFlightInfo().getAirlineCode())
                        .setFlightNumber(authorizationRequest.getSegmentInfo().getFlightInfo().getFlightNumber())
                        .setDepartureDate(authorizationRequest.getSegmentInfo().getFlightInfo().getScheduledDepartureDate())
                        .setDepartureAirportCode(authorizationRequest.getSegmentInfo().getFlightInfo().getDepartureAirportCode())
                        .setArrivalAirportCode(authorizationRequest.getSegmentInfo().getFlightInfo().getArrivalAirportCode())
                        .build();

                ResponseInfo responseInfoSuccess=ResponseInfo.newBuilder()
                        .setResponseStatus(authorizationRequest.getSegmentInfo().getFlightInfo().getAirlineCode().equals("MN")?ResponseStatus.NOT_OFFLOADED : ResponseStatus.SUCCESS)
                        .setReceivedTimestamp(authorizationRequest.getRequestInfo().getTimestamp())
                        .setResponseTimestamp(Instant.now().toString())
                        .build();

                responseObserver.onNext(AuthorizationResponse.newBuilder()
                        .setRequestInfo(authorizationRequest.getRequestInfo())
                        .setResponseInfo(responseInfoSuccess)
                        .setSupplier(mapSupplier)
                        .build());
            }

            responseObserver.onCompleted();

        } catch (Exception e) {
            responseObserver.onError(Status.UNKNOWN.asRuntimeException());
        }
    }

}
