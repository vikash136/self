package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.scheduler;

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.client.ServiceClient;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.service.ESSMService;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.utility.OptionalHealthCheckUtil;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.utility.StaticHealthCheckUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class HealthCheckScheduler {

    private static final String ESSM_SERVICE = "essmService";

    @Value ("${schedule.healthcheckscheduler.completablefuture.timeout}")
    private Integer connectionTimeout;

    @Value ("${schedule.healthcheckscheduler.completablefuture.pool-size}")
    private Integer poolSize;

    @Autowired
    private StaticHealthCheckUtil staticHealthCheckMap;

    @Autowired
    private OptionalHealthCheckUtil optionalHealthCheckMap;

    @Autowired
    private ServiceClient serviceClient;

    @Autowired
    private ServiceHealthCheckStore serviceHealthCheckStore;

    @Autowired
    private ESSMService essmService;

    public void checkAllServicesHealth() {

        try {

            log.info(EscapeUtil.escape("HealthCheckScheduler: checkAllServicesHealthScheduler Started"));
            List<CompletableFuture<String>> completableFutures = new ArrayList<> ();
            ExecutorService executorService = Executors.newFixedThreadPool (poolSize);

            Map<String, String> staticServicesStatusMap = new HashMap<> ();
            Map<String, String> dynamicServicesStatusMap = new HashMap<> ();
            Map<String, String> optionalServicesStatusMap = new HashMap<> ();

            for (Map.Entry<String, String> map : staticHealthCheckMap.getStaticHealthCheckMap ().entrySet ()) {
                CompletableFuture<String> future = CompletableFuture.supplyAsync (() -> serviceClient.getServiceStatus (map.getKey (),staticServicesStatusMap),executorService).orTimeout (connectionTimeout,TimeUnit.SECONDS);
                completableFutures.add (future);
            }

            for (Map.Entry<String, String> map : optionalHealthCheckMap.getOptionalHealthCheckMap ().entrySet ()) {
                CompletableFuture<String> future = CompletableFuture.supplyAsync (() -> serviceClient.getServiceStatus(map.getKey (),optionalServicesStatusMap),executorService).orTimeout (connectionTimeout,TimeUnit.SECONDS);
                completableFutures.add (future);
            }

            if(serviceHealthCheckStore.getDynamicHealthCheckMap ().containsKey (ESSM_SERVICE)) {
                CompletableFuture<String> future = CompletableFuture.supplyAsync (() -> essmService.getEssmStatus (dynamicServicesStatusMap),executorService).orTimeout (connectionTimeout,TimeUnit.SECONDS);
                completableFutures.add (future);
            }

            CompletableFuture.allOf (completableFutures.toArray (new CompletableFuture[completableFutures.size ()])).join ();

            serviceHealthCheckStore.updateStaticServiceHealthStatus (staticServicesStatusMap);
            serviceHealthCheckStore.updateDynamicServiceHealthStatus (dynamicServicesStatusMap);
            serviceHealthCheckStore.updateOptionalServiceHealthStatus (optionalServicesStatusMap);

        } catch (Exception ex) {
            log.error(EscapeUtil.escape("HealthCheckScheduler: Exception Occurred :" + ex.getMessage ()));
        }
    }

}
