package com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.JsonSEATMAPRESPONSEV1;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AirSeatMapResponse {

    private JsonSEATMAPRESPONSEV1 seatmapResponse;


}
