package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store;

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.*;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@Slf4j
public class ServiceHealthCheckStore {

    private static ServiceHealthStatus serviceHealthStatus = new ServiceHealthStatus ();

    private static OptionalServiceHealthStatus optionalServiceHealthStatus = new OptionalServiceHealthStatus ();

    private static Map<String, AtomicInteger> retryCountMap = new ConcurrentHashMap<>();

    private static Map<String,String> dynamicHealthCheckMap = new HashMap<> ();

    private static Map<String,String> optionalHealthCheckMap = new HashMap<> ();

    public Map<String,String> getDynamicHealthCheckMap() {
        return dynamicHealthCheckMap;
    }

    public Map<String,String> getOptionalHealthCheckMap() {
        return optionalHealthCheckMap;
    }

    public String getOverallHealthStatus() {
        return serviceHealthStatus.getStatus () !=null ? serviceHealthStatus.getStatus ().getStatus (): null;
    }

    public ServiceHealthStatus getHealthStatusForAllServices() {
        return serviceHealthStatus;
    }

    public OptionalServiceHealthStatus getHealthStatusForOptionalServices() {
        return optionalServiceHealthStatus;
    }

    public AtomicInteger getRetryCount(String serviceName) {
        return retryCountMap.get (serviceName) != null ? retryCountMap.get (serviceName) : new AtomicInteger(0);
    }

    public void updateStaticServiceHealthStatus(Map<String, String> map) {
        log.info(EscapeUtil.escape("inside updateStaticServiceHealthStatus method" ));

        log.debug(EscapeUtil.escape("Static Service Server Response Map :: {}" + map));

        serviceHealthStatus.setComponent (new HashMap<> ());
        for(Map.Entry<String, String> serviceMap: map.entrySet ()) {
            serviceHealthStatus.getComponent ().put (serviceMap.getKey (), getServiceInfo (serviceMap.getKey (), serviceMap.getValue ()));
        }
        serviceHealthStatus.setStatus (getStatus(map));
    }

    public void updateOptionalServiceHealthStatus(Map<String, String> map) {
        log.info(EscapeUtil.escape("inside updateOptionalServiceHealthStatus method" ));

        log.debug(EscapeUtil.escape("Optional Service Server Response Map :: {}" + map));
        optionalServiceHealthStatus.setComponent (new HashMap<> ());
        for(Map.Entry<String, String> serviceMap: map.entrySet ()) {
            optionalServiceHealthStatus.getComponent ().put (serviceMap.getKey (), getServiceInfo (serviceMap.getKey (), serviceMap.getValue ()));
        }
        optionalServiceHealthStatus.setStatus (getStatus(map));
    }

    public void updateDynamicServiceHealthStatus(Map<String, String> map) {

        log.info(EscapeUtil.escape("inside updateDynamicServiceHealthStatus method" ));

        log.debug(EscapeUtil.escape("Dynamic Service Server Response Map :: {}" + map));
        for(Map.Entry<String, String> serviceMap: map.entrySet ()) {
            if(serviceMap.getValue ().equals (ServerResponse.SERVING.getServerResponse ())) {
                map.remove (serviceMap.getKey ());
                setRetryCount (serviceMap.getKey (), new AtomicInteger(0));
            } else {
                serviceHealthStatus.getComponent ().put (serviceMap.getKey (), getServiceInfo (serviceMap.getKey (), serviceMap.getValue ()));
                serviceHealthStatus.setStatus (ServiceStatus.DOWN);
            }
        }

    }

    private ServiceInfo getServiceInfo(String name, String status) {
        ServiceInfo serviceInfo = new ServiceInfo ();
        serviceInfo.setName (name);
        serviceInfo.setStatus (status.equals (ServerResponse.SERVING.getServerResponse ()) ? ServiceStatus.UP : ServiceStatus.DOWN);
        serviceInfo.setUpdateTimestamp (System.currentTimeMillis ());
        return serviceInfo;
    }

    private ServiceStatus getStatus(Map<String, String> serviceHealthStatusMap) {
        for(Map.Entry<String, String> map: serviceHealthStatusMap.entrySet ()) {
            if(!map.getValue ().equals (ServerResponse.SERVING.getServerResponse ())) {
                return ServiceStatus.DOWN;
            }
        }
        return ServiceStatus.UP;
    }

    public void setServiceComponentDown(String serviceName, String status) {
        serviceHealthStatus.getComponent ().put (serviceName, getServiceInfo (serviceName, status));
        serviceHealthStatus.setStatus (ServiceStatus.DOWN);
        retryCountMap.put (serviceName, new AtomicInteger(0));
    }

    public void setRetryCount(String serviceName, AtomicInteger retryCount) {
        retryCountMap.put (serviceName, retryCount);
    }

}
