package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.util.JsonFormat;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.*;
import com.sabre.seats.common.protobuf.Cabin;
import com.sabre.seats.common.protobuf.FlightInfo;
import com.sabre.seats.common.protobuf.OxygenMask;
import com.sabre.seats.common.protobuf.Seat;
import com.sabre.seats.common.protobuf.SeatRow;
import com.sabre.seats.common.protobuf.Seatmap;
import com.sabre.seats.common.protobuf.*;
import com.sabre.seats.transformation.protobuf.*;
import io.grpc.stub.StreamObserver;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;
import org.lognet.springboot.grpc.GRpcService;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@GRpcService
public class MockTransformationService extends TransformServiceGrpc.TransformServiceImplBase {

    private static final Gson gson = new Gson();

    @SneakyThrows
    @Override
    public void transform(TransformRequest transformRequest, StreamObserver<TransformReqResponse> responseObserver) {
        TransformReqResponse transformResponse = null;


        if (MessageType.SEAT_MAP_REQUEST.equals(transformRequest.getRequest().getInputMessageInfo().getMsgType())) {
            transformResponse = getSeatMapRequest(transformRequest);
        }
        else if (MessageType.SEGMENT_INFO.equals(transformRequest.getRequest().getInputMessageInfo().getMsgType())){
            transformResponse = getTransformerConnectivityToSupplier(transformRequest);
        }
        else if (MessageType.SEAT_MAP_CORE_RESPONSE.equals(transformRequest.getRequest().getInputMessageInfo().getMsgType())
                || MessageType.SMPRES.equals(transformRequest.getRequest().getInputMessageInfo().getMsgType())){
            transformResponse = getTransformerSupplierToViewSource(transformRequest);
        }
        else if (MessageType.SEAT_MAP_RESPONSE.equals(transformRequest.getRequest().getInputMessageInfo().getMsgType())){
            transformResponse = getTransformerResponseToPOSService(transformRequest);
        }


        if (transformResponse != null) {
            responseObserver.onNext(TransformReqResponse.newBuilder()
                    .setSeatMapOutputReqResponse(transformResponse.getSeatMapOutputReqResponse())
                    .build());
        }

        responseObserver.onCompleted();

    }


    public TransformReqResponse getSeatMapRequest(TransformRequest transformRequest) {

        FlightInfo flightInfo = FlightInfo.newBuilder().build();
        String requestPayload = transformRequest.getRequest().getInputRequest().getRequest();
        JSONObject requestJson = null;
        try {
            requestJson = jsonParse(requestPayload);
        } catch (ParseException e) {
            log.error(EscapeUtil.escape("Exception in getSeatMapRequest while parsing json: "+e));
        }
        assert requestJson != null;
        List<JSONObject> flightInfoJsonList = (List<JSONObject>)requestJson.get("flightInfo");
        for (JSONObject jsonObject : flightInfoJsonList) {
            flightInfo = FlightInfo.newBuilder()
                    .setAirlineCode(String.valueOf(jsonObject.get("airlineCode")))
                    .setDepartureAirportCode(String.valueOf(jsonObject.get("departureAirportCode")))
                    .setArrivalAirportCode(String.valueOf(jsonObject.get("arrivalAirportCode")))
                    .setFlightNumber(String.valueOf(jsonObject.get("flightNumber")))
                    .setScheduledDepartureDate(String.valueOf(jsonObject.get("scheduledDepartureDate")))
                    .build();

        }

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId(transformRequest.getRequest().getRequestInfo().getCorrelationId())
                .setTransactionId(transformRequest.getRequest().getRequestInfo().getTransactionId())
                .setTimestamp(Instant.now().toString())
                .setVersion(transformRequest.getRequest().getRequestInfo().getVersion()).build();

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build();
        SeatmapRequest seatmapRequest=SeatmapRequest.newBuilder()
                .addPaxSegmentInfo(PaxSegmentInfo.newBuilder().setSegmentInfo(segmentInfo).build())
                .setRequestInfo(requestInfo)
                .build();
        InputRequest outputResponse = InputRequest.newBuilder()
                .setSeatMapRequest(seatmapRequest)
                .build();
        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setOutputResponse(outputResponse)
                .build();
        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build();

    }


    private ResponseInfo getSuccessResponse() {
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.SUCCESS)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .build();
    }


    private ResponseInfo getFailureResponse() {
        com.sabre.seats.error.protobuf.ErrorMessage errorMessage = com.sabre.seats.error.protobuf.ErrorMessage.newBuilder()
                .setCategory("INTERNAL_SERVER_ERROR")
                .setType("APPLICATION")
                .setDescription(com.sabre.seats.error.protobuf.Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("Invalid Seatmap")
                        .build())
                .build();

        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .addErrorMessages(errorMessage)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .build();
    }

    SegmentInfo segmentInfo= null;

    public TransformReqResponse getTransformerConnectivityToSupplier(TransformRequest transformRequest) {
        log.info(EscapeUtil.escape("inside getTransformerConnectivityToSupplier method"));

        RequestInfo requestInfo = transformRequest.getRequest().getRequestInfo();
        segmentInfo= transformRequest.getRequest().getInputRequest().getInputRequest().getSegmentInfo();
        String response = null;
        String payload = "SMPREQ:AIRAALSMPREQ0001...TVL000.D...01Y5.290521...0086."+segmentInfo.getFlightInfo().getDepartureAirportCode() +"...0086."+segmentInfo.getFlightInfo().getArrivalAirportCode() +"...008O."+segmentInfo.getFlightInfo().getAirlineCode() +"...008U."+segmentInfo.getFlightInfo().getFlightNumber()+"...008V.Y...SRP001.D...005A.N";

        if (transformRequest.getRequest().getDesiredMessageInfo().getMsgType().equals(MessageType.SMPREQ)){
            response = payload;
        }else {
            response = "{\"correlationId\"" + ":\"" + requestInfo.getCorrelationId() + "\",\"flightInfo\"" + ":{\"airlineCode\"" + ":\"" + segmentInfo.getFlightInfo().getAirlineCode() + "\",\"arrivalAirportCode\"" + ":\"" + segmentInfo.getFlightInfo().getArrivalAirportCode() + "\",\"departureAirportCode\"" + ":\"" + segmentInfo.getFlightInfo().getDepartureAirportCode() + "\",\"scheduleDepartureDate\"" + ":\"" + segmentInfo.getFlightInfo().getScheduledDepartureDate() + "\",\"flightNumber\"" + ":\"" + segmentInfo.getFlightInfo().getFlightNumber() + "\",\"ownerAirlineCode\": \"EY\"},\"requestDateTime\"" + ":\"" + requestInfo.getTimestamp() + "\",\"reservationBookingDesignator\": \"Y\",\"responseOptions\": [" + "\"ALL\"],\"transactionId\"" + ":\"" + requestInfo.getTransactionId() + "\",\"version\"" + ":\"" + requestInfo.getVersion() + "\" }";
        }
        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setTransformReqResponse(response)
                .build();
        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build();
    }

    public TransformReqResponse getTransformerSupplierToViewSource(TransformRequest transformRequest) {
        log.info(EscapeUtil.escape("inside getTransformerSupplierToViewSource method"));

        String requestString = transformRequest.getRequest().getInputRequest().getRequest();
        if (transformRequest.getRequest().getInputMessageInfo().getMsgType().equals(MessageType.SMPRES)) {
                RequestInfo requestInfo = transformRequest.getRequest().getRequestInfo();
                requestString = "{\"version\":\"<VERSION>\",\"transactionId\":\"<TRANSACTION_ID>\",\"correlationId\":\"<CORRELATION_ID>\",\"requestDateTime\":\"<REQUEST_DATETIME>\",\"responseDateTime\":\"<RESPONSE_DATETIME>\",\"status\":200,\"warningMessages\":[],\"flightInfo\":{\"airlineCode\":\"<AIRLINE_CODE>\",\"flightNumber\":\"<FLIGHT_NUMBER>\",\"reservationBookingDesignator\":\"Y\",\"scheduleDepartureDate\":\"<DEPARTURE_DATE>\",\"departureAirportCode\":\"<DEPARTURE_AIRPORT_CODE>\",\"arrivalAirportCode\":\"<ARRIVAL_AIRPORT_CODE>\"},\"seatmaps\":[{\"departureAirportCode\":\"<DEPARTURE_AIRPORT_CODE>\",\"arrivalAirportCode\":\"<ARRIVAL_AIRPORT_CODE>\",\"iataConfigurationCode\":\"<FLIGHT_NUMBER>\",\"physicalAircraftName\":\"TEST\",\"physicalAircraftDescription\":\"TESTED\",\"cabinJumpSeatCount\":\"5\",\"cockpitJumpSeatCount\":\"2\",\"isAnimalAllowed\":true,\"isSmoking\":false,\"scheduleDepartureDateTime\":\"<DEPARTURE_DATE>\",\"scheduleArrivalDateTime\":\"<ARRIVAL_DATE>\",\"cabins\":[{\"seatRows\":[{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"}],\"rowNumber\":\"8\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"9\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"10\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"11\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"12\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"13\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"14\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"W\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window-BulkHead  \",\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"LS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"K\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisel-BulkHead\",\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"K\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisel-BulkHead\",\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"RS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"W\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window-BulkHead  \",\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"15\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"16\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"17\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"18\",\"rowCharacteristics\":[]}],\"cabinLayout\":{\"cabinCode\":\"Y\",\"cabinNumber\":\"2\",\"facilities\":[],\"firstRow\":\"8\",\"cabinCodeDescription\":\"ECONOMY\",\"lastRow\":\"18\",\"seatCount\":61,\"missingRowNumbers\":[],\"seatAlphabetList\":[{\"columnCode\":\"A\",\"position\":\"W\"},{\"columnCode\":\"B\",\"position\":\"9\"},{\"columnCode\":\"C\",\"position\":\"A\"},{\"columnCode\":\"D\",\"position\":\"A\"},{\"columnCode\":\"E\",\"position\":\"9\"},{\"columnCode\":\"F\",\"position\":\"W\"}],\"missingSeatList\":[]}}]}]}";
                requestString = getSeatMap(requestString, requestInfo, segmentInfo);

        }
        FlightInfo flightInfo;
        JSONObject requestJson = null;
        try {
            requestJson = jsonParse(requestString);
        } catch (ParseException e) {
            log.error(EscapeUtil.escape("Exception in transformation supplier to view source: "+e));
        }


        if (null==requestJson){
            SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                    .setResponseInfo(getFailureResponse())
                    .build();
            return TransformReqResponse.newBuilder()
                    .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                    .build();
        }
        JSONObject jsonFlightInfo = (JSONObject) requestJson.get("flightInfo");
        Object array =  requestJson.get("seatmaps");
        JSONArray jsonArray = (JSONArray)array;
        List<Seatmap> seatmapList = new ArrayList<>();
        flightInfo = FlightInfo.newBuilder()
                .setAirlineCode(String.valueOf(jsonFlightInfo.get("airlineCode")))
                .setDepartureAirportCode(String.valueOf(jsonFlightInfo.get("departureAirportCode")))
                .setArrivalAirportCode(String.valueOf(jsonFlightInfo.get("arrivalAirportCode")))
                .setFlightNumber(String.valueOf(jsonFlightInfo.get("flightNumber")))
                .setScheduledDepartureDate(String.valueOf(jsonFlightInfo.get("scheduleDepartureDate")))
                .build();

        for(Object jsonObject:jsonArray){
            Seatmap.Builder seatmapBuilder=Seatmap.newBuilder();
            try {
                JsonFormat.parser().ignoringUnknownFields().merge(String.valueOf(jsonObject),seatmapBuilder);
            } catch (InvalidProtocolBufferException e) {
                log.error(EscapeUtil.escape("Exception in transformation supplier to view source: "+e));
            }
            Seatmap seatmap = seatmapBuilder.build();
            seatmapList.add(seatmap);
        }

        FlightSeatMap flightSeatMap = FlightSeatMap.newBuilder()
                .addAllSeatmap(seatmapList)
                .build();

        SegmentInfo segmentInfo = SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build();
        SegmentResponse segmentResponse = SegmentResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setSegmentInfo(segmentInfo)
                .setFlightSeatmap(flightSeatMap)
                .build();


        InputRequest outputResponse = InputRequest.newBuilder()
                .setSegmentResponse(segmentResponse)
                .build();
        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setOutputResponse(outputResponse)
                .build();
        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build();
    }

    public TransformReqResponse getTransformerResponseToPOSService(TransformRequest transformRequest) {
        log.info(EscapeUtil.escape("inside getTransformerResponseToPOSService method"));
        String seatmapResponse = null;

        JsonSEATMAPRESPONSEV1 jsonSEATMAPRESPONSEV1 = getSeatmapResponse(transformRequest);

        ObjectMapper objectMapper = new ObjectMapper();
        try {
            seatmapResponse = objectMapper.writeValueAsString(jsonSEATMAPRESPONSEV1);
        } catch (JsonProcessingException e) {
            log.error(EscapeUtil.escape("Exception while Transforming Response to POS service: "+e));
        }


        SeatMapOutputReqResponse seatMapOutputReqResponse = null;
        if (seatmapResponse != null) {
            seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                    .setResponseInfo(getSuccessResponse())
                    .setTransformReqResponse(seatmapResponse)
                    .build();
        }
        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build();
    }

    public JSONObject jsonParse( String requestPayload ) throws ParseException {
        JSONParser parser = new JSONParser(1984);
        return (JSONObject) parser.parse(requestPayload);
    }

    public JsonSEATMAPRESPONSEV1 getSeatmapResponse(TransformRequest transformRequest) {
        JsonSEATMAPRESPONSEV1 jsonGetSeatMapResPosV1 = new JsonSEATMAPRESPONSEV1();
        RequestInfo requestInfo = transformRequest.getRequest().getRequestInfo();
        SeatmapResponse seatmapResponse = transformRequest.getRequest().getInputRequest().getInputRequest().getSeatMapResponse();
        ResponseInfo responseInfo = seatmapResponse.getResponseInfo();

        if (!seatmapResponse.getSegmentResponseList().isEmpty()){
            List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightSeatmap> flightSeatMapList = seatmapResponse.getSegmentResponseList()
                    .stream()
                    .map(this::getFlightSeatMap)
                    .collect(Collectors.toList());
            jsonGetSeatMapResPosV1.setFlightSeatmaps(flightSeatMapList);
        }else{
            List<ErrorMessage> sabreErrorMessageList = new ArrayList<>();

            List<com.sabre.seats.error.protobuf.ErrorMessage> protoErrorMessagesList = responseInfo.getErrorMessagesList();
            ErrorMessage errorMessage = new ErrorMessage();
            for(com.sabre.seats.error.protobuf.ErrorMessage protoErrorMessages:protoErrorMessagesList) {
                errorMessage.setCategory(protoErrorMessages.getCategory());
                errorMessage.setType(protoErrorMessages.getType());
                List<MessageCode> messageCodeList = new ArrayList<>();
                for(com.sabre.seats.error.protobuf.MessageCode messageCode: protoErrorMessages.getErrorCodeList()){
                    MessageCode messageCodev1 = new MessageCode();
                    messageCodev1.setCode(messageCode.getCode());
                    messageCodev1.setMessageContext(messageCode.getCodeContext());
                    messageCodeList.add(messageCodev1);
                }
                errorMessage.setMessageCode(messageCodeList);
                if(protoErrorMessages.getDescription()!=null){
                    Description description = new Description();
                    description.setLang(protoErrorMessages.getDescription().getLang());
                    description.setMessage(protoErrorMessages.getDescription().getMessage());
                    errorMessage.setDescription(description);
                }
                sabreErrorMessageList.add(errorMessage);
            }

            jsonGetSeatMapResPosV1.setErrorMessages(sabreErrorMessageList);

        }

        jsonGetSeatMapResPosV1.setStatus(responseInfo.getResponseStatus().getNumber());
        jsonGetSeatMapResPosV1.setTransactionId(requestInfo.getTransactionId());
        jsonGetSeatMapResPosV1.setCorrelationId(requestInfo.getCorrelationId());
        jsonGetSeatMapResPosV1.setRequestDateTime(requestInfo.getTimestamp());
        jsonGetSeatMapResPosV1.setVersion(requestInfo.getVersion());

        return jsonGetSeatMapResPosV1;
    }

    private com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightSeatmap getFlightSeatMap(SegmentResponse segmentResponse) {
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightSeatmap flightSeatMap=new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightSeatmap();
        FlightInfo segmentResponseFlightInfo = segmentResponse.getSegmentInfo().getFlightInfo();
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightInfo flightInfo=new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightInfo();
        flightInfo.setAirlineCode(segmentResponseFlightInfo.getAirlineCode());
        flightInfo.setFlightNumber(segmentResponseFlightInfo.getFlightNumber());
        flightInfo.setScheduleDepartureDate(segmentResponseFlightInfo.getScheduledDepartureDate());
        flightInfo.setDepartureAirportCode(segmentResponseFlightInfo.getDepartureAirportCode());
        flightInfo.setArrivalAirportCode(segmentResponseFlightInfo.getArrivalAirportCode());
        flightSeatMap.setFlightInfo(flightInfo);

        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Seatmap> seatmapList =segmentResponse.getFlightSeatmap().getSeatmapList()
                .stream()
                .map(this::getSeatMap)
                .collect(Collectors.toList());

        flightSeatMap.setSeatmaps(seatmapList);

        List<WarningMessage_> warnMessageList = new ArrayList<>();
        WarningMessage_ warningMessage = new WarningMessage_();
        List<com.sabre.seats.error.protobuf.WarningMessage> warningMessageList = segmentResponse.getResponseInfo().getWarningMessagesList();
        for (com.sabre.seats.error.protobuf.WarningMessage protoWarningMessage:warningMessageList){
            warningMessage.setCategory(protoWarningMessage.getCategory());
            warningMessage.setType(protoWarningMessage.getType());
            if(protoWarningMessage.getDescription()!=null){
                Description_ description = new Description_();
                description.setLang(protoWarningMessage.getDescription().getLang());
                description.setMessage(protoWarningMessage.getDescription().getMessage());
                warningMessage.setDescription(description);
            }
            List<MessageCode> messageCodeList = new ArrayList<>();
            for(com.sabre.seats.error.protobuf.MessageCode messageCode: protoWarningMessage.getWarningCodeList()){
                MessageCode messageCodev1 = new MessageCode();
                messageCodev1.setCode(messageCode.getCode());
                messageCodev1.setMessageContext(messageCode.getCodeContext());
                messageCodeList.add(messageCodev1);
            }
            warningMessage.setMessageCode(messageCodeList);
            warnMessageList.add(warningMessage);
        }

        List<ErrorMessage_> errorMessageList = new ArrayList<>();
        ErrorMessage_ errorMessage = new ErrorMessage_();
        List<com.sabre.seats.error.protobuf.ErrorMessage> protoErrorMessageLIst = segmentResponse.getResponseInfo().getErrorMessagesList();
        for (com.sabre.seats.error.protobuf.ErrorMessage protoErrorMessage:protoErrorMessageLIst){
            errorMessage.setCategory(protoErrorMessage.getCategory());
            errorMessage.setType(protoErrorMessage.getType());
            List<MessageCode> messageCodeList = new ArrayList<>();
            MessageCode messageCode = new MessageCode();
            for (com.sabre.seats.error.protobuf.MessageCode protoMessageCode: protoErrorMessage.getErrorCodeList()){
                messageCode.setCode(protoMessageCode.getCode());
                messageCode.setMessageContext(protoMessageCode.getCodeContext());
                messageCodeList.add(messageCode);
            }
            errorMessage.setMessageCode(messageCodeList);
            if (protoErrorMessage.getDescription()!=null) {
                Description description = new Description();
                description.setMessage(protoErrorMessage.getDescription().getMessage());
                description.setLang(protoErrorMessage.getDescription().getLang());
                errorMessage.setDescription(description);
            }
            errorMessageList.add(errorMessage);
        }

        flightSeatMap.setErrorMessages(errorMessageList);
        flightSeatMap.setWarningMessages(warnMessageList);
        return flightSeatMap;
    }

    private com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Seatmap getSeatMap(Seatmap seatmap){
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Seatmap seatMap = new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Seatmap();
        seatMap.setIataConfigurationCode(seatmap.getIataConfigurationCode());
        seatMap.setDepartureAirportCode(seatmap.getDepartureAirportCode());
        seatMap.setArrivalAirportCode(seatmap.getArrivalAirportCode());
        seatMap.setPhysicalAircraftName(seatmap.getPhysicalAircraftName());
        seatMap.setPhysicalAircraftDescription(seatmap.getPhysicalAircraftDescription());
        seatMap.setCabinJumpSeatCount(seatmap.getCabinJumpSeatCount());
        seatMap.setCockpitJumpSeatCount(seatmap.getCockpitJumpSeatCount());
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Cabin> cabinList =seatmap.getCabinsList()
                .stream()
                .map(this::getCabins)
                .collect(Collectors.toList());
        seatMap.setCabins(cabinList);
        return seatMap;
    }

    private com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Cabin getCabins(Cabin cabin){
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Cabin flightSeatmapCabin = new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Cabin();
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.CabinLayout cabinLayout = new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.CabinLayout();
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.SeatRow> seatRowList =cabin.getSeatRowsList()
                .stream()
                .map(this::getSeatRows)
                .collect(Collectors.toList());
        flightSeatmapCabin.setSeatRows(seatRowList);
        cabinLayout.setCabinCode(cabin.getCabinLayout().getCabinCode());
        cabinLayout.setCabinNumber(cabin.getCabinLayout().getCabinNumber());
        cabinLayout.setFirstRow(cabin.getCabinLayout().getFirstRow());
        cabinLayout.setCabinCodeDescription(cabin.getCabinLayout().getCabinCodeDescription());
        cabinLayout.setLastRow(cabin.getCabinLayout().getLastRow());
        cabinLayout.setSeatCount(cabin.getCabinLayout().getSeatCount());
        flightSeatmapCabin.setCabinLayout(cabinLayout);
        return flightSeatmapCabin;
    }

    private com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.SeatRow getSeatRows(SeatRow seatRow){
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.SeatRow flightSeatmapSeatRow = new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.SeatRow();
        flightSeatmapSeatRow.setRowNumber(seatRow.getRowNumber());
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.OxygenMask> oxygenMaskList =seatRow.getOxygenMasksList()
                .stream()
                .map(this::getOxygenMasks)
                .collect(Collectors.toList());
        flightSeatmapSeatRow.setOxygenMasks(oxygenMaskList);
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Seat> seatList =seatRow.getSeatsList()
                .stream()
                .map(this::getSeats)
                .collect(Collectors.toList());
        flightSeatmapSeatRow.setOxygenMasks(oxygenMaskList);
        flightSeatmapSeatRow.setSeats(seatList);
        return flightSeatmapSeatRow;
    }

    private com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.OxygenMask getOxygenMasks(OxygenMask oxygenMask){
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.OxygenMask flightSeatmapOxygenMask = new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.OxygenMask();
        flightSeatmapOxygenMask.setAdditionalMaskCount(oxygenMask.getAdditionalMaskCount());
        flightSeatmapOxygenMask.setSection(oxygenMask.getSection());
        return flightSeatmapOxygenMask;
    }

    private com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Seat getSeats(Seat seat){
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Seat flightSeatmapseat = new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Seat();
        flightSeatmapseat.setSeatStatus(seat.getSeatStatus().toString());
        flightSeatmapseat.setColumnCode(seat.getColumnCode());
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Characteristic> characteristicList =seat.getCharacteristicsList()
                .stream()
                .map(this::getCharacteristics)
                .collect(Collectors.toList());

        flightSeatmapseat.setCharacteristics(characteristicList);
        return flightSeatmapseat;
    }
    private com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Characteristic getCharacteristics(Characteristics characteristics){
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Characteristic flightseatmapCharacteristic = new Characteristic();
        flightseatmapCharacteristic.setCodeContext(characteristics.getCodeContext().toString());
        flightseatmapCharacteristic.setCodes(characteristics.getCodesList());
        return flightseatmapCharacteristic;

    }

    private String getSeatMap(String resp, RequestInfo requestInfo, SegmentInfo segmentInfo) {
        resp=resp.replaceAll("\\w*<VERSION>",requestInfo.getVersion());
        resp=resp.replaceAll("\\w*<TRANSACTION_ID>",requestInfo.getTransactionId());
        resp=resp.replaceAll("\\w*<CORRELATION_ID>",requestInfo.getCorrelationId());
        resp=resp.replaceAll("\\w*<REQUEST_DATETIME>",requestInfo.getTimestamp());
        resp=resp.replaceAll("\\w*<RESPONSE_DATETIME>", requestInfo.getTimestamp());
        resp=resp.replaceAll("\\w*<AIRLINE_CODE>",segmentInfo.getFlightInfo().getAirlineCode());
        resp=resp.replaceAll("\\w*<FLIGHT_NUMBER>",segmentInfo.getFlightInfo().getFlightNumber());
        resp=resp.replaceAll("\\w*<DEPARTURE_DATE>",segmentInfo.getFlightInfo().getScheduledDepartureDate());
        resp=resp.replaceAll("\\w*<DEPARTURE_AIRPORT_CODE>",segmentInfo.getFlightInfo().getDepartureAirportCode());
        resp=resp.replaceAll("\\w*<ARRIVAL_AIRPORT_CODE>",segmentInfo.getFlightInfo().getArrivalAirportCode());
        return resp;
    }

}
