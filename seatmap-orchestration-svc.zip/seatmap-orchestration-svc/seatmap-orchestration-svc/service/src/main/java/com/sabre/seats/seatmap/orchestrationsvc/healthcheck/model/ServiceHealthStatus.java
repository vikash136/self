package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model;

import lombok.Data;

import java.util.Map;

@Data
public class ServiceHealthStatus {

    private ServiceStatus status;

    Map<String, ServiceInfo> component;

}
