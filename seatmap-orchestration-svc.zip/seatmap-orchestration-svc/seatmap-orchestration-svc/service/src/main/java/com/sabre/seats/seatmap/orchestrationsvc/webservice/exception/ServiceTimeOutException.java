package com.sabre.seats.seatmap.orchestrationsvc.webservice.exception;

public class ServiceTimeOutException extends Exception {

    public ServiceTimeOutException(String message) {
        super(message);
    }

}
