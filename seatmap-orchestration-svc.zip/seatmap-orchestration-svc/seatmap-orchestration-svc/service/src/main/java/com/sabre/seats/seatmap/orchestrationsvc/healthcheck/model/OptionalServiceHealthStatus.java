package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model;

import lombok.Data;

import java.util.Map;

@Data
public class OptionalServiceHealthStatus {

        private ServiceStatus status;

        private Map<String, ServiceInfo> component;

}
