package com.sabre.seats.seatmap.orchestrationsvc.webservice.connection;

import com.sabre.http.connector.HttpConnectionProperty;
import com.sabre.http.connector.HttpConnectionType;
import com.sabre.http.enums.ConnectivityProtocol;
import com.sabre.http.enums.TrustStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class EssmHttpPublicKeyConnectionProperty extends HttpConnectionProperty {

    @Value("${essm.get.public.key.connect.timeout}")
    private Integer connectTimeout;

    @Value("${essm.get.public.key.socket.timeout}")
    private Integer socketTimeout;

    @PostConstruct
    public void init() {
        setHttpConnectionType(HttpConnectionType.TIMEOUT);
        setConnectTimeout(connectTimeout);
        setSocketTimeout(socketTimeout);
        setHttpsEnabled(true);
        setProtocol(ConnectivityProtocol.TLS);
        setTrustStrategy(TrustStrategy.TRUST_SELF_SIGNED);
        setValidateSubjectAlternativeName(false);
    }
}
