package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GenericRootController {
    private final String applicationName;

    public GenericRootController(@Value("${spring.application.name}") String applicationName) {
        this.applicationName = applicationName;
    }

    @GetMapping(path = "/")
    public ResponseEntity<String> root() {
        var message = String.format("This is auto-generated '%s' application", applicationName);
        return ResponseEntity.ok(message);
    }
}
