package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.connector.model.*;
import com.sabre.connector.tpf.constants.ConnectorConstants;
import com.sabre.connector.tpf.enums.ConnectivityType;
import com.sabre.connector.tpf.service.Connector;
import com.sabre.http.connector.HttpConnectionProperty;
import com.sabre.http.connector.HttpConnector;
import com.sabre.http.connector.HttpConnectorImpl;
import com.sabre.http.exception.HttpCallFailedException;
import com.sabre.seats.common.protobuf.ResponseInfo;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.common.protobuf.SeatAction;
import com.sabre.seats.common.protobuf.SegmentResponse;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.CoreServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.UnknownGenericException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import springfox.documentation.spring.web.json.Json;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Slf4j
@Component
public class SeatmapSupplierService implements FlightItemProcessor {

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    private Connector connector;

    @Value("${tpf.connectTimeout}")
    private String tpfConnectTimeout;

    @Value("${tpf.socketTimeout}")
    private String tpfSocketTimeout;

    @Value("${appId}")
    private String customerID;


    private static final String UNKNOWN_GENERIC_EXCEPTION = "UnknownGenericException";
    private static final String TPF = "TPF";
    private static final String HTTP = "http";
    private static final String SECURITY_TOKEN = "securityToken";
    private static final String TRANSACTION_ID = "x-transaction-id";
    private static final String CORRELATION_ID = "x-correlation-id";


    @Override
    public void processFlightItem(WebServiceRequestResponseContext requestResponseContext, int segmentId) {

        FlightItemReqResContext flightItemReqResContext=requestResponseContext.getFlightItemReqResContextMap().get(segmentId);

        if (ResponseStatus.SUCCESS.equals(flightItemReqResContext.getTransformSupplierRequestStatus())
                && StringUtils.isNotEmpty(flightItemReqResContext.getSupplierRequestFromTransformer())) {

            if (flightItemReqResContext.getConnectivityConfiguration().getPlatform().equals(TPF)) {
                getSeatmapFromTpf(requestResponseContext, flightItemReqResContext);
            } else {
                getSeatMapFromCore(requestResponseContext, flightItemReqResContext);
            }
        }

    }
    private void getSeatMapFromCore(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) {
        String seatmapResponseFromCore = "";
        ResponseInfo responseInfo = null;
        try{
            log.info(EscapeUtil.escape("In getSeatMapFromCore try block"));
            String url = flightItemReqResContext.getConnectivityConfiguration().getConnectivityDestination();
            String transactionId = requestResponseContext.getRequestInfo().getTransactionId();
            String correlationId = requestResponseContext.getRequestInfo().getCorrelationId();

            seatmapResponseFromCore = getSeatMapFromCore(url, flightItemReqResContext.getSupplierRequestFromTransformer(), requestResponseContext.getJwtToken(), transactionId, correlationId);
            log.debug(EscapeUtil.escape("Response from core: {}" + seatmapResponseFromCore));

        } catch(CoreServiceTimeOutException e){
            log.info(EscapeUtil.escape("In getSeatMapFromCore catch block"));
            log.error(EscapeUtil.escape("CoreServiceTimeOutException in SeatmapCore service: " + e.getMessage()));
            responseInfo = errorMessageListBuilder.getErrorResponseInfo("CoreServiceTimeOutException");

        } catch(Exception e){
            log.error(EscapeUtil.escape("Exception in SeatmapCore service : " + e));
            responseInfo = errorMessageListBuilder.getErrorResponseInfo(UNKNOWN_GENERIC_EXCEPTION);

        } finally {
            validateResponse(flightItemReqResContext, seatmapResponseFromCore, responseInfo);
        }

    }

    public String getSeatMapFromCore(String url, String body, String token, String transactionId, String correlationId) throws UnknownGenericException, CoreServiceTimeOutException {
        try{
            return new Json(sendRequest(url, body, token, transactionId, correlationId).getBody()).value();
        } catch(HttpCallFailedException e){
            throw new CoreServiceTimeOutException(e.getMessage());
        } catch(Exception e){
            throw new UnknownGenericException(e.getMessage());
        }
    }

    ResponseEntity<String> sendRequest(String url, String body, String token, String transactionId, String correlationId) throws HttpCallFailedException, IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        HttpConnectionProperty httpConnectionProperty = new HttpConnectionProperty();
        HttpConnector httpConnector = new HttpConnectorImpl(httpConnectionProperty);
        HttpHeaders headers=new HttpHeaders();
        headers.add(SECURITY_TOKEN,token);
        headers.add(TRANSACTION_ID, transactionId);
        headers.add(CORRELATION_ID, correlationId);
        return httpConnector.postForEntity(url, new Json(body), headers, String.class);
    }

    private void getSeatmapFromTpf(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) {
        String seatmapResponseFromTpf = "";
        ResponseInfo responseInfo = null;
        try{

            log.info(EscapeUtil.escape("Request sent to tpf"));
            ConnectorRequest connectorRequest = buildConnectorRequest(requestResponseContext, flightItemReqResContext);

            ConnectorResponse connectorResponse = connector.connect(connectorRequest);
            log.info(EscapeUtil.escape("Response received from tpf"));
            if(!CollectionUtils.isEmpty(connectorResponse.getErrorMessages()) || ((Property_)connectorResponse.getHeader().getProperties().get(1)).getValue().equals("FAILED")){
                responseInfo = errorMessageListBuilder.getResponseInfo(connectorResponse);
            }else{
                seatmapResponseFromTpf = connectorResponse.getPayload().getMessageBody().get(0);
            }

        } catch(Exception e){
            log.error("Exception in tpf : ", e);
        } finally {
            validateResponse(flightItemReqResContext, seatmapResponseFromTpf, responseInfo);
        }
    }
    private ConnectorRequest buildConnectorRequest(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) {

        SabreHeader sabreHeader = new SabreHeader();
        sabreHeader.setCustomerID(customerID);
        sabreHeader.setCustomerAppID(customerID);
        sabreHeader.setTimeStamp(requestResponseContext.getRequestInfo().getTimestamp());

        Header header = new Header();
        header.setCorrelationId(requestResponseContext.getRequestInfo().getCorrelationId());
        header.setPriority("1");
        header.setSupplierId(ConnectorConstants.SUPPLIER_ID);

        List<Property> propertyList = new ArrayList<>();
        propertyList.add(getPropertyDetails(ConnectorConstants.TRANSACTION_ID,requestResponseContext.getRequestInfo().getTransactionId()));
        propertyList.add(getPropertyDetails(ConnectorConstants.IATA,requestResponseContext.getClientInfo().getLniata()));
        propertyList.add(getPropertyDetails(ConnectorConstants.CHANNEL_ID,requestResponseContext.getClientInfo().getRequester()));
        propertyList.add(getPropertyDetails(ConnectorConstants.CHANNEL_TYPE,requestResponseContext.getClientInfo().getRequesterType().toString()));
        propertyList.add(getPropertyDetails(ConnectorConstants.REQUESTEE_CAHNNEL_ID,flightItemReqResContext.getSegmentInfo().getFlightInfo().getAirlineCode()));
        propertyList.add(getPropertyDetails(ConnectorConstants.SUPPLIER_TYPE,requestResponseContext.getClientInfo().getSupplierType().name()));
        propertyList.add(getPropertyDetails(ConnectorConstants.SEAT_ACION, SeatAction.SEAT_VIEW.toString()));
        propertyList.add(getPropertyDetails(ConnectorConstants.LOCK_ID,requestResponseContext.getClientInfo().getLockId()));
        propertyList.add(getPropertyDetails(ConnectorConstants.SDS_INPUT, "true"));
        propertyList.add(getPropertyDetails(ConnectorConstants.CONNECTIVITY_TYPE,flightItemReqResContext.getConnectivityConfiguration().getConnectivityType().equals(HTTP)?ConnectivityType.HTTP.toString():ConnectivityType.HTTPS.toString())); //Hardcoded for now as change required from connectivity End
        propertyList.add(getPropertyDetails(ConnectorConstants.CONNECT_ENDPOINT,
                flightItemReqResContext.getConnectivityConfiguration().getConnectivityDestination()));
        propertyList.add(getPropertyDetails(ConnectorConstants.IS_PAYLOAD_LENGTH_REQUIRED,"false"));
        propertyList.add(getPropertyDetails(ConnectorConstants.CONNECT_TIMEOUT ,tpfConnectTimeout));
        propertyList.add(getPropertyDetails(ConnectorConstants.SOCKET_TIMEOUT ,tpfSocketTimeout));

        Payload payload = new Payload();
        payload.setHeader(header);
        payload.setProperties(propertyList);
        payload.setMessageBody(new ArrayList<>(Collections.singletonList(flightItemReqResContext.getSupplierRequestFromTransformer())));

        ConnectorRequest connectorRequest = new ConnectorRequest();
        connectorRequest.setJwtToken(requestResponseContext.getJwtToken());
        connectorRequest.setSabreHeader(sabreHeader);
        connectorRequest.setPayload(payload);
        return connectorRequest;
    }

    private static Property getPropertyDetails(String key, String value){
        Property property = new Property();
        property.setKey(key);
        property.setValue(value);
        return property;
    }

    private void validateResponse(FlightItemReqResContext flightItemReqResContext,String seatmapSupplierResponse, ResponseInfo responseInfo){

        if(StringUtils.isEmpty(seatmapSupplierResponse) && null == responseInfo){
            responseInfo = errorMessageListBuilder.getErrorResponseInfo (UNKNOWN_GENERIC_EXCEPTION);
        }

        if(StringUtils.isNotEmpty(seatmapSupplierResponse)){
            flightItemReqResContext.setSupplierResponseStatus(ResponseStatus.SUCCESS);
            flightItemReqResContext.setSeatmapResponseFromSupplier(seatmapSupplierResponse);

        } else{
            flightItemReqResContext.setSupplierResponseStatus(ResponseStatus.FAILED);
            SegmentResponse segmentResponse=SegmentResponse.newBuilder()
                    .setResponseInfo(responseInfo)
                    .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                    .build();
            flightItemReqResContext.setSegmentResponse(segmentResponse);
        }
    }
    
    
}
