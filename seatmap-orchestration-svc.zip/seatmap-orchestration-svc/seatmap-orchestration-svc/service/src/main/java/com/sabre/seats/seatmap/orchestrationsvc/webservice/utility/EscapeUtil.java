package com.sabre.seats.seatmap.orchestrationsvc.webservice.utility;

import org.springframework.web.util.HtmlUtils;

public class EscapeUtil {

    private EscapeUtil() {

    }

    public static String escape(String input) {
        return HtmlUtils.htmlEscape(input);
    }
}
