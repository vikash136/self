package com.sabre.seats.seatmap.orchestrationsvc.webservice.utility;

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServerResponse;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServiceStatus;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.ServiceTimeoutEnum;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.AuthorizationService;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.ConnectivityService;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TransformerConnectivityToSupplierService;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TransformerAirSeatMapRQToAuthorizationService;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Component
public class ServiceTimeoutUtil {

    @Autowired
    private ConnectivityService connectivityService;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private TransformerAirSeatMapRQToAuthorizationService airSeatMapRQToAuthorizationService;

    @Autowired
    private TransformerConnectivityToSupplierService connectivityToCoreTransformerService;

    @Autowired
    private ServiceHealthCheckStore serviceHealthCheckStore;

    @Autowired
    MeterRegistry meterRegistry;

    @Value("${service.retryCount}")
    private Integer serviceRetryCount;

    public Integer getServiceTimeout(ServiceTimeoutEnum service) {
        log.info(EscapeUtil.escape("in getServiceTimeout method"));
        if (ServiceTimeoutEnum.CONNECTIVITY.equals(service)) {
            return connectivityService.getConnectivityServiceCallTimeout();
        } else if (ServiceTimeoutEnum.AUTHORIZATION.equals(service)) {
            return authorizationService.getAuthorizationServiceCallTimeout();
        } else if (ServiceTimeoutEnum.AUTH_TRANSFORMATION.equals(service)) {
            return airSeatMapRQToAuthorizationService.getTransformationServiceCallTimeout();
        } else if (ServiceTimeoutEnum.CONN_TRANSFORMATION.equals(service)) {
            return connectivityToCoreTransformerService.getTransformationServiceCallTimeout();
        } else {
            log.debug(EscapeUtil.escape("Service did not match"));
        }
        return null;
    }

    public void setServiceTimeout(ServiceTimeoutEnum service, String time) {
        log.info(EscapeUtil.escape("in setServiceTimeout method"));
        var intTime = Integer.parseInt(time);
        if (ServiceTimeoutEnum.CONNECTIVITY.equals(service)) {
            connectivityService.setConnectivityServiceCallTimeout(intTime);
        } else if (ServiceTimeoutEnum.AUTHORIZATION.equals(service)) {
            authorizationService.setAuthorizationServiceCallTimeout(intTime);
        } else if (ServiceTimeoutEnum.AUTH_TRANSFORMATION.equals(service)) {
            airSeatMapRQToAuthorizationService.setTransformationServiceCallTimeout(intTime);
        } else if (ServiceTimeoutEnum.CONN_TRANSFORMATION.equals(service)) {
            connectivityToCoreTransformerService.setTransformationServiceCallTimeout(intTime);
        } else {
            log.debug(EscapeUtil.escape("Service did not match"));
        }
    }

    public void setServiceDown(String serviceName) {
        AtomicInteger retryCount = serviceHealthCheckStore.getRetryCount(serviceName);
        if (retryCount.intValue() < 3) {
            retryCount.incrementAndGet();
            serviceHealthCheckStore.setRetryCount(serviceName, retryCount);
            if (retryCount.intValue() >= serviceRetryCount) {
                Counter.builder("Health.Down").register(meterRegistry).increment();
                serviceHealthCheckStore.getDynamicHealthCheckMap().put(serviceName, ServiceStatus.DOWN.getStatus());
                serviceHealthCheckStore.setServiceComponentDown(serviceName, ServerResponse.NOT_SERVING.getServerResponse());
            }
        }
    }
}
