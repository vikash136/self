package com.sabre.seats.seatmap.orchestrationsvc.webservice.converter;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.transformation.protobuf.TransformReqResponse;
import org.springframework.stereotype.Component;

@Component
public class FlightItemReqResContextConverter {

    public void createFlightItemContextMap(WebServiceRequestResponseContext requestResponseContext, TransformReqResponse transformResponse) {

        transformResponse.getSeatMapOutputReqResponse().getOutputResponse().getSeatMapRequest().getPaxSegmentInfoList().forEach(paxSegmentInfo -> {
            var flightItemReqResContext = new FlightItemReqResContext();
            flightItemReqResContext.setSegmentInfo(paxSegmentInfo.getSegmentInfo());
            flightItemReqResContext.setPassengerSeatmapRetrieveRequestList(paxSegmentInfo.getPassengersList());
            requestResponseContext.getFlightItemReqResContextMap().put(paxSegmentInfo.getSegmentInfo().getSegmentId(),flightItemReqResContext);
        });
    }

}
