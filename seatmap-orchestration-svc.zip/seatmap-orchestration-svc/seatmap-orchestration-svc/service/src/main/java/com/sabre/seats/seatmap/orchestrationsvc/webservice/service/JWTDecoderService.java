package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.checkin.jwtdecoder.exception.ESSMKeyNotFoundException;
import com.sabre.checkin.jwtdecoder.model.DecodeType;
import com.sabre.checkin.jwtdecoder.model.JWTDecodedData;
import com.sabre.checkin.jwtdecoder.model.JWTDecoderRequest;
import com.sabre.checkin.jwtdecoder.service.JWTDecoder;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.service.ESSMService;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.converter.JwtDecodedDataToClientInfo;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.NoJwtDecoderTypeException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.common.protobuf.ClientInfo;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Slf4j
@Component
public class JWTDecoderService implements RequestProcessor {

    @Value("${appId}")
    private String appId;

    @Value("${essmBaseUrl}")
    private String essmBaseUrl;

    @Autowired
    private JwtDecodedDataToClientInfo jwtDecodedDataToClientInfo;

    @Autowired
    private List<JWTDecoder> jwtDecoderList;

    @Autowired
    private ESSMService essmService;

    @Autowired
    MeterRegistry meterRegistry;

    private String decoderType = DecodeType.ESSM.getType();

    @Override
    public void processRequest(WebServiceRequestResponseContext requestResponseContext) throws ESSMKeyNotFoundException, NoJwtDecoderTypeException {
        Optional<JWTDecodedData> jwtDecodedData = decode(requestResponseContext.getJwtToken());
        Optional<JWTDecodedData> tjrDecodedData = null;
        if(requestResponseContext.getTjrToken()!=null) {
            tjrDecodedData = decode(requestResponseContext.getTjrToken());
        }
        ClientInfo clientInfo = jwtDecodedDataToClientInfo.convertJwtDecodedDataToClientInfo(jwtDecodedData, tjrDecodedData);
        requestResponseContext.setClientInfo(clientInfo);
    }

    private Optional<JWTDecodedData> decode(String token) throws ESSMKeyNotFoundException, NoJwtDecoderTypeException {
        JWTDecoder jwtDecoder = getJwtDecoder(decoderType);
        if (jwtDecoder == null) {
            Counter.builder("No.JWTDecoder.Found").register(meterRegistry).increment();
            throw new NoJwtDecoderTypeException(String.format("No JWTDecoder found for type: %s", decoderType));
        }
        JWTDecoderRequest jwtDecoderRequest = getJWTDecoderRequest(token);

        Optional<JWTDecodedData> jwtDecodedData;
        try {
            jwtDecodedData = jwtDecoder.validateAndDecodeJWTToken(jwtDecoderRequest);
        } catch (ESSMKeyNotFoundException e) {
            log.error(EscapeUtil.escape("ESSMKeyNotFoundException :: {} " + e));
            essmService.setEssmDown();
            Counter.builder("ESSMService.Down").register(meterRegistry).increment();
            throw e;
        }
        return  jwtDecodedData;
    }

    public boolean refreshJWTTokens() {
        JWTDecoder jwtDecoder = getJwtDecoder(decoderType);
        if (jwtDecoder == null) {
            log.error(EscapeUtil.escape("No JWTDecoder found for type :: " + decoderType));
            return false;
        }
        return jwtDecoder.refreshJWTTokens(getJWTDecoderRequest("dummy"));
    }

    private JWTDecoderRequest getJWTDecoderRequest(String jwtToken) {
            Long id = Instant.now().toEpochMilli();
            return new JWTDecoderRequest(appId, "conId-" + id, "message-" + id, essmBaseUrl,jwtToken);
    }
        JWTDecoder getJwtDecoder (String type){
            for (JWTDecoder jwtDecoder : jwtDecoderList) {
                if (jwtDecoder.getType().equals(type)) {
                    return jwtDecoder;
                }
            }
            return null;

    }
}
