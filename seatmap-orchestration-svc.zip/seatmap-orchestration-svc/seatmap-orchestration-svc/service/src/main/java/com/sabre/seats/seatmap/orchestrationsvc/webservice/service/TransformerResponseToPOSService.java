package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil;
import com.sabre.seats.common.protobuf.*;
import com.sabre.seats.transformation.protobuf.*;
import io.grpc.ManagedChannel;
import io.grpc.StatusRuntimeException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Component
@Slf4j
public class TransformerResponseToPOSService implements RequestProcessor {

    private static final String TRANSFORMER_SERVICE = "transformerService";

    @Autowired
    @Qualifier("transformChannel")
    ManagedChannel transformProtoToPosRespChannel;

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    private ServiceTimeoutUtil serviceTimeoutUtil;

    @Value("${transformationService.callTimeout}")
    private int transformationServiceCallTimeout;

    @Value("${transformationService.version}")
    private String transformationServiceVersion;

    @Override
    public void processRequest(WebServiceRequestResponseContext requestResponseContext) throws ServiceTimeOutException {
            getSeatmapPOSResponse(requestResponseContext);
    }

    private void getSeatmapPOSResponse(WebServiceRequestResponseContext requestResponseContext) throws ServiceTimeOutException{
        log.info(EscapeUtil.escape("Inside getSeatmapPOSResponse method"));
        TransformReqResponse transformerPosResponse=null;
        try{
            TransformServiceGrpc.TransformServiceBlockingStub transformServiceBlockingStub = TransformServiceGrpc
                    .newBlockingStub(transformProtoToPosRespChannel)
                    .withDeadlineAfter(transformationServiceCallTimeout, TimeUnit.MILLISECONDS);

            TransformRequest transformRequest = getTransformRequestForPosResponse(requestResponseContext);

            log.debug(EscapeUtil.escape("transformRequest - TransformerResponseToPOSService: {}" + transformRequest));
            transformerPosResponse = getResponseForPos(transformServiceBlockingStub, transformRequest);
            log.debug(EscapeUtil.escape("transformResponse - TransformerResponseToPOSService: {}" + transformerPosResponse));

        } catch(StatusRuntimeException ste) {
            log.info(EscapeUtil.escape("StatusRuntimeException in TransformationResponseToPOSService : {}"));
            serviceTimeoutUtil.setServiceDown(TRANSFORMER_SERVICE);
            throw new ServiceTimeOutException("ServiceTimeOutException");
        } catch(Exception e) {
            log.info(EscapeUtil.escape("Exception in TransformationResponseToPOSService : " + e));
        }

        validateResponse(requestResponseContext, transformerPosResponse);
    }

    private TransformRequest getTransformRequestForPosResponse(WebServiceRequestResponseContext requestResponseContext) {
        log.debug(EscapeUtil.escape("Inside getTransformRequestForPosResponse method"));

        MessageInfo inputMessageInfo = MessageInfo.newBuilder()
                .setMsgType(MessageType.SEAT_MAP_RESPONSE )
                .setFormat(MessageFormat.PROTOBUF)
                .setVersion(transformationServiceVersion)
                .build();

        MessageInfo desiredMessageInfo = MessageInfo.newBuilder()
                .setMsgType(MessageType.SEAT_MAP_RESPONSE )
                .setFormat(MessageFormat.JSON)
                .setVersion(requestResponseContext.getRequestVersion())
                .build();


        InputRequest inputRequest = InputRequest.newBuilder()
                .setSeatMapResponse(populateSeatMapResponse(requestResponseContext)).build();

        Input input = Input.newBuilder()
                .setInputRequest(inputRequest)
                .build();

        Request request = Request.newBuilder()
                .setRequestInfo(requestResponseContext.getRequestInfo())
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .build();

        return TransformRequest.newBuilder()
                .setRequest(request)
                .build();
    }

    TransformReqResponse getResponseForPos(TransformServiceGrpc.TransformServiceBlockingStub transformServiceBlockingStub, TransformRequest transformRequest){
        return transformServiceBlockingStub
                .transform(transformRequest);
    }

    private void validateResponse(WebServiceRequestResponseContext requestResponseContext, TransformReqResponse transformResponse) {

        if(null==transformResponse){
            transformResponse = errorMessageListBuilder.getTransformerExceptionResponse("UnknownGenericException");
        }

        requestResponseContext.setTransformReqResponse(transformResponse);
        requestResponseContext.setTransformPosResponseToJsonStatus(transformResponse.getSeatMapOutputReqResponse().getResponseInfo().getResponseStatus());

        if(ResponseStatus.SUCCESS.equals(requestResponseContext.getTransformPosResponseToJsonStatus())){
            requestResponseContext.setSeatmapResponseToPOS(transformResponse.getSeatMapOutputReqResponse().getTransformReqResponse());

        } else{
            requestResponseContext.setResponseInfo(transformResponse.getSeatMapOutputReqResponse().getResponseInfo());
        }
    }
    public int getTransformationServiceCallTimeout() {
        return transformationServiceCallTimeout;
    }

    public void setTransformationServiceCallTimeout(int transformationServiceCallTimeout) {
        this.transformationServiceCallTimeout = transformationServiceCallTimeout;
    }

    private  SeatmapResponse populateSeatMapResponse(WebServiceRequestResponseContext requestResponseContext){
        log.info(EscapeUtil.escape("Inside populateSeatMapResponse method"));

        if(!ResponseStatus.SUCCESS.equals(requestResponseContext.getTransformPosRequestToProtoStatus())
                && CollectionUtils.isEmpty(requestResponseContext.getFlightItemReqResContextMap())) {

            return SeatmapResponse.newBuilder()
                    .setRequestInfo(requestResponseContext.getRequestInfo())
                    .setResponseInfo(requestResponseContext.getResponseInfo())
                    .build();
        }

        List<SegmentResponse> segmentResponseList = requestResponseContext.getFlightItemReqResContextMap().keySet()
                .stream()
                .map(segmentId -> requestResponseContext.getFlightItemReqResContextMap().get(segmentId).getSegmentResponse())
                .collect(Collectors.toList());

        return SeatmapResponse.newBuilder()
                .setRequestInfo(requestResponseContext.getRequestInfo())
                .setResponseInfo(ResponseInfo.newBuilder().setResponseStatus(populateFinalResponseStatus(segmentResponseList)).build())
                .addAllSegmentResponse(segmentResponseList)
                .build();
    }

    private ResponseStatus populateFinalResponseStatus(List<SegmentResponse> segmentResponseList) {

        log.debug(EscapeUtil.escape("Inside populateFinalResponseStatus method"));

        boolean isSuccess=segmentResponseList.stream().allMatch(segmentResponse -> ResponseStatus.SUCCESS.equals(segmentResponse.getResponseInfo().getResponseStatus()));
        if(isSuccess){
            return ResponseStatus.SUCCESS;
        }

        boolean isFailed=segmentResponseList.stream().allMatch(segmentResponse -> ResponseStatus.FAILED.equals(segmentResponse.getResponseInfo().getResponseStatus()));
        if(isFailed){
            return ResponseStatus.FAILED;
        }

        return ResponseStatus.PARTIAL_SUCCESS;
    }

}