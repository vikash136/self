package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.common.protobuf.SeatAction;
import com.sabre.seats.common.protobuf.SegmentResponse;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationRequest;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationResponse;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.StatusRuntimeException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class ConnectivityService implements FlightItemProcessor {

    @Value("${connectivityService.callTimeout}")
    private int connectivityServiceCallTimeout;

    @Value("${connectivityService.version}")
    private String connectivityServiceVersion;

    @Autowired
    @Qualifier("connectivityServiceChannel")
    ManagedChannel connectivityServiceChannel;

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    private ServiceTimeoutUtil serviceTimeoutUtil;

    private static final String CONNECTIVITY_SERVICE = "ConnectivityService";

    @Override
    public void processFlightItem(WebServiceRequestResponseContext requestResponseContext, int segmentId) throws ServiceTimeOutException {

        var flightItemReqResContext = requestResponseContext.getFlightItemReqResContextMap().get(segmentId);

        if (!ResponseStatus.FAILED.equals(flightItemReqResContext.getAuthorizationResponseStatus())
                && Objects.nonNull(flightItemReqResContext.getSupplier())) {
            getSupplierDetails(requestResponseContext, flightItemReqResContext);
        }

    }

    private void getSupplierDetails(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) throws ServiceTimeOutException {
        log.info(EscapeUtil.escape("inside getSupplierDetails method"));
        ConnectivityConfigurationRequest connectivityConfigurationRequest;
        ConnectivityConfigurationResponse connectivityConfigurationResponse = null;
        try {
            ConnectivityConfigurationServiceGrpc.ConnectivityConfigurationServiceBlockingStub
                    connectivityServiceBlockingStub = ConnectivityConfigurationServiceGrpc
                    .newBlockingStub(connectivityServiceChannel)
                    .withDeadlineAfter(connectivityServiceCallTimeout, TimeUnit.MILLISECONDS);

            connectivityConfigurationRequest = ConnectivityConfigurationRequest.newBuilder()
                    .setRequestInfo(requestResponseContext.getRequestInfo())
                    .setSupplier(flightItemReqResContext.getSupplier().getAirlineCode())
                    .setSupplierType(flightItemReqResContext.getSegmentInfo().getSupplierType())
                    .setSeatAction(SeatAction.SEAT_VIEW)
                    .build();

            log.debug(EscapeUtil.escape("connectivityConfigurationRequest :: " + connectivityConfigurationRequest));
            connectivityConfigurationResponse = getConnectivityResponse(connectivityServiceBlockingStub, connectivityConfigurationRequest);
            log.debug(EscapeUtil.escape("ConnectivityConfigurationResponse :: " + connectivityConfigurationResponse));

        } catch (StatusRuntimeException sre) {
            log.error(EscapeUtil.escape("StatusRuntimeException in ConnectivityService : {} " + sre.getMessage()));
            serviceTimeoutUtil.setServiceDown(CONNECTIVITY_SERVICE);
            connectivityConfigurationResponse = errorMessageListBuilder.getConnectivityExceptionResponse ("ConnectivityTimeOutException");
            throw new ServiceTimeOutException("ServiceTimeOutException");

        } catch (Exception e) {
            log.error(EscapeUtil.escape("StatusRuntimeException in ConnectivityService : {} " + e));

        } finally {
            validateResponse(flightItemReqResContext, connectivityConfigurationResponse);
        }

    }

    ConnectivityConfigurationResponse getConnectivityResponse(ConnectivityConfigurationServiceGrpc.ConnectivityConfigurationServiceBlockingStub connectivityServiceBlockingStub,
                                                              ConnectivityConfigurationRequest connectivityConfigurationRequest){
        return connectivityServiceBlockingStub
                .getConnectivityConfiguration(connectivityConfigurationRequest);
    }

    private void validateResponse(FlightItemReqResContext flightItemReqResContext, ConnectivityConfigurationResponse connectivityConfigurationResponse) {
        log.debug(EscapeUtil.escape("inside validateResponse method"));

        if(null==connectivityConfigurationResponse){
            connectivityConfigurationResponse = errorMessageListBuilder.getConnectivityExceptionResponse("UnknownGenericException");
        }

        flightItemReqResContext.setConnectivityConfigurationResponse(connectivityConfigurationResponse);
        flightItemReqResContext.setConnectivityResponseStatus(connectivityConfigurationResponse.getResponseInfo().getResponseStatus());

        if(ResponseStatus.SUCCESS.equals(flightItemReqResContext.getConnectivityResponseStatus())){
            flightItemReqResContext.setConnectivityConfiguration(connectivityConfigurationResponse.getConnectivityConfiguration());

        } else{
            var segmentResponse = SegmentResponse.newBuilder()
                    .setResponseInfo(connectivityConfigurationResponse.getResponseInfo())
                    .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                    .build();
            flightItemReqResContext.setSegmentResponse(segmentResponse);
        }

    }
    public int getConnectivityServiceCallTimeout() {
        return connectivityServiceCallTimeout;
    }

    public void setConnectivityServiceCallTimeout(int connectivityServiceCallTimeout) {
        this.connectivityServiceCallTimeout = connectivityServiceCallTimeout;
    }
}
