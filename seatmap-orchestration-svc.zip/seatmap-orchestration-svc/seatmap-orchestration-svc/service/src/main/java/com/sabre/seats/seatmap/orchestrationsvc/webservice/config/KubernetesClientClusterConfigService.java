package com.sabre.seats.seatmap.orchestrationsvc.webservice.config;

import com.marcnuri.yakc.KubernetesClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;

@Service
@RequiredArgsConstructor
public class KubernetesClientClusterConfigService {
    @Value("${authorizationService.name}")
    private String authorizationServiceName;

    private final KubernetesClient kubernetesClient;
    private String namespace;
    private String authorizationServiceHostName;

    @PostConstruct
    public void init() {
        namespace = (kubernetesClient.getConfiguration() != null) ? kubernetesClient.getConfiguration().getNamespace() : "";
        authorizationServiceHostName = StringUtils.hasText(namespace) ? String.format("%s.%s.svc.cluster.local", authorizationServiceName, namespace) : "";
    }

    public String getNamespace() {
        return namespace;
    }

    public String getAuthorizationServiceHostName() {
        return authorizationServiceHostName;
    }
}
