package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.converter.FlightItemReqResContextConverter;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest;
import com.sabre.seats.common.protobuf.MessageFormat;
import com.sabre.seats.common.protobuf.RequestInfo;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.transformation.protobuf.*;
import io.grpc.ManagedChannel;
import io.grpc.StatusRuntimeException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
@Slf4j
public class TransformerAirSeatMapRQToAuthorizationService implements RequestProcessor{

    private static final String TRANSFORMER_SERVICE = "transformerService";

    @Autowired
    @Qualifier("transformChannel")
    ManagedChannel transformPosReqToProtoChannel;

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    FlightItemReqResContextConverter flightItemReqResContextConverter;

    @Autowired
    private ServiceTimeoutUtil serviceTimeoutUtil;

    @Value("${transformationService.callTimeout}")
    private int transformationServiceCallTimeout;

    @Value("${transformationService.version}")
    private String transformationServiceVersion;

    @Override
    public void processRequest(WebServiceRequestResponseContext requestResponseContext) throws ServiceTimeOutException {

        if(requestResponseContext.getClientInfo()!=null &&
                StringUtils.isNotEmpty(requestResponseContext.getClientInfo().getRequester())){
            sendAirSeatMapRQToTransformer(requestResponseContext);
        }
    }

    private void sendAirSeatMapRQToTransformer(WebServiceRequestResponseContext requestResponseContext) throws ServiceTimeOutException {
        log.info(EscapeUtil.escape("Inside sendAirSeatMapRQToTransformer method"));
        TransformRequest transformRequest;
        TransformReqResponse transformResponse=null;
        try{
            TransformServiceGrpc.TransformServiceBlockingStub transformServiceBlockingStub = TransformServiceGrpc
                    .newBlockingStub(transformPosReqToProtoChannel)
                    .withDeadlineAfter(transformationServiceCallTimeout, TimeUnit.MILLISECONDS);

            transformRequest = getTransformationRequest(requestResponseContext);

            log.debug(EscapeUtil.escape("transformRequest: {}" + transformRequest));
            transformResponse = getTransformationResponse(transformServiceBlockingStub, transformRequest);
            log.debug(EscapeUtil.escape("transformResponse: {}" + transformResponse));

        } catch(StatusRuntimeException ex) {
            log.info(EscapeUtil.escape("StatusRuntimeException in TransformationPosRequestToProto :"));
            serviceTimeoutUtil.setServiceDown(TRANSFORMER_SERVICE);
            throw new ServiceTimeOutException("ServiceTimeOutException");
        } catch(Exception ex) {
            log.error(EscapeUtil.escape("Exception in TransformationPosRequestToProto : " + ex));
        }

        validateResponse(requestResponseContext, transformResponse);
    }

    private TransformRequest getTransformationRequest(WebServiceRequestResponseContext requestResponseContext) throws JsonProcessingException {

        MessageInfo inputMessageInfo = MessageInfo.newBuilder()
                .setMsgType(MessageType.SEAT_MAP_REQUEST)
                .setFormat(MessageFormat.JSON)
                .setVersion(requestResponseContext.getRequestVersion())
                .build();

        MessageInfo desiredMessageInfo = MessageInfo.newBuilder()
                .setMsgType(MessageType.SEAT_MAP_REQUEST)
                .setFormat(MessageFormat.PROTOBUF)
                .setVersion(transformationServiceVersion)
                .build();

        Input input = Input.newBuilder()
                .setRequest(convertToJson(requestResponseContext.getAirSeatMapRQ()))
                .build();

        Request request = Request.newBuilder()
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .build();

        return TransformRequest.newBuilder()
                .setRequest(request)
                .build();
    }

    private String convertToJson(AirSeatMapRequest input) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return mapper.writeValueAsString(input);
    }

    TransformReqResponse getTransformationResponse(TransformServiceGrpc.TransformServiceBlockingStub transformServiceBlockingStub, TransformRequest transformRequest){
        return transformServiceBlockingStub
                .transform(transformRequest);
    }

    private void validateResponse(WebServiceRequestResponseContext requestResponseContext, TransformReqResponse transformResponse) {

        if(transformResponse==null){
            transformResponse = errorMessageListBuilder.getTransformerExceptionResponse("UnknownGenericException");
        }

        requestResponseContext.setTransformReqResponse(transformResponse);
        requestResponseContext.setTransformPosRequestToProtoStatus(transformResponse.getSeatMapOutputReqResponse().getResponseInfo().getResponseStatus());

        if(ResponseStatus.SUCCESS.equals(requestResponseContext.getTransformPosRequestToProtoStatus())){
            String requestTimeStamp = transformResponse.getSeatMapOutputReqResponse().getOutputResponse().getSeatMapRequest().getRequestInfo().getTimestamp();
            RequestInfo requestInfo= RequestInfo.newBuilder()
                    .setCorrelationId(requestResponseContext.getRequestInfo().getCorrelationId())
                    .setTransactionId(requestResponseContext.getRequestInfo().getTransactionId())
                    .setTimestamp(requestTimeStamp)
                    .setVersion(requestResponseContext.getRequestVersion()).build();
            requestResponseContext.setRequestInfo(requestInfo);
            flightItemReqResContextConverter.createFlightItemContextMap(requestResponseContext, transformResponse);

        } else{
            RequestInfo requestInfo= RequestInfo.newBuilder()
                    .setCorrelationId(requestResponseContext.getRequestInfo().getCorrelationId())
                    .setTransactionId(requestResponseContext.getRequestInfo().getTransactionId())
                    .setTimestamp(requestResponseContext.getAirSeatMapRQ().getRequestDateTime())
                    .setVersion(requestResponseContext.getRequestVersion()).build();

            requestResponseContext.setRequestInfo(requestInfo);
            requestResponseContext.setResponseInfo(transformResponse.getSeatMapOutputReqResponse().getResponseInfo());
        }
    }

    public int getTransformationServiceCallTimeout() {
        return transformationServiceCallTimeout;
    }

    public void setTransformationServiceCallTimeout(int transformationServiceCallTimeout) {
        this.transformationServiceCallTimeout = transformationServiceCallTimeout;
    }
}
