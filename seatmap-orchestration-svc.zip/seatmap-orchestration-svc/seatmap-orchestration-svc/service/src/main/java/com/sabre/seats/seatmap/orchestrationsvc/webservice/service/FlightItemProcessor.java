package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import org.springframework.retry.annotation.Retryable;

public interface FlightItemProcessor {
    @Retryable(value = ServiceTimeOutException.class, maxAttemptsExpression = "#{${service.retryCount}}")
    void processFlightItem(WebServiceRequestResponseContext requestResponseContext, int segmentId) throws ServiceTimeOutException;
}
