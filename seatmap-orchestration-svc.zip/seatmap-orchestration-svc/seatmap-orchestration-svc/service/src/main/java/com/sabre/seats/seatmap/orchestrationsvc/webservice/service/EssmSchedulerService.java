package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.checkin.jwtdecoder.model.JWTDecoderRequest;
import com.sabre.checkin.jwtdecoder.scheduler.ESSMScheduler;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.NoJwtDecoderTypeException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.Instant;

@Slf4j
@Component
public class EssmSchedulerService {

    @Value("${appId}")
    private String appId;

    @Value("${essmBaseUrl}")
    private String essmBaseUrl;

    @Autowired
    private ESSMScheduler essmScheduler;

    @PostConstruct
    private void init() throws NoJwtDecoderTypeException {
        boolean essmStatus = essmScheduler.schedule(getJwtDecoderRequest());
        if (!essmStatus) {
            throw new NoJwtDecoderTypeException("Scheduler failed to update the essmPublicKeyStore at server startup.");
        }
    }

    public void schedule() {
       essmScheduler.schedule(getJwtDecoderRequest());
    }

    private JWTDecoderRequest getJwtDecoderRequest() {
        long id = Instant.now().getEpochSecond();
        return new JWTDecoderRequest
                (appId, "conId-" + id, "message-" + id, essmBaseUrl, "dummy");
    }
}
