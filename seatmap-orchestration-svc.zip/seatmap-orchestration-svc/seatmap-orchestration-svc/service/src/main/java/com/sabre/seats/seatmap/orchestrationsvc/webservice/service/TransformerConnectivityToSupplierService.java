package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.common.protobuf.*;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil;
import com.sabre.seats.transformation.protobuf.*;
import io.grpc.ManagedChannel;
import io.grpc.StatusRuntimeException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class TransformerConnectivityToSupplierService implements FlightItemProcessor {

    @Value("${transformationService.callTimeout}")
    private int transformationServiceCallTimeout;

    @Value("${transformationService.version}")
    private String transformationServiceVersion;

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    @Qualifier("transformChannel")
    ManagedChannel transformChannel;

    @Autowired
    private ServiceTimeoutUtil serviceTimeoutUtil;

    private static final String TRANSFORMER_SERVICE = "transformerService";

    @Override
    public void processFlightItem(WebServiceRequestResponseContext requestResponseContext, int segmentId) throws ServiceTimeOutException {

        FlightItemReqResContext flightItemReqResContext=requestResponseContext.getFlightItemReqResContextMap().get(segmentId);

        if (ResponseStatus.SUCCESS.equals(flightItemReqResContext.getConnectivityResponseStatus())
                && Objects.nonNull(flightItemReqResContext.getConnectivityConfiguration())) {
            connectivityToCoreTransformer(requestResponseContext, flightItemReqResContext);
        }

    }

    private void connectivityToCoreTransformer(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) throws ServiceTimeOutException {

        log.info(EscapeUtil.escape("Inside connectivityToCoreTransformer method"));
        TransformRequest transformRequest;
        TransformReqResponse transformResponse = null;
        try {
            TransformServiceGrpc.TransformServiceBlockingStub transformServiceBlockingStub = TransformServiceGrpc
                    .newBlockingStub(transformChannel)
                    .withDeadlineAfter(transformationServiceCallTimeout, TimeUnit.MILLISECONDS);

            transformRequest = getTransformRequest(requestResponseContext, flightItemReqResContext);

            log.debug(EscapeUtil.escape("transformRequest: {}" + transformRequest));
            transformResponse = getTransformationResponse(transformServiceBlockingStub, transformRequest);
            log.debug(EscapeUtil.escape("transformResponse: {}" + transformResponse));

        } catch (StatusRuntimeException sre) {
            log.info(EscapeUtil.escape("StatusRuntimeException in TransformerConnectivityToSupplierService: {} "));
            serviceTimeoutUtil.setServiceDown(TRANSFORMER_SERVICE);
            transformResponse = errorMessageListBuilder.getTransformerExceptionResponse("TransformerTimeOutException");
            throw new ServiceTimeOutException("ServiceTimeOutException");

        } catch (Exception ex) {
            log.error(EscapeUtil.escape("Exception in TransformerConnectivityToSupplierService : " + ex));

        } finally {
            validateResponse(flightItemReqResContext, transformResponse);
        }

    }

    private TransformRequest getTransformRequest(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) {

       MessageInfo desiredMessageInfo = MessageInfo.newBuilder()
                .setMsgType(flightItemReqResContext.getConnectivityConfiguration().getMessageRequestType())
                .setFormat(flightItemReqResContext.getConnectivityConfiguration().getMessageFormat())
                .setVersion(flightItemReqResContext.getConnectivityConfiguration().getApiVersion())
                .build();

       PaxSegmentInfo paxSegmentInfo = PaxSegmentInfo.newBuilder()
                .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                .addAllPassengers(flightItemReqResContext.getPassengerSeatmapRetrieveRequestList())
                .build();

       InputRequest inputRequest = InputRequest.newBuilder()
                   .setPaxSegmentInfo(paxSegmentInfo)
                   .build();

        MessageInfo inputMessageInfo = MessageInfo.newBuilder()
                .setMsgType(MessageType.SEGMENT_INFO)
                .setFormat(MessageFormat.PROTOBUF)
                .setVersion(transformationServiceVersion)
                .build();

        Input input = Input.newBuilder()
                .setInputRequest(inputRequest)
                .build();

        Request request = Request.newBuilder()
                .setRequestInfo(requestResponseContext.getRequestInfo())
                .setClientInfo(requestResponseContext.getClientInfo())
                .setSupplierInfo(flightItemReqResContext.getSupplier())
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .setSeatAction(SeatAction.SEAT_VIEW)
                .build();

        return TransformRequest.newBuilder()
                .setRequest(request)
                .build();
    }

    TransformReqResponse getTransformationResponse(TransformServiceGrpc.TransformServiceBlockingStub transformServiceBlockingStub, TransformRequest transformRequest) {
        return transformServiceBlockingStub
                .transform(transformRequest);
    }

    private void validateResponse(FlightItemReqResContext flightItemReqResContext, TransformReqResponse transformResponse) {

        if(transformResponse==null){
            transformResponse = errorMessageListBuilder.getTransformerExceptionResponse("UnknownGenericException");
        }

        flightItemReqResContext.setTransformReqResponse(transformResponse);
        flightItemReqResContext.setTransformSupplierRequestStatus(transformResponse.getSeatMapOutputReqResponse().getResponseInfo().getResponseStatus());

        if(ResponseStatus.SUCCESS.equals(flightItemReqResContext.getTransformSupplierRequestStatus())){
            flightItemReqResContext.setSupplierRequestFromTransformer(transformResponse.getSeatMapOutputReqResponse().getTransformReqResponse());

        } else{
            SegmentResponse segmentResponse=SegmentResponse.newBuilder()
                    .setResponseInfo(transformResponse.getSeatMapOutputReqResponse().getResponseInfo())
                    .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                    .build();
            flightItemReqResContext.setSegmentResponse(segmentResponse);
        }
    }

    public int getTransformationServiceCallTimeout() {
        return transformationServiceCallTimeout;
    }

    public void setTransformationServiceCallTimeout(int transformationServiceCallTimeout) {
        this.transformationServiceCallTimeout = transformationServiceCallTimeout;
    }

}