package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.service;

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServerResponse;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServiceStatus;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.JWTDecoderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class ESSMService {

    private static final String ESSM_SERVICE = "essmService";

    @Autowired
    private ServiceHealthCheckStore serviceHealthCheckStore;

    @Value("${schedule.healthcheckscheduler.dynamicServiceRetryCount}")
    private Integer dynamicServiceRetryCount;

    @Autowired
    private JWTDecoderService jwtDecoderService;

    public void setEssmDown() {
        AtomicInteger retryCount = serviceHealthCheckStore.getRetryCount (ESSM_SERVICE);
        if(retryCount.intValue() < 3) {
            retryCount.incrementAndGet();
            serviceHealthCheckStore.setRetryCount (ESSM_SERVICE,retryCount);
            if(retryCount.intValue() >= dynamicServiceRetryCount) {
                serviceHealthCheckStore.getDynamicHealthCheckMap ().put (ESSM_SERVICE, ServiceStatus.DOWN.getStatus ());
                serviceHealthCheckStore.setServiceComponentDown (ESSM_SERVICE, ServerResponse.NOT_SERVING.getServerResponse ());
            }
        }
    }

    public String getEssmStatus(Map<String, String> map) {
        boolean essmStatus = jwtDecoderService.refreshJWTTokens ();
        if(essmStatus) {
            map.put (ESSM_SERVICE,ServerResponse.SERVING.getServerResponse ());
            return ServerResponse.SERVING.getServerResponse ();
        } else {
            map.put (ESSM_SERVICE, ServerResponse.NOT_SERVING.getServerResponse ());
            return ServerResponse.NOT_SERVING.getServerResponse ();
        }
    }
}
