package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model;

import lombok.Data;

@Data
public class ServiceInfo {

    private String name;

    private ServiceStatus status;

    private long updateTimestamp;

}
