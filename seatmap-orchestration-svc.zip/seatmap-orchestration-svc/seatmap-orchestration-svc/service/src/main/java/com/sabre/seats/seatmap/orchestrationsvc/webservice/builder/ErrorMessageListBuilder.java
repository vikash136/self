package com.sabre.seats.seatmap.orchestrationsvc.webservice.builder;

import com.sabre.connector.model.ConnectorResponse;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ErrorMapUtil;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.Description;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.MessageCode;
import com.sabre.seats.authorization.protobuf.AuthorizationResponse;
import com.sabre.seats.common.protobuf.ResponseInfo;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationResponse;
import com.sabre.seats.error.protobuf.ErrorMessage;
import com.sabre.seats.error.protobuf.WarningMessage;
import com.sabre.seats.seatmapView.protobuf.SeatmapViewResponse;
import com.sabre.seats.transformation.protobuf.SeatMapOutputReqResponse;
import com.sabre.seats.transformation.protobuf.TransformReqResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
public class ErrorMessageListBuilder {

    @Autowired
    private ErrorMapUtil errorMap;

    private static final String DESC_LANG_TAG = "description-languageTag";
    private static final String DESC_MSG = "description-message";
    private static final String IATA_ERROR_CODE = "errorCodeIata-code";
    private static final String IATA_ERROR_CODE_CONTEXT = "errorCodeIata-codeContext";
    private static final String INTERNAL_ERROR_CODE = "errorCodeInternal-code";
    private static final String INTERNAL_ERROR_CODE_CONTEXT = "errorCodeInternal-codeContext";
    private static final String CATEGORY = "category";
    private static final String TYPE = "type";
    private static final String IATA = "IATA";
    private static final String INTERNAL = "INTERNAL";
    private static final String UTF = "UTF-8";

    public List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage> getErrorMessageList(String errorKey) {
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage> errorMessageList = new ArrayList<> ();
        errorMessageList.add (getErrorMessage (errorKey));
        return errorMessageList;
    }


    private com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage getErrorMessage(String errorKey) {
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage errorMessage = new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage();
        Description description  = new Description();
        description.setLang(errorMap.getErrormap ().get (errorKey).get (DESC_LANG_TAG));
        description.setMessage(errorMap.getErrormap ().get (errorKey).get (DESC_MSG));
        MessageCode messageCode1 = new MessageCode();
        messageCode1.setCode(errorMap.getErrormap ().get (errorKey).get (IATA_ERROR_CODE));
        messageCode1.setMessageContext(errorMap.getErrormap ().get (errorKey).get (IATA_ERROR_CODE_CONTEXT));
        MessageCode messageCode2 = new MessageCode();
        messageCode2.setCode(errorMap.getErrormap ().get (errorKey).get (INTERNAL_ERROR_CODE));
        messageCode2.setMessageContext(errorMap.getErrormap ().get (errorKey).get (INTERNAL_ERROR_CODE_CONTEXT));
        List<MessageCode> messageCodeList = new ArrayList<>();
        messageCodeList.add(messageCode1);
        messageCodeList.add(messageCode2);
        errorMessage.setCategory (errorMap.getErrormap ().get (errorKey).get (CATEGORY));
        errorMessage.setType (errorMap.getErrormap ().get (errorKey).get (TYPE));
        errorMessage.setDescription(description);
        errorMessage.setMessageCode(messageCodeList);
        return errorMessage;
    }

    public List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage> getErrorMessageListForFinalResp(List<ErrorMessage> protoErrorMessageList) {
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage> errorMessageList = new ArrayList<> ();

        for(ErrorMessage protoErrorMessage: protoErrorMessageList) {
            com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage errorMessage= new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage();
            errorMessage.setCategory(protoErrorMessage.getCategory());
            if (protoErrorMessage.getDescription() != null) {
                Description description = new Description();
                description.setMessage(protoErrorMessage.getDescription().getMessage());
                description.setLang(protoErrorMessage.getDescription().getLang());
                errorMessage.setDescription(description);
            }
            List<MessageCode> messageCodeList = new ArrayList<>();
            for(com.sabre.seats.error.protobuf.MessageCode  protoMessageCode: protoErrorMessage.getErrorCodeList()){
                MessageCode messageCode = new MessageCode();
                messageCode.setCode(protoMessageCode.getCode());
                messageCode.setMessageContext(protoMessageCode.getCodeContext());
                messageCodeList.add(messageCode);
            }
            errorMessage.setMessageCode (messageCodeList);
            errorMessage.setType(protoErrorMessage.getType());
            errorMessageList.add (errorMessage);
        }
        return errorMessageList;
    }

    public TransformReqResponse getTransformerExceptionResponse(String errorKey){
        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getErrorResponseInfo(errorKey))
                .build();

        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build();
    }

    public AuthorizationResponse getAuthorizationExceptionResponse(String errorKey){
        return AuthorizationResponse.newBuilder()
                .setResponseInfo(getErrorResponseInfo(errorKey))
                .build();
    }

    public ConnectivityConfigurationResponse getConnectivityExceptionResponse(String errorKey){
        return ConnectivityConfigurationResponse.newBuilder()
                .setResponseInfo(getErrorResponseInfo(errorKey))
                .build();
    }

    public SeatmapViewResponse getSeatmapViewExceptionResponse(String errorKey){
        return SeatmapViewResponse.newBuilder()
                .setResponseInfo(getErrorResponseInfo(errorKey))
                .build();
    }

    public ResponseInfo getErrorResponseInfo(String errorKey) {
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setResponseTimestamp(Instant.now().toString())
                .addErrorMessages(buildProtoErrorMessage(errorKey)).build();
    }

    public ResponseInfo getWarningResponseInfo(String errorKey) {
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.SUCCESS)
                .setResponseTimestamp(Instant.now().toString())
                .addWarningMessages(buildProtoWarningMessage(errorKey)).build();
    }

    private ErrorMessage buildProtoErrorMessage(String errorKey) {
        List<com.sabre.seats.error.protobuf.MessageCode> messageCodeList = getMessageCodeList(errorKey);
        return ErrorMessage.newBuilder ()
                .setCategory(errorMap.getErrormap ().get (errorKey).get (CATEGORY))
                .setDescription(com.sabre.seats.error.protobuf.Description.newBuilder()
                        .setLang(errorMap.getErrormap ().get (errorKey).get (DESC_LANG_TAG))
                        .setMessage(errorMap.getErrormap ().get (errorKey).get (DESC_MSG))
                        .build())
                .setType(errorMap.getErrormap ().get (errorKey).get (TYPE))
                .addAllErrorCode(messageCodeList)
                .build ();
    }

    private WarningMessage buildProtoWarningMessage(String errorKey) {
        List<com.sabre.seats.error.protobuf.MessageCode> messageCodeList = getMessageCodeList(errorKey);
        return WarningMessage.newBuilder ()
                .setCategory(errorMap.getErrormap ().get (errorKey).get (CATEGORY))
                .setDescription(com.sabre.seats.error.protobuf.Description.newBuilder()
                        .setLang(errorMap.getErrormap ().get (errorKey).get (DESC_LANG_TAG))
                        .setMessage(errorMap.getErrormap ().get (errorKey).get (DESC_MSG))
                        .build())
                .setType(errorMap.getErrormap ().get (errorKey).get (TYPE))
                .addAllWarningCode(messageCodeList)
                .build ();
    }

    private List<com.sabre.seats.error.protobuf.MessageCode> getMessageCodeList(String errorKey) {
        List<com.sabre.seats.error.protobuf.MessageCode> messageCodeLst = new ArrayList<>();
        com.sabre.seats.error.protobuf.MessageCode messageCode = com.sabre.seats.error.protobuf.MessageCode.newBuilder()
                .setCode(errorMap.getErrormap().get(errorKey).get(IATA_ERROR_CODE))
                .setCodeContext(errorMap.getErrormap().get(errorKey).get(IATA_ERROR_CODE_CONTEXT))
                .build();
        com.sabre.seats.error.protobuf.MessageCode msgCode = com.sabre.seats.error.protobuf.MessageCode.newBuilder()
                .setCode(errorMap.getErrormap().get(errorKey).get(INTERNAL_ERROR_CODE))
                .setCodeContext(errorMap.getErrormap().get(errorKey).get(INTERNAL_ERROR_CODE_CONTEXT))
                .build();
        messageCodeLst.addAll(Arrays.asList(messageCode, msgCode));
        return messageCodeLst;
    }

    public ResponseInfo getResponseInfo(ConnectorResponse connectorResponse) {
        List<ErrorMessage> errorMessageList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(connectorResponse.getErrorMessages())) {
            for (com.sabre.connector.model.ErrorMessage errorMessage : connectorResponse.getErrorMessages()) {
                com.sabre.seats.error.protobuf.MessageCode iataCode = com.sabre.seats.error.protobuf.MessageCode.newBuilder()
                        .setCode(errorMessage.getErrorCodeIata()).setCodeContext(IATA).build();
                com.sabre.seats.error.protobuf.MessageCode internalCode = com.sabre.seats.error.protobuf.MessageCode.newBuilder()
                        .setCode(errorMessage.getErrorCodeInternal()).setCodeContext(INTERNAL).build();

                com.sabre.seats.error.protobuf.Description description = com.sabre.seats.error.protobuf.Description.newBuilder()
                        .setLang(UTF)
                        .setMessage(errorMessage.getIataMessage()).build();

                ErrorMessage message = ErrorMessage.newBuilder()
                        .setCategory(errorMessage.getCategory())
                        .setType(errorMessage.getType())
                        .setDescription(description)
                        .addAllErrorCode(Arrays.asList(iataCode, internalCode))
                        .setFieldName(StringUtils.EMPTY).setFieldPath(StringUtils.EMPTY)
                        .build();
                errorMessageList.add(message);
            }
        }

        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setResponseTimestamp(Instant.now().toString())
                .addAllErrorMessages(errorMessageList).build();
    }
}
