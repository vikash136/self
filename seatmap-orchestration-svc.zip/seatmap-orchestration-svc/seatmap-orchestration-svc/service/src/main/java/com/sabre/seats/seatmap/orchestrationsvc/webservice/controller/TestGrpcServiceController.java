package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TestGrpcService;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest;
import com.sabre.seats.common.protobuf.RequestInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
public class TestGrpcServiceController {

    @Autowired
    TestGrpcService testGrpcService;

    @PostMapping(value ="/{version}/getResponseFromGrpcService", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getResponseFromGrpcService(@RequestBody AirSeatMapRequest airSeatMapRequest, @RequestHeader(name = "securityToken") String token,
                                                             @RequestHeader(name = "x-transaction-id") String transactionId,@RequestHeader(name = "x-correlation-id") String correlationId,
                                                             @PathVariable("version") String version) {
        log.debug(EscapeUtil.escape("Inside getResponseFromGrpcService method"));
        RequestInfo  requestInfo = RequestInfo.newBuilder()
                .setCorrelationId(correlationId)
                .setTransactionId(transactionId)
                .build();

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext();
        requestResponseContext.setRequestVersion(version.replaceAll("[^0-9]+", ""));
        requestResponseContext.setAirSeatMapRQ(airSeatMapRequest);
        requestResponseContext.setJwtToken(token);
        requestResponseContext.setRequestInfo(requestInfo);
        log.info(EscapeUtil.escape("Response received"));
        return ResponseEntity.status(HttpStatus.OK).body(testGrpcService.testGrpcService(requestResponseContext));
    }
}
