package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers;

import com.sabre.seats.common.protobuf.ResponseInfo;
import com.sabre.seats.error.protobuf.ErrorMessage;
import com.sabre.seats.error.protobuf.MessageCode;
import com.sabre.seats.seatmapView.protobuf.SeatmapViewRequest;
import com.sabre.seats.seatmapView.protobuf.SeatmapViewResponse;
import com.sabre.seats.seatmapView.protobuf.SeatmapViewServiceGrpc;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;
import org.lognet.springboot.grpc.GRpcService;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@GRpcService
public class MockViewService extends SeatmapViewServiceGrpc.SeatmapViewServiceImplBase {

    @Override
    public void view(SeatmapViewRequest seatmapViewRequest, StreamObserver<SeatmapViewResponse> responseObserver) {

        try {
            if(seatmapViewRequest.getSegmentInfo().getFlightInfo().getAirlineCode().equals("AA")) {
                responseObserver.onNext(buildFailedSeatmapViewResponse(seatmapViewRequest));
            }else{
                responseObserver.onNext(buildSuccessSeatmapViewResponse(seatmapViewRequest));
            }
        } catch(Exception ex){
            responseObserver.onError(Status.UNKNOWN.asRuntimeException());
        } finally {
            responseObserver.onCompleted();
        }
    }

    private SeatmapViewResponse buildSuccessSeatmapViewResponse(SeatmapViewRequest seatmapViewRequest) {
        List<String> executedRules = new ArrayList<>();
        executedRules.add(seatmapViewRequest.getSegmentInfo().getFlightInfo().getAirlineCode()+"::Rule for PRS block::1::MOCK");

        ResponseInfo responseInfoSuccess=ResponseInfo.newBuilder()
                .setResponseStatus(com.sabre.seats.common.protobuf.ResponseStatus.SUCCESS)
                .setReceivedTimestamp(seatmapViewRequest.getRequestInfo().getTimestamp())
                .setResponseTimestamp(Instant.now().toString())
                .build();

        return SeatmapViewResponse.newBuilder()
                .addAllExecutedRules(executedRules)
                .setRequestInfo(seatmapViewRequest.getRequestInfo())
                .setSegmentInfo(seatmapViewRequest.getSegmentInfo())
                .setClientInfo(seatmapViewRequest.getClientInfo())
                .setFlightSeatmap(seatmapViewRequest.getFlightSeatmap())
                .setResponseInfo(responseInfoSuccess)
                .build();
    }

    private SeatmapViewResponse buildFailedSeatmapViewResponse(SeatmapViewRequest seatmapViewRequest) {

        List<MessageCode> messageCodeList = new ArrayList<>();
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("VIEW-2001")
                .setCodeContext("IATAErrorCode").build();
        messageCodeList.add(messageCode);

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setCategory("INTERNAL_SERVER_ERROR")
                .setType("BUSINESS")
                .setDescription(com.sabre.seats.error.protobuf.Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("Carrier Not Offloaded")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build();

        ResponseInfo responseInfoFailure=ResponseInfo.newBuilder()
                .setResponseStatus(com.sabre.seats.common.protobuf.ResponseStatus.FAILED)
                .setReceivedTimestamp(seatmapViewRequest.getRequestInfo().getTimestamp())
                .setResponseTimestamp(Instant.now().toString())
                .addErrorMessages(errorMessage)
                .build();

        return SeatmapViewResponse.newBuilder()
                .setRequestInfo(seatmapViewRequest.getRequestInfo())
                .setSegmentInfo(seatmapViewRequest.getSegmentInfo())
                .setClientInfo(seatmapViewRequest.getClientInfo())
                .setResponseInfo(responseInfoFailure)
                .build();
    }

}
