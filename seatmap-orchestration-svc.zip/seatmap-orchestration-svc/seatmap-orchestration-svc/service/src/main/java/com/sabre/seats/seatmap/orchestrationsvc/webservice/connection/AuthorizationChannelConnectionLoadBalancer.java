package com.sabre.seats.seatmap.orchestrationsvc.webservice.connection;

import io.grpc.ManagedChannel;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

@Component
public class AuthorizationChannelConnectionLoadBalancer {
    private int indexCount=0;
    private final ReentrantLock lock=new ReentrantLock();

    List<ManagedChannel> authorizationChannelList; // create channel list in AuthorizationServiceConfig class

    public ManagedChannel getManagedChannel() {
        lock.lock();
        ManagedChannel channel=null;
        try {
            channel = authorizationChannelList.get(indexCount);
            indexCount++;
            if (indexCount >= authorizationChannelList.size()) {
                indexCount = 0;
            }

        } finally {
            lock.unlock();
        }

        return channel;
    }

}
