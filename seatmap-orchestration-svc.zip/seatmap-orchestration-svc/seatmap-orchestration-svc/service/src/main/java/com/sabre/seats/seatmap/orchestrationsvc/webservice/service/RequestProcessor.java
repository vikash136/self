package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sabre.checkin.jwtdecoder.exception.ESSMKeyNotFoundException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.NoJwtDecoderTypeException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import org.springframework.retry.annotation.Retryable;

public interface RequestProcessor {
    @Retryable(value = ServiceTimeOutException.class, maxAttemptsExpression = "#{${service.retryCount}}")
    void processRequest(WebServiceRequestResponseContext requestResponseContext) throws ESSMKeyNotFoundException, NoJwtDecoderTypeException, ServiceTimeOutException, JsonProcessingException;
}
