package com.sabre.seats.seatmap.orchestrationsvc.webservice.builder;

import com.google.gson.Gson;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.RequestProcessor;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.*;
import com.sabre.seats.common.protobuf.ResponseStatus;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
public class AirSeatMapResponseBuilder implements RequestProcessor {

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    private static final Gson gson = new Gson();

    @Override
    public void processRequest(WebServiceRequestResponseContext requestResponseContext){

        AirSeatMapResponse airSeatMapResponse;

        if (ResponseStatus.SUCCESS.equals(requestResponseContext.getTransformPosResponseToJsonStatus())){
            JsonSEATMAPRESPONSEV1 jsonGetSeatMapResPosV1 = gson.fromJson(requestResponseContext.getSeatmapResponseToPOS(), JsonSEATMAPRESPONSEV1.class);
            airSeatMapResponse = new AirSeatMapResponse ();
            airSeatMapResponse.setSeatmapResponse(jsonGetSeatMapResPosV1);

        } else{
            airSeatMapResponse = getAirSeatMapErrorResponse(requestResponseContext,
                    errorMessageListBuilder.getErrorMessageListForFinalResp(requestResponseContext.getResponseInfo().getErrorMessagesList()));
        }

        requestResponseContext.setAirSeatMapResponse(airSeatMapResponse);
    }

    public AirSeatMapResponse getAirSeatMapErrorResponse(WebServiceRequestResponseContext requestResponseContext, List<ErrorMessage> errorMessageList) {
        JsonSEATMAPRESPONSEV1 jsonGetSeatMapResPosV1 = new JsonSEATMAPRESPONSEV1();
        jsonGetSeatMapResPosV1.setTransactionId(requestResponseContext.getRequestInfo().getTransactionId());
        jsonGetSeatMapResPosV1.setCorrelationId(requestResponseContext.getRequestInfo().getCorrelationId());
        jsonGetSeatMapResPosV1.setVersion(requestResponseContext.getRequestVersion());
        jsonGetSeatMapResPosV1.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
        jsonGetSeatMapResPosV1.setErrorMessages(errorMessageList);

        AirSeatMapResponse airSeatMapResponse = new AirSeatMapResponse();
        airSeatMapResponse.setSeatmapResponse(jsonGetSeatMapResPosV1);
        return airSeatMapResponse;
    }



}
