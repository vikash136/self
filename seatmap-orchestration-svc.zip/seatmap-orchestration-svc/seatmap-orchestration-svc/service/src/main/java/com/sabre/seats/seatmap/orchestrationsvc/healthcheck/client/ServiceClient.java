package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.client;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.health.v1.HealthCheckRequest;
import io.grpc.health.v1.HealthCheckResponse;
import io.grpc.health.v1.HealthGrpc;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class ServiceClient {

    @Value ("${authorizationService.url}")
    private String authorizationServiceUrl;

    @Value ("${authorizationService.port}")
    private int authorizationServicePort;

    @Value ("${authorizationService.callTimeout}")
    private int authorizationServiceCallTimeout;

    @Value("${transformationService.callTimeout}")
    private int transformationServiceCallTimeout;

    @Value("${transformationService.url}")
    private String transformationServiceUrl;

    @Value("${transformationService.port}")
    private int transformationServicePort;

    @Value("${connectivityService.callTimeout}")
    private int connectivityServiceCallTimeout;

    @Value("${connectivityService.url}")
    private String connectivityServiceUrl;

    @Value("${connectivityService.port}")
    private int connectivityServicePort;

    @Value("${viewService.callTimeout}")
    private int viewServiceCallTimeout;

    @Value("${viewService.url}")
    private String viewServiceUrl;

    @Value("${viewService.port}")
    private int viewServicePort;

    private static final String AUTHORIZATION_SERVICE = "authorizationService";
    private static final String TRANSFORMER_SERVICE = "transformerService";
    private static final String CONNECTIVITY_SERVICE = "connectivityService";
    private static final String VIEW_SERVICE = "viewService";

    public String getServiceStatus(String serviceName, Map<String, String> map) {
        log.debug(EscapeUtil.escape("inside getServiceStatus method "));

        try {
            ManagedChannel managedChannel =
                    ManagedChannelBuilder.forAddress(getHealthCheckServiceUrl(serviceName), getHealthCheckServicePort(serviceName)).usePlaintext().build();
            HealthGrpc.HealthBlockingStub healthBlockingStub = HealthGrpc.newBlockingStub(managedChannel);
            HealthCheckResponse healthCheckResponse = healthBlockingStub.withDeadlineAfter(getHealthCheckServiceCallTimeout(serviceName), TimeUnit.MILLISECONDS).check(HealthCheckRequest.newBuilder().build());
            log.info(EscapeUtil.escape("HealthCheckResponse Status for - " + serviceName + " : " + healthCheckResponse.getStatus().name()));
            map.put(serviceName, healthCheckResponse.getStatus().name());
            return healthCheckResponse.getStatus().name();
        } catch(Exception ex) {
            log.error(EscapeUtil.escape("Exception in fetching HealthStatus of service - "+ serviceName + " : " + ex.getMessage()));
            map.put (serviceName,HealthCheckResponse.ServingStatus.UNKNOWN.name ());
            return HealthCheckResponse.ServingStatus.UNKNOWN.name ();
        }
    }

    private String getHealthCheckServiceUrl(String serviceName){
        switch(serviceName) {
            case AUTHORIZATION_SERVICE:
                return authorizationServiceUrl;
            case TRANSFORMER_SERVICE:
                return transformationServiceUrl;
            case CONNECTIVITY_SERVICE:
                return connectivityServiceUrl;
            case VIEW_SERVICE:
                return viewServiceUrl;
            default:
                return "localhost";
        }
    }

    private int getHealthCheckServicePort(String serviceName){
        switch(serviceName) {
            case AUTHORIZATION_SERVICE:
                return authorizationServicePort;
            case TRANSFORMER_SERVICE:
                return transformationServicePort;
            case CONNECTIVITY_SERVICE:
                return connectivityServicePort;
            case VIEW_SERVICE:
                return viewServicePort;
            default:
                return 8090;
        }
    }

    private int getHealthCheckServiceCallTimeout(String serviceName){
        switch(serviceName) {
            case AUTHORIZATION_SERVICE:
                return authorizationServiceCallTimeout;
            case TRANSFORMER_SERVICE:
                return transformationServiceCallTimeout;
            case CONNECTIVITY_SERVICE:
                return connectivityServiceCallTimeout;
            case VIEW_SERVICE:
                return viewServiceCallTimeout;
            default:
                return 5000;
        }
    }
}
