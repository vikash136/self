package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.utility;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@ConfigurationProperties("optional.healthcheck")
@Component
public class OptionalHealthCheckUtil {

    private Map<String, String> optionalHealthCheckMap = new HashMap<> ();

    public Map<String, String> getOptionalHealthCheckMap() {
        return optionalHealthCheckMap;
    }

    public void setOptionalHealthCheckMap(Map<String, String> optionalHealthCheckMap) {
        this.optionalHealthCheckMap = optionalHealthCheckMap;
    }

}
