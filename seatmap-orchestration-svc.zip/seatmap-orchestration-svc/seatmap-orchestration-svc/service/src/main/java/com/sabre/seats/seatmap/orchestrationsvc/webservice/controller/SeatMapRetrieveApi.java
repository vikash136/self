package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller;


import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-08-23T07:49:22.024Z[GMT]")
@Validated
public interface SeatMapRetrieveApi {

    @Operation(summary = "Post Call to retrieve the seatmap", description = "", tags={ "Retrieve Seatmap" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "This code is returned when Partnership is added successfully in database.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AirSeatMapResponse.class))),
        
        @ApiResponse(responseCode = "400", description = "This code is returned when any of the below conditions are true  1. Mandatory fields in the request are not passed in the JSON request  2. Invalid values are provided in request parameters", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AirSeatMapResponse.class))),
        
        @ApiResponse(responseCode = "500", description = "This code is returned when there is an error in processing the request in the server side.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AirSeatMapResponse.class))) })
    @RequestMapping(value = "/seatMapRetrieve/{version}/seats/seatmap",
        produces = { "application/json" }, 
        consumes = { "application/json" }, 
        method = RequestMethod.POST)
    ResponseEntity<AirSeatMapResponse> seatMapRetrieveVersionSeatsSeatmapPost(@Parameter(in = ParameterIn.HEADER, description = "TransactionId for tracking API request" ,required=true,schema=@Schema()) @RequestHeader(value="transactionId", required=true) String transactionId, @Parameter(in = ParameterIn.HEADER, description = "-security-token for authenticating API request" ,required=true,schema=@Schema()) @RequestHeader(value="security-token", required=true) String securityToken, @Parameter(in = ParameterIn.HEADER, description = "correlation-id for tracking API request" ,required=true,schema=@Schema()) @RequestHeader(value="correlation-id", required=true) String correlationId, @Parameter(in = ParameterIn.PATH, description = "version", required=true, schema=@Schema()) @PathVariable("version") String version, @Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody AirSeatMapRequest body);

}

