package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model;

public enum ServiceStatus {

    UP("UP"),
    DOWN("DOWN");

    private String status;

    ServiceStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return this.status;
    }
}
