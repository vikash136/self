package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers;


import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.common.protobuf.MessageFormat;
import com.sabre.seats.common.protobuf.ResponseInfo;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfiguration;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationRequest;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationResponse;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationServiceGrpc;
import com.sabre.seats.error.protobuf.Description;
import com.sabre.seats.error.protobuf.ErrorMessage;
import com.sabre.seats.error.protobuf.MessageCode;

import com.sabre.seats.transformation.protobuf.MessageType;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;
import lombok.extern.slf4j.Slf4j;
import org.lognet.springboot.grpc.GRpcService;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@GRpcService
public class MockConectivityService extends ConnectivityConfigurationServiceGrpc.ConnectivityConfigurationServiceImplBase {

    @Override
    public void getConnectivityConfiguration(ConnectivityConfigurationRequest request, StreamObserver<ConnectivityConfigurationResponse> responseObserver) {
        ConnectivityConfigurationResponse connectivityConfigurationResponse = null;
        try {

            if ("EY".equals(request.getSupplier())) {
                List<MessageCode> messageCodeList = new ArrayList<>();
                MessageCode messageCode =  MessageCode.newBuilder()
                        .setCode("CONN-2001")
                        .setCodeContext("IATAErrorCode").build();
                messageCodeList.add(messageCode);
                var errorMessage = ErrorMessage.newBuilder()
                        .setCategory("INTERNAL_SERVER_ERROR")
                        .setType("BUSINESS")
                        .setDescription(Description.newBuilder()
                                .setLang("UTF-11111")
                                .setMessage("Connectivity Configuration not active")
                                .build())
                        .addAllErrorCode(messageCodeList)
                        .build();

                var responseInfoFailure = ResponseInfo.newBuilder()
                        .setResponseStatus(ResponseStatus.FAILED)
                        .setReceivedTimestamp(request.getRequestInfo().getTimestamp())
                        .setResponseTimestamp(Instant.now().toString())
                        .addErrorMessages(errorMessage)
                        .build();

                connectivityConfigurationResponse = ConnectivityConfigurationResponse.newBuilder()
                        .setSeatAction(request.getSeatAction())
                        .setSupplier(request.getSupplier())
                        .setSupplierType(request.getSupplierType())
                        .setResponseInfo(responseInfoFailure)
                        .build();
            } else if ("MN".equals(request.getSupplier())) {
                var connectivityConfiguration = ConnectivityConfiguration.newBuilder()
                        .setMessageFormat(MessageFormat.ATB)
                        .setMessageRequestType(MessageType.SMPREQ)
                        .setMessageResponseType(MessageType.SMPRES)
                        .setApiVersion("1")
                        .setPlatform("TPF")
                        .setConnectivityType("http")
                        .setConnectivityDestination("http://localhost:8080/tpf/mock")
                        .build();

                var responseInfoSuccess = ResponseInfo.newBuilder()
                        .setResponseStatus(ResponseStatus.SUCCESS)
                        .setReceivedTimestamp(request.getRequestInfo().getTimestamp())
                        .setResponseTimestamp(Instant.now().toString())
                        .build();

                connectivityConfigurationResponse = ConnectivityConfigurationResponse.newBuilder()
                        .setSeatAction(request.getSeatAction())
                        .setSupplier(request.getSupplier())
                        .setSupplierType(request.getSupplierType())
                        .setResponseInfo(responseInfoSuccess)
                        .setConnectivityConfiguration(connectivityConfiguration)
                        .build();

            } else {
                var connectivityConfiguration = ConnectivityConfiguration.newBuilder()
                        .setMessageFormat(MessageFormat.JSON)
                        .setMessageRequestType(MessageType.SEAT_MAP_CORE_REQUEST)
                        .setMessageResponseType(MessageType.SEAT_MAP_CORE_RESPONSE)
                        .setApiVersion("1")
                        .setConnectivityType("Mock Connection")
                        .setConnectivityDestination("http://localhost:8080/v1/seatscore/seatmap")
                        .build();

                var responseInfoSuccess = ResponseInfo.newBuilder()
                        .setResponseStatus(ResponseStatus.SUCCESS)
                        .setReceivedTimestamp(request.getRequestInfo().getTimestamp())
                        .setResponseTimestamp(Instant.now().toString())
                        .build();

                connectivityConfigurationResponse = ConnectivityConfigurationResponse.newBuilder()
                        .setSeatAction(request.getSeatAction())
                        .setSupplier(request.getSupplier())
                        .setSupplierType(request.getSupplierType())
                        .setResponseInfo(responseInfoSuccess)
                        .setConnectivityConfiguration(connectivityConfiguration)
                        .build();

            }
            responseObserver.onNext(connectivityConfigurationResponse);
            responseObserver.onCompleted();
        } catch (Exception e) {
            log.error(EscapeUtil.escape("MockConectivityService Error :: " + e));
            responseObserver.onError(Status.UNKNOWN.asRuntimeException());
        }

    }

}
