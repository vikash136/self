package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.client.ServiceClient;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.common.protobuf.SegmentResponse;
import com.sabre.seats.seatmapView.protobuf.SeatmapViewRequest;
import com.sabre.seats.seatmapView.protobuf.SeatmapViewResponse;
import com.sabre.seats.seatmapView.protobuf.SeatmapViewServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.StatusRuntimeException;
import io.grpc.health.v1.HealthCheckResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class ViewService implements FlightItemProcessor {

    @Value("${grpcService.callTimeout}")
    private int viewServiceCallTimeout;

    @Value("${viewService.version}")
    private String viewServiceVersion;

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    @Qualifier("viewServiceChannel")
    ManagedChannel viewServiceChannel;

    @Autowired
    private ServiceClient serviceClient;

    @Autowired
    private ServiceHealthCheckStore serviceHealthCheckStore;

    private static final String VIEW_SERVICE = "viewService";
    private final Map<String, String> optionalServicesStatusMap = new HashMap<>();


    @Override
    public void processFlightItem(WebServiceRequestResponseContext requestResponseContext, int segmentId) throws ServiceTimeOutException {
        SeatmapViewResponse seatmapViewResponse = null;

        var flightItemReqResContext=requestResponseContext.getFlightItemReqResContextMap().get(segmentId);

        if(ResponseStatus.SUCCESS.equals(flightItemReqResContext.getTransformSupplierResponseStatus())
                && ResponseStatus.SUCCESS.equals(flightItemReqResContext.getSegmentResponse().getResponseInfo().getResponseStatus())
                && !CollectionUtils.isEmpty(flightItemReqResContext.getSegmentResponse().getFlightSeatmap().getSeatmapList())
                && !ResponseStatus.NOT_OFFLOADED.equals(flightItemReqResContext.getAuthorizationResponseStatus())){

            if(serviceClient.getServiceStatus(VIEW_SERVICE, optionalServicesStatusMap).equals(HealthCheckResponse.ServingStatus.NOT_SERVING.name())){
                log.warn(EscapeUtil.escape("View service  is not serving: {}" + HealthCheckResponse.ServingStatus.NOT_SERVING));
                seatmapViewResponse = getSeatMapViewWarningResponse(flightItemReqResContext);
                validateResponse(flightItemReqResContext, seatmapViewResponse);
            } else{
                getSeatmapViewResponse(requestResponseContext, flightItemReqResContext);
            }

        }

    }

    private void getSeatmapViewResponse(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) throws ServiceTimeOutException {
        log.info(EscapeUtil.escape("Inside getSeatmapViewResponse method"));
        SeatmapViewResponse seatmapViewResponse=null;
        try{
            SeatmapViewServiceGrpc.SeatmapViewServiceBlockingStub viewServiceBlockingStub=SeatmapViewServiceGrpc
                    .newBlockingStub(viewServiceChannel)
                    .withDeadlineAfter(viewServiceCallTimeout, TimeUnit.MILLISECONDS);

            var seatmapViewRequest = SeatmapViewRequest.newBuilder()
                    .setSupplierCode(flightItemReqResContext.getSupplier().getAirlineCode())
                    .setRequestInfo(requestResponseContext.getRequestInfo())
                    .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                    .setClientInfo(requestResponseContext.getClientInfo())
                    .setFlightSeatmap(flightItemReqResContext.getSegmentResponse().getFlightSeatmap())
                    .addAllPassengers(flightItemReqResContext.getPassengerSeatmapRetrieveRequestList())
                    .build();

            log.debug(EscapeUtil.escape("seatmapViewRequest: {}" + seatmapViewRequest));
            seatmapViewResponse = getResponseFromViewService(viewServiceBlockingStub,seatmapViewRequest);
            log.debug(EscapeUtil.escape("seatmapViewResponse: {}" + seatmapViewResponse));

        }catch (StatusRuntimeException sre) {
            log.error(EscapeUtil.escape("StatusRuntimeException connecting to viewService :: " + sre));
            serviceHealthCheckStore.updateOptionalServiceHealthStatus (optionalServicesStatusMap);
            seatmapViewResponse = getSeatMapViewWarningResponse(flightItemReqResContext);

        } catch (Exception ex) {
            log.error(EscapeUtil.escape("Exception connecting to viewService :: " + ex));

        } finally {
            validateResponse(flightItemReqResContext,seatmapViewResponse);
        }
    }

    SeatmapViewResponse getResponseFromViewService(SeatmapViewServiceGrpc.SeatmapViewServiceBlockingStub viewServiceBlockingStub, SeatmapViewRequest seatmapViewRequest){
        return viewServiceBlockingStub.view(seatmapViewRequest);
    }

    private void validateResponse(FlightItemReqResContext flightItemReqResContext, SeatmapViewResponse seatmapViewResponse) {

        if(null==seatmapViewResponse){
            seatmapViewResponse = errorMessageListBuilder.getSeatmapViewExceptionResponse("UnknownGenericException");
        }

        flightItemReqResContext.setSeatmapViewResponse(seatmapViewResponse);
        flightItemReqResContext.setViewResponseStatus(seatmapViewResponse.getResponseInfo().getResponseStatus());

        SegmentResponse segmentResponse;

        if(ResponseStatus.SUCCESS.equals(flightItemReqResContext.getViewResponseStatus())){
            segmentResponse=SegmentResponse.newBuilder()
                    .setResponseInfo(seatmapViewResponse.getResponseInfo())
                    .setSegmentInfo(seatmapViewResponse.getSegmentInfo())
                    .setFlightSeatmap(seatmapViewResponse.getFlightSeatmap()).build();

        } else{
            segmentResponse=SegmentResponse.newBuilder()
                    .setResponseInfo(seatmapViewResponse.getResponseInfo())
                    .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                    .build();
        }

        flightItemReqResContext.setSegmentResponse(segmentResponse);

    }

    public int getViewServiceCallTimeout() {
        return viewServiceCallTimeout;
    }

    public void setViewServiceCallTimeout(int viewServiceCallTimeout) {
        this.viewServiceCallTimeout = viewServiceCallTimeout;
    }

    private SeatmapViewResponse getSeatMapViewWarningResponse(FlightItemReqResContext flightItemReqResContext) {

        var responseInfo=errorMessageListBuilder.getWarningResponseInfo("ViewServiceTimeOutException");

        return  SeatmapViewResponse.newBuilder()
                .setResponseInfo(responseInfo)
                .setSegmentInfo(flightItemReqResContext.getSegmentResponse().getSegmentInfo())
                .setFlightSeatmap(flightItemReqResContext.getSegmentResponse().getFlightSeatmap())
                .build();
    }

}
