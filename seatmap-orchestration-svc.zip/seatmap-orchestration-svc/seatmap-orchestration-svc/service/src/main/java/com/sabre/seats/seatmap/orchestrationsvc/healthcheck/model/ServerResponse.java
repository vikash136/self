package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model;

public enum ServerResponse {

    SERVING("SERVING"),
    NOT_SERVING("NOT_SERVING"),
    UNKNOWN("UNKNOWN");

    private String serverRes;

    ServerResponse(String serverResponse) {
        this.serverRes = serverResponse;
    }

    public String getServerResponse() {
        return this.serverRes;
    }
}
