package com.sabre.seats.seatmap.orchestrationsvc.webservice.converter;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.sabre.checkin.jwtdecoder.model.JWTDecodedData;
import com.sabre.seats.common.protobuf.RequesterType;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.Payload;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ChannelIdUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.common.protobuf.ClientInfo;
import com.sabre.seats.common.protobuf.SupplierType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
public class JwtDecodedDataToClientInfo {

    private static final Gson gson = new Gson();

    @Autowired
    private ChannelIdUtil channelMapUtil;

    public ClientInfo convertJwtDecodedDataToClientInfo(Optional<JWTDecodedData> jwtDecodedData,Optional<JWTDecodedData> tjrDecodedData) {
        ClientInfo.Builder clientInfoBuilder = ClientInfo.newBuilder();
        if (jwtDecodedData.isPresent()) {
            try {
                Payload jwtPayload = gson.fromJson(jwtDecodedData.get().getPayload(), Payload.class);
                log.info(EscapeUtil.escape("JWTDecodedData-Payload received" + jwtPayload));
                clientInfoBuilder
                        .setRequester( Objects.requireNonNullElse(jwtPayload.getCurrentPrimeHost(), ""))
                        .setAgencyCode( Objects.requireNonNullElse(jwtPayload.getGroup(), ""))
                        .setPseudoCityCode( Objects.requireNonNullElse(jwtPayload.getHomeCity(), ""))
                        .setAgentCityCode( Objects.requireNonNullElse(jwtPayload.getHomeCity(), ""))
                        .setCountryCode( Objects.requireNonNullElse(jwtPayload.getCountryCode(), ""))
                        .setCurrencyCode( Objects.requireNonNullElse(jwtPayload.getDefaultCurrency(), ""))
                        .setIataNumber( Objects.requireNonNullElse(getIataNumber(jwtPayload.getIataNumber()), ""))
                        .setSupplierType(SupplierType.AIR)
                        .setRequesterType(RequesterType.forNumber(channelMapUtil.getRequesterIds().contains(jwtPayload.getCurrentPrimeHost())  && !jwtPayload.getCurrentPrimeHost().equals("**") ? RequesterType.GDS.getNumber():RequesterType.AIRLINE.getNumber()))
                        .setLniata("F2C906")
                        .setLockId("Z1234567")
                        .setAgentSign(Objects.requireNonNullElse(jwtPayload.getAgentSign(), ""))
                        .addAllEprKeywords(null == jwtPayload.getKeywords() ? new ArrayList<>() : jwtPayload.getKeywords()).build();
            } catch (JsonSyntaxException jse) {
                log.error(EscapeUtil.escape("Can't deserialize ESSM Public Keys. Exception: {}" + jse.getMessage()));
                throw jse;
            }
        }

        return clientInfoBuilder.setClientContext("WebService").build();
    }

    private String getIataNumber(String iataNumber) {
        if(null != iataNumber && StringUtils.isNotEmpty(iataNumber) && StringUtils.length(iataNumber) < 8) {
            iataNumber = iataNumber + Math.floorMod(Integer.valueOf(iataNumber), 7);
        }
        return iataNumber;
    }
}
