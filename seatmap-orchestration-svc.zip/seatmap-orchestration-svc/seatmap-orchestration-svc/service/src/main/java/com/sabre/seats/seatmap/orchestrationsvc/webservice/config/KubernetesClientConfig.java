package com.sabre.seats.seatmap.orchestrationsvc.webservice.config;

import com.marcnuri.yakc.KubernetesClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KubernetesClientConfig {
    public static final String DUMMY_KUBERNETES_SERVER = "http://dummy-server";
    public static final String DUMMY_KUBERNETES_NAMESPACE = "dummy-namespace";

    @Bean(destroyMethod = "close", name = "kubernetesClient")
    public KubernetesClient kubernetesClient() {
        try{
            return new KubernetesClient();
        }catch(Exception e){
            return new KubernetesClient(com.marcnuri.yakc.config.Configuration.builder()
                    .server(DUMMY_KUBERNETES_SERVER)
                    .namespace(DUMMY_KUBERNETES_NAMESPACE)
                    .build());
        }
    }

}