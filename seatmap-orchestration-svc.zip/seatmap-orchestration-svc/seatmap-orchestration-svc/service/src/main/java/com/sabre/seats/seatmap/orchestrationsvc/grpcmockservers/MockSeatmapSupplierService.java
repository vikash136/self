package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Map;

@Slf4j
@RestController
public class MockSeatmapSupplierService {

    private static String successResponse ="{\"version\":\"1\",\"transactionId\":\"<TRANSACTION_ID>\",\"correlationId\":\"<CORRELATION_ID>\",\"requestDateTime\":\"<REQUEST_DATETIME>\",\"responseDateTime\":\"<RESPONSE_DATETIME>\",\"status\":200,\"warningMessages\":[],\"flightInfo\":{\"airlineCode\":\"<AIRLINE_CODE>\",\"flightNumber\":\"<FLIGHT_NUMBER>\",\"reservationBookingDesignator\":\"Y\",\"scheduleDepartureDate\":\"<DEPARTURE_DATE>\",\"departureAirportCode\":\"<DEPARTURE_AIRPORT_CODE>\",\"arrivalAirportCode\":\"<ARRIVAL_AIRPORT_CODE>\"},\"seatmaps\":[{\"departureAirportCode\":\"<DEPARTURE_AIRPORT_CODE>\",\"arrivalAirportCode\":\"<ARRIVAL_AIRPORT_CODE>\",\"iataConfigurationCode\":\"<FLIGHT_NUMBER>\",\"physicalAircraftName\":\"TEST\",\"physicalAircraftDescription\":\"TESTED\",\"cabinJumpSeatCount\":\"5\",\"cockpitJumpSeatCount\":\"2\",\"isAnimalAllowed\":true,\"isSmoking\":false,\"scheduleDepartureDateTime\":\"<DEPARTURE_DATE>\",\"scheduleArrivalDateTime\":\"<ARRIVAL_DATE>\",\"cabins\":[{\"seatRows\":[{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"}],\"rowNumber\":\"8\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"9\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"10\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"11\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"12\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"13\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"14\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"W\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window-BulkHead  \",\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"LS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"K\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisel-BulkHead\",\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"K\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisel-BulkHead\",\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"RS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"W\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window-BulkHead  \",\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"15\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"16\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"17\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"18\",\"rowCharacteristics\":[]}],\"cabinLayout\":{\"cabinCode\":\"Y\",\"cabinNumber\":\"2\",\"facilities\":[],\"firstRow\":\"8\",\"cabinCodeDescription\":\"ECONOMY\",\"lastRow\":\"18\",\"seatCount\":61,\"missingRowNumbers\":[],\"seatAlphabetList\":[{\"columnCode\":\"A\",\"position\":\"W\"},{\"columnCode\":\"B\",\"position\":\"9\"},{\"columnCode\":\"C\",\"position\":\"A\"},{\"columnCode\":\"D\",\"position\":\"A\"},{\"columnCode\":\"E\",\"position\":\"9\"},{\"columnCode\":\"F\",\"position\":\"W\"}],\"missingSeatList\":[]}}]}]}";
    private static String failedResponse ="{\"version\":\"1\",\"transactionId\":\"<TRANSACTION_ID>\",\"correlationId\":\"<CORRELATION_ID>\",\"requestDateTime\":\"<REQUEST_DATETIME>\",\"responseDateTime\":\"<RESPONSE_DATETIME>\",\"status\":500,\"errorMessages\":[   {\"code\":\"\",\"descText\":\"Seatmap re-detailing in progress\",\"errorId\":\"SMS-2003\",\"type\":\"BUSINESS\"   }],\"warningMessages\":[   ]}";

    private static String tpfSuccesResponse = "{\"correlationId\" : \"<CORRELATION_ID>\",\"transactionId\" : \"<TRANSACTION_ID>\",\r\n\"responseCode\":200, \r\n\"responseCodeText\":\"Success\", \r\n\"responseDataLst\":\r\n{\r\n\"payloadLength\":\"<PAY_LOAD_LENGTH>\",\"payloadName\" : \"SMPRES\",\r\n\"payload\":\"<PAY_LOAD>\"\r\n}\r\n}";

    private static String successResponseWithTwoSeatmaps ="{\n" +
            "    \"version\": \"1\",\n" +
            "    \"transactionId\": \"<TRANSACTION_ID>\",\n" +
            "    \"correlationId\": \"<CORRELATION_ID>\",\n" +
            "    \"requestDateTime\": \"<REQUEST_DATETIME>\",\n" +
            "    \"responseDateTime\": \"<RESPONSE_DATETIME>\",\n" +
            "    \"status\": 200,\n" +
            "    \"warningMessages\": [],\n" +
            "    \"flightInfo\": {\n" +
            "        \"airlineCode\": \"<AIRLINE_CODE>\",\n" +
            "        \"flightNumber\": \"<FLIGHT_NUMBER>\",\n" +
            "        \"reservationBookingDesignator\": \"Y\",\n" +
            "        \"scheduleDepartureDate\": \"<DEPARTURE_DATE>\",\n" +
            "        \"departureAirportCode\": \"<DEPARTURE_AIRPORT_CODE>\",\n" +
            "        \"arrivalAirportCode\": \"<ARRIVAL_AIRPORT_CODE>\"\n" +
            "    },\n" +
            "    \"seatmaps\": [\n" +
            "        {\n" +
            "            \"departureAirportCode\": \"<DEPARTURE_AIRPORT_CODE>\",\n" +
            "            \"arrivalAirportCode\": \"NGO\",\n" +
            "            \"iataConfigurationCode\": \"319\",\n" +
            "            \"physicalAircraftName\": \"325\",\n" +
            "            \"physicalAircraftDescription\": \"TESTED\",\n" +
            "            \"cabinJumpSeatCount\": \"5\",\n" +
            "            \"cockpitJumpSeatCount\": \"2\",\n" +
            "            \"isAnimalAllowed\": false,\n" +
            "            \"isSmoking\": false,\n" +
            "            \"scheduleDepartureDateTime\": \"2021-06-14T01:50:00Z\",\n" +
            "            \"scheduleArrivalDateTime\": \"2021-06-14T04:50:00Z\",\n" +
            "            \"cabins\": [\n" +
            "                {\n" +
            "                    \"seatRows\": [\n" +
            "                        {\n" +
            "                            \"oxygenMasks\": [\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 0,\n" +
            "                                    \"section\": \"L\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 0,\n" +
            "                                    \"section\": \"R\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"seats\": [\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\"\n" +
            "                                         \n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"A\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"LS\"\n" +
            "                                            \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"B\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\"\n" +
            "                                              \n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"RKENG\"\n" +
            "                                                \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"C\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\"\n" +
            "                                               \n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"RKENG\"\n" +
            "                                               \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"D\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"RS\"\n" +
            "                                               \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"E\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\"\n" +
            "                                               \n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"F\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"rowNumber\": \"6\",\n" +
            "                            \"rowCharacteristics\": []\n" +
            "                        }   \n" +
            "                    ],\n" +
            "                    \"cabinLayout\": {\n" +
            "                        \"cabinCode\": \"Y\",\n" +
            "                        \"cabinNumber\": \"2\",\n" +
            "                        \"facilities\": [\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"25\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\",\n" +
            "                                        \"F\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"B\",\n" +
            "                                    \"beginRow\": \"25\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"LA\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"25\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"B\",\n" +
            "                                        \"E\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"B\",\n" +
            "                                    \"beginRow\": \"25\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"G\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"firstRow\": \"6\",\n" +
            "                        \"cabinCodeDescription\": \"ECONOMY\",\n" +
            "                        \"lastRow\": \"25\",\n" +
            "                        \"seatCount\": 120,\n" +
            "                        \"missingRowNumbers\": [],\n" +
            "                        \"seatAlphabetList\": [\n" +
            "                            {\n" +
            "                                \"columnCode\": \"A\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"B\",\n" +
            "                                \"position\": \"9\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"C\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"D\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"E\",\n" +
            "                                \"position\": \"9\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"F\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"missingSeatList\": []\n" +
            "                    }\n" +
            "                }\n" +
            "            ]\n" +
            "        },\n" +
            "        {\n" +
            "            \"departureAirportCode\": \"NGO\",\n" +
            "            \"arrivalAirportCode\": \"<ARRIVAL_AIRPORT_CODE>\",\n" +
            "            \"iataConfigurationCode\": \"CRJ\",\n" +
            "            \"physicalAircraftName\": \"SRJ\",\n" +
            "            \"physicalAircraftDescription\": \"TEST\",\n" +
            "            \"cabinJumpSeatCount\": \"5\",\n" +
            "            \"cockpitJumpSeatCount\": \"2\",\n" +
            "            \"isAnimalAllowed\": true,\n" +
            "            \"isSmoking\": false,\n" +
            "            \"scheduleDepartureDateTime\": \"2021-06-14T05:30:00Z\",\n" +
            "            \"scheduleArrivalDateTime\": \"2021-06-14T19:30:00Z\",\n" +
            "            \"cabins\": [\n" +
            "                {\n" +
            "                    \"seatRows\": [\n" +
            "                        {\n" +
            "                            \"oxygenMasks\": [\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 0,\n" +
            "                                    \"section\": \"L\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 0,\n" +
            "                                    \"section\": \"R\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"seats\": [\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\",\n" +
            "                                                \"LS\",\n" +
            "                                                \"14\",\n" +
            "                                                \"B\",\n" +
            "                                                \"O\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"A\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\",\n" +
            "                                                \"LS\",\n" +
            "                                                \"14\",\n" +
            "                                                \"B\",\n" +
            "                                                \"O\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Aisle-Bassinet\",\n" +
            "                                                \"Aisle Bassinet\",\n" +
            "                                                \"RKENG\",\n" +
            "                                                \"VUEBN\",\n" +
            "                                                \"NYIFW\",\n" +
            "                                                \"PRCAD\",\n" +
            "                                                \"SGQDO\",\n" +
            "                                                \"VDGGL\",\n" +
            "                                                \"ODOMG\",\n" +
            "                                                \"OSPMV\",\n" +
            "                                                \"Aisle BulkHead updated\",\n" +
            "                                                \"Aisle seat Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"B\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\",\n" +
            "                                                \"RS\",\n" +
            "                                                \"14\",\n" +
            "                                                \"B\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"O\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Aisle-Bassinet\",\n" +
            "                                                \"Aisle Bassinet\",\n" +
            "                                                \"RKENG\",\n" +
            "                                                \"VUEBN\",\n" +
            "                                                \"NYIFW\",\n" +
            "                                                \"PRCAD\",\n" +
            "                                                \"SGQDO\",\n" +
            "                                                \"VDGGL\",\n" +
            "                                                \"ODOMG\",\n" +
            "                                                \"OSPMV\",\n" +
            "                                                \"Aisle BulkHead updated\",\n" +
            "                                                \"Aisle seat Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"C\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\",\n" +
            "                                                \"RS\",\n" +
            "                                                \"14\",\n" +
            "                                                \"B\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"O\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"D\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"rowNumber\": \"1\",\n" +
            "                            \"rowCharacteristics\": []\n" +
            "                        }\n" +
            "                    ],\n" +
            "                    \"cabinLayout\": {\n" +
            "                        \"cabinCode\": \"Y\",\n" +
            "                        \"cabinNumber\": \"1\",\n" +
            "                        \"facilities\": [\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\",\n" +
            "                                        \"B\",\n" +
            "                                        \"C\",\n" +
            "                                        \"D\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"D\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"C\",\n" +
            "                                        \"D\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"G\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"12\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"C\",\n" +
            "                                        \"D\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"B\",\n" +
            "                                    \"beginRow\": \"12\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"LA\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"firstRow\": \"1\",\n" +
            "                        \"cabinCodeDescription\": \"BUSINESS\",\n" +
            "                        \"lastRow\": \"13\",\n" +
            "                        \"seatCount\": 52,\n" +
            "                        \"missingRowNumbers\": [],\n" +
            "                        \"seatAlphabetList\": [\n" +
            "                            {\n" +
            "                                \"columnCode\": \"A\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"B\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"C\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"D\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"missingSeatList\": []\n" +
            "                    }\n" +
            "                }\n" +
            "            ],\n" +
            "            \"changeofGaugeInd\": true\n" +
            "        }\n" +
            "    ]\n" +
            "}";
    private static String successResponseWithThreeSeatmaps ="{\n" +
            "    \"version\": \"1\",\n" +
            "    \"transactionId\": \"<TRANSACTION_ID>\",\n" +
            "    \"correlationId\": \"<CORRELATION_ID>\",\n" +
            "    \"requestDateTime\": \"<REQUEST_DATETIME>\",\n" +
            "    \"responseDateTime\": \"<RESPONSE_DATETIME>\",\n" +
            "    \"status\": 200,\n" +
            "    \"warningMessages\": [],\n" +
            "    \"flightInfo\": {\n" +
            "        \"airlineCode\": \"<AIRLINE_CODE>\",\n" +
            "        \"flightNumber\": \"<FLIGHT_NUMBER>\",\n" +
            "        \"reservationBookingDesignator\": \"F\",\n" +
            "        \"scheduleDepartureDate\": \"<DEPARTURE_DATE>\",\n" +
            "        \"departureAirportCode\": \"<DEPARTURE_AIRPORT_CODE>\",\n" +
            "        \"arrivalAirportCode\": \"<ARRIVAL_AIRPORT_CODE>\"\n" +
            "    },\n" +
            "    \"seatmaps\": [\n" +
            "        {\n" +
            "            \"departureAirportCode\": \"<DEPARTURE_AIRPORT_CODE>\",\n" +
            "            \"arrivalAirportCode\": \"DFW\",\n" +
            "            \"iataConfigurationCode\": \"343\",\n" +
            "            \"physicalAircraftName\": \"AUT\",\n" +
            "            \"physicalAircraftDescription\": \"Boeing 737-200 Passenger\",\n" +
            "            \"cabinJumpSeatCount\": \"1\",\n" +
            "            \"cockpitJumpSeatCount\": \"6\",\n" +
            "            \"isAnimalAllowed\": true,\n" +
            "            \"isSmoking\": false,\n" +
            "            \"scheduleDepartureDateTime\": \"2021-06-11T04:00:00Z\",\n" +
            "            \"scheduleArrivalDateTime\": \"2021-06-11T04:30:00Z\",\n" +
            "            \"cabins\": [\n" +
            "                {\n" +
            "                    \"seatRows\": [\n" +
            "                        {\n" +
            "                            \"oxygenMasks\": [\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 3,\n" +
            "                                    \"section\": \"L\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 3,\n" +
            "                                    \"section\": \"R\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"seats\": [\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\",\n" +
            "                                                \"K\",\n" +
            "                                                \"H\",\n" +
            "                                                \"Q\",\n" +
            "                                                \"C\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window-BulkHead  \",\n" +
            "                                                \"Window\",\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"A\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Aisel-BulkHead\"\n" +
            "                                                \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"B\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Aisel-BulkHead\",\n" +
            "                                                \"Aisle seat\"\n" +
            "                                             \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"E\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window-BulkHead  \",\n" +
            "                                                \"Window\",\n" +
            "                                                \"QAAdminTestin1\",\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"F\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"rowNumber\": \"1\",\n" +
            "                            \"rowCharacteristics\": []\n" +
            "                        }\n" +
            "                    ],\n" +
            "                    \"cabinLayout\": {\n" +
            "                        \"cabinCode\": \"F\",\n" +
            "                        \"cabinNumber\": \"1\",\n" +
            "                        \"facilities\": [\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\",\n" +
            "                                        \"B\",\n" +
            "                                        \"E\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"D\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"700\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"F\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"G\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"CL\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"firstRow\": \"1\",\n" +
            "                        \"cabinCodeDescription\": \"FIRST\",\n" +
            "                        \"lastRow\": \"4\",\n" +
            "                        \"seatCount\": 16,\n" +
            "                        \"missingRowNumbers\": [],\n" +
            "                        \"seatAlphabetList\": [\n" +
            "                            {\n" +
            "                                \"columnCode\": \"A\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"B\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"E\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"F\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"missingSeatList\": []\n" +
            "                    }\n" +
            "                }\n" +
            "            ]\n" +
            "        },\n" +
            "        {\n" +
            "            \"departureAirportCode\": \"DFW\",\n" +
            "            \"arrivalAirportCode\": \"SAT\",\n" +
            "            \"iataConfigurationCode\": \"344\",\n" +
            "            \"physicalAircraftName\": \"AUU\",\n" +
            "            \"physicalAircraftDescription\": \"Boeing 737-200 Passenger\",\n" +
            "            \"cabinJumpSeatCount\": \"1\",\n" +
            "            \"cockpitJumpSeatCount\": \"6\",\n" +
            "            \"isAnimalAllowed\": true,\n" +
            "            \"isSmoking\": false,\n" +
            "            \"scheduleDepartureDateTime\": \"2021-06-11T08:00:00Z\",\n" +
            "            \"scheduleArrivalDateTime\": \"2021-06-11T08:30:00Z\",\n" +
            "            \"cabins\": [\n" +
            "                {\n" +
            "                    \"seatRows\": [\n" +
            "                        {\n" +
            "                            \"oxygenMasks\": [\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 3,\n" +
            "                                    \"section\": \"L\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 3,\n" +
            "                                    \"section\": \"R\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"seats\": [\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\",\n" +
            "                                                \"K\",\n" +
            "                                                \"H\",\n" +
            "                                                \"Q\",\n" +
            "                                                \"C\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window-BulkHead  \",\n" +
            "                                                \"Window\",\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"A\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Aisel-BulkHead\",\n" +
            "                                                \"Aisle seat\"\n" +
            "                                              \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"B\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Aisel-BulkHead\",\n" +
            "                                                \"Aisle seat\"\n" +
            "                                            \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"E\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window-BulkHead  \",\n" +
            "                                                \"Window\",\n" +
            "                                                \"QAAdminTestin1\",\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"F\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"rowNumber\": \"1\",\n" +
            "                            \"rowCharacteristics\": []\n" +
            "                        }\n" +
            "                    ],\n" +
            "                    \"cabinLayout\": {\n" +
            "                        \"cabinCode\": \"F\",\n" +
            "                        \"cabinNumber\": \"1\",\n" +
            "                        \"facilities\": [\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\",\n" +
            "                                        \"B\",\n" +
            "                                        \"E\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"D\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"700\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"F\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"G\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"CL\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"firstRow\": \"1\",\n" +
            "                        \"cabinCodeDescription\": \"FIRST\",\n" +
            "                        \"lastRow\": \"4\",\n" +
            "                        \"seatCount\": 16,\n" +
            "                        \"missingRowNumbers\": [],\n" +
            "                        \"seatAlphabetList\": [\n" +
            "                            {\n" +
            "                                \"columnCode\": \"A\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"B\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"E\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"F\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"missingSeatList\": []\n" +
            "                    }\n" +
            "                }\n" +
            "            ],\n" +
            "            \"changeofGaugeInd\": true\n" +
            "        },\n" +
            "        {\n" +
            "            \"departureAirportCode\": \"SAT\",\n" +
            "            \"arrivalAirportCode\": \"<ARRIVAL_AIRPORT_CODE>\",\n" +
            "            \"iataConfigurationCode\": \"345\",\n" +
            "            \"physicalAircraftName\": \"AUV\",\n" +
            "            \"physicalAircraftDescription\": \"Boeing 737-200 Passenger\",\n" +
            "            \"cabinJumpSeatCount\": \"1\",\n" +
            "            \"cockpitJumpSeatCount\": \"6\",\n" +
            "            \"isAnimalAllowed\": true,\n" +
            "            \"isSmoking\": false,\n" +
            "            \"scheduleDepartureDateTime\": \"2021-06-11T10:00:00Z\",\n" +
            "            \"scheduleArrivalDateTime\": \"2021-06-11T12:30:00Z\",\n" +
            "            \"cabins\": [\n" +
            "                {\n" +
            "                    \"seatRows\": [\n" +
            "                        {\n" +
            "                            \"oxygenMasks\": [\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 3,\n" +
            "                                    \"section\": \"L\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"additionalMaskCount\": 3,\n" +
            "                                    \"section\": \"R\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"seats\": [\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\",\n" +
            "                                                \"K\",\n" +
            "                                                \"H\",\n" +
            "                                                \"Q\",\n" +
            "                                                \"C\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window-BulkHead  \",\n" +
            "                                                \"Window\",\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"A\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Aisel-BulkHead\",\n" +
            "                                                \"Aisle seat\",\n" +
            "                                                \"RKENG\"\n" +
            "                                            \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"B\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"A\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Aisel-BulkHead\",\n" +
            "                                                \"Aisle seat\"\n" +
            "                                               \n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"E\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"characteristics\": [\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"W\",\n" +
            "                                                \"1A\",\n" +
            "                                                \"1B\",\n" +
            "                                                \"K\"\n" +
            "                                            ]\n" +
            "                                        },\n" +
            "                                        {\n" +
            "                                            \"codeContext\": \"SEATS_PADIS_GROUPING\",\n" +
            "                                            \"codes\": [\n" +
            "                                                \"Window-BulkHead  \",\n" +
            "                                                \"Window\",\n" +
            "                                                \"QAAdminTestin1\",\n" +
            "                                                \"Window Updated\"\n" +
            "                                            ]\n" +
            "                                        }\n" +
            "                                    ],\n" +
            "                                    \"columnCode\": \"F\",\n" +
            "                                    \"seatStatus\": \"F\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"rowNumber\": \"1\",\n" +
            "                            \"rowCharacteristics\": []\n" +
            "                        }\n" +
            "\t\t\t\t\t\t],\n" +
            "                    \"cabinLayout\": {\n" +
            "                        \"cabinCode\": \"F\",\n" +
            "                        \"cabinNumber\": \"1\",\n" +
            "                        \"facilities\": [\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\",\n" +
            "                                        \"B\",\n" +
            "                                        \"E\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"D\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"700\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"F\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"G\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"location\": {\n" +
            "                                    \"endRow\": \"1\",\n" +
            "                                    \"columnPositions\": [\n" +
            "                                        \"A\"\n" +
            "                                    ],\n" +
            "                                    \"orientation\": \"F\",\n" +
            "                                    \"beginRow\": \"1\"\n" +
            "                                },\n" +
            "                                \"facilityType\": \"CL\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"firstRow\": \"1\",\n" +
            "                        \"cabinCodeDescription\": \"FIRST\",\n" +
            "                        \"lastRow\": \"4\",\n" +
            "                        \"seatCount\": 16,\n" +
            "                        \"missingRowNumbers\": [],\n" +
            "                        \"seatAlphabetList\": [\n" +
            "                            {\n" +
            "                                \"columnCode\": \"A\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"B\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"E\",\n" +
            "                                \"position\": \"A\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                                \"columnCode\": \"F\",\n" +
            "                                \"position\": \"W\"\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"missingSeatList\": []\n" +
            "                    }\n" +
            "                }\n" +
            "            ],\n" +
            "            \"changeofGaugeInd\": true\n" +
            "        }\n" +
            "    ]\n" +
            "}";

    String resp = "{\"correlationId\" : \"1234567890ABCDE\",\"transactionId\" : \"1234567890ABCDE\",\r\n\"responseCode\":200, \r\n\"responseCodeText\":\"Success\", \r\n\"responseDataLst\":\r\n{\r\n\"payloadLength\":2224,\"payloadName\" : \"SMPRES\",\r\n\"payload\":\"C1C9D9C1C1D3E2D4D7D9C5E2F0F0F0F2002E4000E6C1C4F0F0F000C4000920F0F0D3E706F1000C20F0F0D3D406F0F3F2F4000D20F0F0D3F806C3D6C1C3C800504000E3E5D3F0F0F000C4000E20F0F1E8F506F0F1F0F6F2F1000B20F0F0F8F606D4C9C1000B20F0F0F8F606C2D6E2000A20F0F0F8D606C1C1000C20F0F0F8E406F0F0F1F5000A20F0F0F8E506E84000204000C5D8C9F0F0F001C4000920F0F0F5E606E8000B20F0F0F4C306F1F5F600174000C5D8C9F0F0F101C4000B20F0F0F9E606F7F3F700534000C3C2C4F0F0F101C4000920F0F0F5E606E8000B20F0F0F5C606F0F0F8000B20F0F0F5C606F0F3F3000920F0F0F6F506D4000920F0F0C1C206D6000B20F0F0C4C606F0F1F3000B20F0F0C4C606F0F2F1001E4000C3C2C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6D206E600154000C3C2C4F0F0F202C4000920F0F0F5C706C2001E4000C3C2C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6D206C1001E4000C3C2C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6D206C100154000C3C2C4F0F0F202C4000920F0F0F5C706C5001E4000C3C2C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6D206E600214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F0F9000A20F0F0D2C406C3C8003C4000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F0000A20F0F0D2C406C3C800324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F1000A20F0F0D2C406C3C800324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F2000A20F0F0D2C406C3C800324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F3000A20F0F0D2C406C3C8003C4000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200504000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200504000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200464000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F4000A20F0F0D2C406C3C8003C4000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200504000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200504000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F500464000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E740000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E740000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200504000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200504000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200464000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E740000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200464000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E740000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2002B4000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F6000A20F0F0D2C406C540000A20F0F0D2C406C3C8006E4000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D3E2006E4000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D3E2006E4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D3E2006E4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D9E2006E4000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D9E2006E4000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D9E2002B4000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F7000A20F0F0D2C406C540000A20F0F0D2C406C3C800644000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D3E200644000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D3E200644000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D3E200644000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D9E200644000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D9E200644000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106C540000A20F0F0F5C106D340000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106F1C1000A20F0F0F5C106F1C2000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F8000A20F0F0D2C406C3C8003C4000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F1F9000A20F0F0D2C406C3C8003C4000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F0000A20F0F0D2C406C3C8003C4000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200214000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F1000A20F0F0D2C406C3C8003C4000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106C3C8000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D6E6000A20F0F0F5C106D9E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D6E6000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F200324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106D640000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F300324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F400324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F500324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F600324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F700324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F800324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F2F900324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F3F000324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F3F100324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F3F200324000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E200324000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E2003C4000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200324000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106E740000A20F0F0F5C106D9E200174000D9D6C4F0F0F101C4000B20F0F0F5C606F0F3F300464000D9D6C4F0F0F202C4000920F0F0F5C706C1000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E540000A20F0F0F5C106E740000A20F0F0F5C106D3E200464000D9D6C4F0F0F202C4000920F0F0F5C706C2000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E540000A20F0F0F5C106E740000A20F0F0F5C106D3E200504000D9D6C4F0F0F202C4000920F0F0F5C706C3000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E540000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D3E200504000D9D6C4F0F0F202C4000920F0F0F5C706C4000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E540000A20F0F0F5C106E740000A20F0F0F5C106D4C1000A20F0F0F5C106D9E200464000D9D6C4F0F0F202C4000920F0F0F5C706C5000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E540000A20F0F0F5C106E740000A20F0F0F5C106D9E200464000D9D6C4F0F0F202C4000920F0F0F5C706C6000920F0F0F6F706C6000A20F0F0F5C106F1C4000A20F0F0F5C106E540000A20F0F0F5C106E740000A20F0F0F5C106D9E200154000C3C2C6F0F0F002C4000920F0F0C2F706D9001F4000C3C2C6F0F0F103C4000A20F0F0C2F906C440000920F0F0C1F906D3001F4000C3C2C6F0F0F103C4000A20F0F0C2F906C440000920F0F0C1F906D900154000C3C2C6F0F0F002C4000920F0F0C2F706D9001F4000C3C2C6F0F0F103C4000A20F0F0C2F906C740000920F0F0C1F906D3001F4000C3C2C6F0F0F103C4000A20F0F0C2F906C740000920F0F0C1F906D900154000C3C2C6F0F0F002C4000920F0F0C2F706D9001F4000C3C2C6F0F0F103C4000A20F0F0C2F906D3C1000920F0F0C1F906D3001F4000C3C2C6F0F0F103C4000A20F0F0C2F906D3C1000920F0F0C1F906D90000008C0020000000000000\"\r\n}\r\n}";


    @PostMapping("/v1/seatscore/seatmap")
    public ResponseEntity<String> getSeatMapFromCore(@RequestBody String request, @RequestHeader(name = "securityToken") String token,
                                                     @RequestHeader(name = "x-transaction-id") String transactionId,@RequestHeader(name = "x-correlation-id") String correlationId) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, String> map = mapper.readValue(request, Map.class);
        map.put("transactionId",transactionId);
        map.put("correlationId",correlationId);
        return ResponseEntity.ok(getResponse(map));
    }

    @PostMapping(value = "tpf/mock")
    public ResponseEntity<String> mockTpf(@RequestBody String tpfRequest) throws JsonProcessingException{
        ObjectMapper mapper = new ObjectMapper();
        Map<String, String> map = mapper.readValue(tpfRequest, Map.class);
        Object requestData  = ((ArrayList)mapper.readValue(tpfRequest, Map.class).get("requestDataLst")).get(0);
        Map<String, String> requestDataMap= (Map<String, String>) requestData;
        String payloadLength= String.valueOf(requestDataMap.get("payloadLength"));

        tpfSuccesResponse= tpfSuccesResponse.replaceAll("\\w*<CORRELATION_ID>",map.get("correlationId"));
        tpfSuccesResponse= tpfSuccesResponse.replaceAll("\\w*<TRANSACTION_ID>",map.get("transactionId"));
        tpfSuccesResponse= tpfSuccesResponse.replaceAll("\\w*<PAY_LOAD_LENGTH>",payloadLength);
        tpfSuccesResponse= tpfSuccesResponse.replaceAll("\\w*<PAY_LOAD>",requestDataMap.get("payload"));
        return ResponseEntity.ok(tpfSuccesResponse);
    }

    private String getResponse(Map<String, String> map) {
        String resp=null;
        Map<String, String> mapFlightInfo=(Map<String, String>)((Object) map.get("flightInfo"));
        String flightNumber = mapFlightInfo.get("flightNumber");

        if (mapFlightInfo.get("airlineCode").equalsIgnoreCase("AA")) {
            resp = failedResponse;
        } else if (flightNumber.length() == 4) {
            if (flightNumber.substring(flightNumber.length() - 1).equals("2")) {
                resp = successResponseWithTwoSeatmaps;
            } else if (flightNumber.substring(flightNumber.length() - 1).equals("3")) {
                resp = successResponseWithThreeSeatmaps;
            } else {
                resp = successResponse;
            }
        } else {
            resp = successResponse;
        }
        resp=resp.replaceAll("\\w*<VERSION>",map.get("version"));
        resp=resp.replaceAll("\\w*<TRANSACTION_ID>",map.get("transactionId"));
        resp=resp.replaceAll("\\w*<CORRELATION_ID>",map.get("correlationId"));
        resp=resp.replaceAll("\\w*<REQUEST_DATETIME>",map.get("requestDateTime"));
        resp=resp.replaceAll("\\w*<RESPONSE_DATETIME>", Instant.now().toString());
        resp=resp.replaceAll("\\w*<AIRLINE_CODE>",mapFlightInfo.get("airlineCode"));
        resp=resp.replaceAll("\\w*<FLIGHT_NUMBER>",String.valueOf(mapFlightInfo.get("flightNumber")));
        resp=resp.replaceAll("\\w*<ARRIVAL_DATE>",mapFlightInfo.get("scheduleDepartureDate"));
        resp=resp.replaceAll("\\w*<DEPARTURE_DATE>",mapFlightInfo.get("scheduleDepartureDate"));
        resp=resp.replaceAll("\\w*<DEPARTURE_AIRPORT_CODE>",mapFlightInfo.get("departureAirportCode"));
        resp=resp.replaceAll("\\w*<ARRIVAL_AIRPORT_CODE>",mapFlightInfo.get("arrivalAirportCode"));
        return resp;
    }
}
