package com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request;

import com.google.gson.annotations.SerializedName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class Payload {

    private String sub;
    private String uid;
    private String group;
    private String domain;
    @SerializedName("home_prime_host")
    private String homePrimeHost;
    @SerializedName("current_prime_host")
    private String currentPrimeHost;
    @SerializedName("home_city")
    private String homeCity;
    @SerializedName("iata_number")
    private String iataNumber;
    @SerializedName("country_code")
    private String countryCode;
    @SerializedName("pseudo_city_code")
    private String pseudoCityCode;
    @SerializedName("agent_city_code")
    private String agentCityCode;
    @SerializedName("currency_code")
    private String currencyCode;
    @SerializedName("supplier_type")
    private String supplierType;
    @SerializedName("default_currency")
    private String defaultCurrency;
    @SerializedName("agency_name")
    private String agencyName;
    @SerializedName("agent_sign")
    private String agentSign;
    @SerializedName("subject_token_type")
    private String subjectTokenType;
    @SerializedName("subject_token")
    private String subjectToken;
    private List<String> keywords;
    @SerializedName("duty_codes")
    private List<String> dutyCodes;
    private String iss;
    private String aud;
    private String nbf;
    private String exp;
    private String iat;
    private String jti;
    private List<String> scp;

}
