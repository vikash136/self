package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServiceStatus;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class HealthCheckService {

    @Autowired
    private ServiceHealthCheckStore serviceHealthCheckStore;

    public boolean isHealthStable() {
        String status = serviceHealthCheckStore.getOverallHealthStatus ();
        return status != null && status.equals (ServiceStatus.UP.getStatus ());
    }
}
