package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.AirSeatMapResponseBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TestGrpcService {

    @Autowired
    private JWTDecoderService jwtDecoderService;

    @Autowired
    private TransformerAirSeatMapRQToAuthorizationService transformerAirSeatMapRQToAuthorizationService;

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private ConnectivityService connectivityService;

    @Autowired
    private TransformerConnectivityToSupplierService transformerConnectivityToSupplierService;

    @Autowired
    private SeatmapSupplierService seatmapSupplierService;

    @Autowired
    private TransformerSupplierToViewService transformerSupplierToViewService;

    @Autowired
    private ViewService viewService;

    @Autowired
    private TransformerResponseToPOSService transformerResponseToPOSService;

    @Autowired
    AirSeatMapResponseBuilder airSeatMapResponseBuilder;

    //need to remove after testing
    public String testGrpcService(WebServiceRequestResponseContext requestResponseContext){

        StringBuilder responseSB=new StringBuilder("");
        try {
            jwtDecoderService.processRequest (requestResponseContext);
            transformerAirSeatMapRQToAuthorizationService.processRequest(requestResponseContext);

            responseSB.append("----------------------- Transformer Service Response - JSON to PROTOBUF  For Authorization  ----------------------- ").append("\n")
                    .append(requestResponseContext.getTransformReqResponse()).append("\n");

            getResponseFromGrpcServiceForTesting(requestResponseContext,responseSB);

            transformerResponseToPOSService.processRequest(requestResponseContext);
            responseSB.append("----------------------- Transformer Service Response - PROTOBUF to JSON For POS  ----------------------- ").append("\n")
                    .append(requestResponseContext.getTransformReqResponse());

            airSeatMapResponseBuilder.processRequest(requestResponseContext);
            responseSB.append("----------------------- airSeatMapResponseBuilder Response - Final Response----------------------- ").append("\n")
                    .append(requestResponseContext.getAirSeatMapResponse());

        } catch(Exception ex) {
            responseSB.append("------------- Exception ----------------").append("\n").append(ex.toString());
        }

        return responseSB.toString();
    }

    private void getResponseFromGrpcServiceForTesting(WebServiceRequestResponseContext requestResponseContext,StringBuilder responseSB) throws ServiceTimeOutException {

        for (int segmentId : requestResponseContext.getFlightItemReqResContextMap().keySet()) {

            FlightItemReqResContext flightItemReqResContext = requestResponseContext.getFlightItemReqResContextMap().get(segmentId);

            authorizationService.processFlightItem(requestResponseContext, segmentId);
            responseSB.append("----------------------- Authorization Service Response ----------------------- ").append("\n")
                    .append(flightItemReqResContext.getAuthorizationResponse())
                    .append("\n");

            connectivityService.processFlightItem(requestResponseContext, segmentId);
            responseSB.append("----------------------- Connectivity Service Response ----------------------- ").append("\n")
                    .append(flightItemReqResContext.getConnectivityConfigurationResponse())
                    .append("\n");

            transformerConnectivityToSupplierService.processFlightItem(requestResponseContext, segmentId);
            responseSB.append("----------------------- Transformer Service Response - PROTOBUF to JSON  For SeatmapCore  ----------------------- ").append("\n")
                    .append(flightItemReqResContext.getTransformReqResponse()).append("\n");

            seatmapSupplierService.processFlightItem(requestResponseContext, segmentId);
            if (StringUtils.isEmpty(flightItemReqResContext.getSeatmapResponseFromSupplier())){
                responseSB.append("----------------------- SeatmapSupplierService Response  ----------------------- ").append("\n")
                        .append(flightItemReqResContext.getSegmentResponse().getResponseInfo()).append("\n\n");

            }else{
                responseSB.append("----------------------- SeatmapSupplierService Response  ----------------------- ").append("\n")
                        .append(flightItemReqResContext.getSeatmapResponseFromSupplier()).append("\n\n");

            }

            transformerSupplierToViewService.processFlightItem(requestResponseContext, segmentId);
            responseSB.append("----------------------- Transformer Service Response - JSON to PROTOBUF  For ViewService  ----------------------- ").append("\n")
                    .append(flightItemReqResContext.getTransformReqResponse()).append("\n");

            viewService.processFlightItem(requestResponseContext, segmentId);
            responseSB.append("----------------------- View Service Response ----------------------- ").append("\n")
                    .append(flightItemReqResContext.getSeatmapViewResponse()).append("\n");

        }

    }
}
