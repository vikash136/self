package com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest;
import com.sabre.seats.common.protobuf.*;
import com.sabre.seats.transformation.protobuf.TransformReqResponse;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
public class WebServiceRequestResponseContext {

    private AirSeatMapRequest airSeatMapRQ;
    private String requestVersion;
    private String jwtToken;
    private ClientInfo clientInfo;
    private TransformReqResponse transformReqResponse;
    private AirSeatMapResponse airSeatMapResponse;
    //added as part of proto changes, need to modify context object
    private ResponseStatus transformPosRequestToProtoStatus;
    private RequestInfo requestInfo;
    private ResponseInfo responseInfo;
    private Map<Integer,FlightItemReqResContext> flightItemReqResContextMap;
    private ResponseStatus transformPosResponseToJsonStatus;
    private String seatmapResponseToPOS;
    private String tjrToken;

    public Map<Integer, FlightItemReqResContext> getFlightItemReqResContextMap() {
        flightItemReqResContextMap = Objects.requireNonNullElseGet(flightItemReqResContextMap, HashMap::new);
        return flightItemReqResContextMap;
    }

    public RequestInfo getRequestInfo() {
        requestInfo = Objects.requireNonNullElseGet(requestInfo, RequestInfo.newBuilder()::build);
        return requestInfo;
    }

}
