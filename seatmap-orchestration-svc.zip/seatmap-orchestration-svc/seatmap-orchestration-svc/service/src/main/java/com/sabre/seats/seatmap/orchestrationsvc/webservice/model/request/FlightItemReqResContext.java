package com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request;

import com.sabre.seats.authorization.protobuf.AuthorizationResponse;
import com.sabre.seats.common.protobuf.*;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfiguration;
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationResponse;
import com.sabre.seats.seatmapView.protobuf.SeatmapViewResponse;
import com.sabre.seats.transformation.protobuf.TransformReqResponse;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class FlightItemReqResContext {
    //testing purpose
    private AuthorizationResponse authorizationResponse;
    private ConnectivityConfigurationResponse connectivityConfigurationResponse;
    private TransformReqResponse transformReqResponse;
    private SeatmapViewResponse seatmapViewResponse;

    //added as part of proto changes, need to modify context object
    SegmentInfo segmentInfo;

    private List<PassengerSeatmapRetrieveRequest> passengerSeatmapRetrieveRequestList;
    //AuthorisationService
    ResponseStatus authorizationResponseStatus;
    Supplier supplier;

    //ConnectivityService
    ResponseStatus connectivityResponseStatus;
    ConnectivityConfiguration connectivityConfiguration;

    //Transformer from Connectivity to Supplier
    ResponseStatus transformSupplierRequestStatus;
    String supplierRequestFromTransformer;

    //Supplier/Core service
    ResponseStatus supplierResponseStatus;
    String seatmapResponseFromSupplier;

    //Transformer from Supplier to View
    ResponseStatus transformSupplierResponseStatus;

    //ViewService
    ResponseStatus viewResponseStatus;

    //set if any error/warning from auth,conn,trans,core,view / add flightSeatMap
    SegmentResponse segmentResponse;

}
