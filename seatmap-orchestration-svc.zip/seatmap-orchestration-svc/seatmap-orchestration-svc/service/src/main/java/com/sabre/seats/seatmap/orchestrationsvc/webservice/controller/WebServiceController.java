package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller;

import com.sabre.checkin.jwtdecoder.handler.ESSMKeyStoreHandler;
import com.sabre.checkin.jwtdecoder.keystore.ESSMPublicKeyStore;
import com.sabre.checkin.jwtdecoder.model.ESSMKeyValue;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.CoreServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.UnknownGenericException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.ServiceTimeoutEnum;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.GetAirSeatMapService;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.SeatmapSupplierService;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil;
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest;
import com.sabre.seats.common.protobuf.RequestInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@Slf4j
public class WebServiceController{

    @Autowired
    private GetAirSeatMapService getAirSeatMapService;

    @Autowired
    private ESSMPublicKeyStore essmPublicKeyStore;

    @Autowired
    private ESSMKeyStoreHandler essmKeyStoreHandler;

    @Autowired
    private SeatmapSupplierService seatmapSupplierService;

    @Autowired
    private ServiceTimeoutUtil serviceTimeoutUtil;

    @PostMapping(value ="/{version}/seats/seatmap",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AirSeatMapResponse> getSeatMap(@RequestBody AirSeatMapRequest airSeatMapRequest,
                                                         @RequestHeader(name = "securityToken") String token,
                                                         @RequestHeader(required = false,name = "TJRToken") String tjrToken,
                                                         @RequestHeader(name = "x-transaction-id") String transactionId,
                                                         @RequestHeader(name = "x-correlation-id") String correlationId,
                                                         @PathVariable("version") String version) {
        if(StringUtils.isNotBlank(transactionId) && StringUtils.isNotBlank(correlationId))
        {
            MDC.put("transactionId", transactionId);
            MDC.put("correlationId", correlationId);

        }
        log.info(EscapeUtil.escape("Payload request received from POS"));
        var requestInfo = RequestInfo.newBuilder()
                .setCorrelationId(correlationId)
                .setTransactionId(transactionId)
                .build();

        var requestResponseContext = new WebServiceRequestResponseContext();
        requestResponseContext.setRequestVersion(version.replaceAll("[^0-9]+", ""));
        requestResponseContext.setAirSeatMapRQ(airSeatMapRequest);
        requestResponseContext.setJwtToken(token);
        requestResponseContext.setTjrToken(tjrToken);
        requestResponseContext.setRequestInfo(requestInfo);
        AirSeatMapResponse result = getAirSeatMapService.handleRequest(requestResponseContext);
        log.info(EscapeUtil.escape("SeatMap response returned to POS"));
        MDC.clear();
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }

    @GetMapping("/changeEssmServiceState")
    public void changeEssmServiceState(@RequestParam(required = false) boolean toggleESSMService,
                                       @RequestParam(required = false) boolean alterPublicKey) {
        if (alterPublicKey) {
            corruptPublicKey();
        }
        essmKeyStoreHandler.setToggleEssmService(toggleESSMService);
    }

    @GetMapping("/getServiceTimeout")
    public ResponseEntity<Integer> getServiceTimeout(@RequestParam(required = true) ServiceTimeoutEnum service) {
        return ResponseEntity.ok(serviceTimeoutUtil.getServiceTimeout(service));
    }

    @PostMapping("/setServiceTimeout")
    public void setServiceTimeout(@RequestParam(required = true) ServiceTimeoutEnum service, @RequestParam(required = true) String time) {
        serviceTimeoutUtil.setServiceTimeout(service, time);
    }

    @PostMapping("/getSeatMapFromCore")
    public ResponseEntity<String> getSeatMapFromCore(@RequestBody String request, @RequestHeader(name = "url") String url,@RequestHeader(name = "securityToken") String token, @RequestHeader(name = "x-transaction-id") String transactionId,@RequestHeader(name = "x-correlation-id") String correlationId) throws UnknownGenericException, CoreServiceTimeOutException  {
        return ResponseEntity.ok(seatmapSupplierService.getSeatMapFromCore(url,request,token,transactionId,correlationId));
    }

    private void corruptPublicKey() {
        Map<String, ESSMKeyValue> keyStore = essmPublicKeyStore.getEssmPublicKeyStore();
        keyStore.keySet().iterator().forEachRemaining(
                key -> {
                    var essmKeyValue = keyStore.get(key);
                    essmKeyValue.setRsaPublicKey(null);
                    essmKeyValue.setCreateTimestamp(Long.MIN_VALUE);
                    keyStore.put(key, essmKeyValue);
                }
        );
    }

}
