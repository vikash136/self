package com.sabre.seats.seatmap.orchestrationsvc.webservice.exception;

public class NoJwtDecoderTypeException extends Exception {

    public NoJwtDecoderTypeException(String message) {
        super(message);
    }
}
