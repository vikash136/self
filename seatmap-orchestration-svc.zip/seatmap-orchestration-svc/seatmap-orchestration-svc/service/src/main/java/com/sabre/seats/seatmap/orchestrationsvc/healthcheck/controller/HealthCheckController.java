package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.controller;

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.OptionalServiceHealthStatus;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServiceHealthStatus;
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthCheckController {

    @Autowired
    private ServiceHealthCheckStore serviceHealthCheckStore;

    @GetMapping("/getOverallHealthStatus")
    public ResponseEntity<String> getOverallHealthstatus() {
        return ResponseEntity.ok(serviceHealthCheckStore.getOverallHealthStatus ());
    }

    @GetMapping(value = "/getHealthStatusForAllServices", produces = "application/json")
    public ResponseEntity<ServiceHealthStatus> getHealthStatusForAllServices() {
        return ResponseEntity.ok((serviceHealthCheckStore.getHealthStatusForAllServices () !=null ? serviceHealthCheckStore.getHealthStatusForAllServices () : new ServiceHealthStatus ()));
    }

    @GetMapping(value = "/getHealthStatusForOptionalServices", produces = "application/json")
    public ResponseEntity<OptionalServiceHealthStatus> getHealthStatusForOptionalServices() {
        return ResponseEntity.ok((serviceHealthCheckStore.getHealthStatusForOptionalServices () !=null ? serviceHealthCheckStore.getHealthStatusForOptionalServices () : new OptionalServiceHealthStatus()));
    }
}
