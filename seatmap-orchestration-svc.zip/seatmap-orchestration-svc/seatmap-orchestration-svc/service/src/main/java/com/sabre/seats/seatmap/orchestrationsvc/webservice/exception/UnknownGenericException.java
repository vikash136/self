package com.sabre.seats.seatmap.orchestrationsvc.webservice.exception;

public class UnknownGenericException extends Exception{

    public UnknownGenericException(String message){super(message);}

}
