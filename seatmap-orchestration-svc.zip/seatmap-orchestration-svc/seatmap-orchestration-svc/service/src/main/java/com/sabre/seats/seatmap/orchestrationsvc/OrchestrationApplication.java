package com.sabre.seats.seatmap.orchestrationsvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication
@EnableRetry
@ImportResource("classpath:spring/orchestration-service-application-context.xml")
@PropertySource("classpath:connector.tpf.application.properties")
public class OrchestrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrchestrationApplication.class, args);
	}

}
