package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil;
import com.sabre.seats.common.protobuf.MessageFormat;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.common.protobuf.SeatAction;
import com.sabre.seats.common.protobuf.SegmentResponse;
import com.sabre.seats.transformation.protobuf.*;
import io.grpc.ManagedChannel;
import io.grpc.StatusRuntimeException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
@Slf4j
public class TransformerSupplierToViewService implements FlightItemProcessor {

    private static final String TRANSFORMER_SERVICE = "transformerService";

    @Value("${transformationService.callTimeout}")
    private int transformationServiceCallTimeout;

    @Value("${transformationService.version}")
    private String transformationServiceVersion;

    @Autowired
    @Qualifier("transformChannel")
    ManagedChannel transformSeatMapRespToProtoChannel;

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    private ServiceTimeoutUtil serviceTimeoutUtil;

    @Override
    public void processFlightItem(WebServiceRequestResponseContext requestResponseContext, int segmentId) throws ServiceTimeOutException {

        FlightItemReqResContext flightItemReqResContext=requestResponseContext.getFlightItemReqResContextMap().get(segmentId);

        if(ResponseStatus.SUCCESS.equals(flightItemReqResContext.getSupplierResponseStatus())
                && StringUtils.isNotEmpty(flightItemReqResContext.getSeatmapResponseFromSupplier())){

            getCoreSeatMapResponseFromTransformer(requestResponseContext, flightItemReqResContext);
        }

    }

    private void getCoreSeatMapResponseFromTransformer(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) throws ServiceTimeOutException {
        log.info(EscapeUtil.escape("inside getCoreSeatMapResponseFromTransformer method"));

        TransformRequest transformRequest;
        TransformReqResponse transformResponse = null;
        try{
            TransformServiceGrpc.TransformServiceBlockingStub transformServiceBlockingStub = TransformServiceGrpc
                    .newBlockingStub(transformSeatMapRespToProtoChannel)
                    .withDeadlineAfter(transformationServiceCallTimeout, TimeUnit.MILLISECONDS);

            transformRequest = getTransformRequest(requestResponseContext,flightItemReqResContext);

            log.debug(EscapeUtil.escape("transformRequest of seat-map-core to view service : {}" + transformRequest));
            transformResponse = getTransformationResponse(transformServiceBlockingStub, transformRequest);
            log.debug(EscapeUtil.escape("transformResponse of seat-map-core to view service: {}" + transformResponse));

        } catch(StatusRuntimeException ex) {
            log.info(EscapeUtil.escape("StatusRuntimeException in TransformerSupplierToViewService: {}"));
            serviceTimeoutUtil.setServiceDown(TRANSFORMER_SERVICE);
            transformResponse = errorMessageListBuilder.getTransformerExceptionResponse("TransformerTimeOutException");
            throw new ServiceTimeOutException("ServiceTimeOutException");

        } catch(Exception ex) {
            log.debug(EscapeUtil.escape("Exception in TransformerSupplierToViewService :" + ex));

        }finally {
            validateResponse(flightItemReqResContext, transformResponse);
        }

    }

    private TransformRequest getTransformRequest(WebServiceRequestResponseContext requestResponseContext,FlightItemReqResContext flightItemReqResContext) {
        TransformRequest transformRequest;
        MessageInfo inputMessageInfo ;
             inputMessageInfo = MessageInfo.newBuilder()
                    .setMsgType(flightItemReqResContext.getConnectivityConfiguration().getMessageResponseType())
                    .setFormat(flightItemReqResContext.getConnectivityConfiguration().getMessageFormat())
                    .setVersion(flightItemReqResContext.getConnectivityConfiguration().getApiVersion())
                    .build();

        MessageInfo desiredMessageInfo = MessageInfo.newBuilder()
                .setMsgType(MessageType.SEGMENT_RESPONSE)
                .setFormat(MessageFormat.PROTOBUF)
                .setVersion(transformationServiceVersion)
                .build();


        Input input = Input.newBuilder()
                .setRequest(flightItemReqResContext.getSeatmapResponseFromSupplier())
                .build();

        Request request = Request.newBuilder()
                .setRequestInfo(requestResponseContext.getRequestInfo())
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .setSeatAction(SeatAction.SEAT_VIEW)
                .build();

        transformRequest = TransformRequest.newBuilder()
                .setRequest(request)
                .build();
        return transformRequest;
    }

    TransformReqResponse getTransformationResponse(TransformServiceGrpc.TransformServiceBlockingStub transformServiceBlockingStub, TransformRequest transformRequest){
        return transformServiceBlockingStub
                .transform(transformRequest);
    }

    private void validateResponse(FlightItemReqResContext flightItemReqResContext, TransformReqResponse transformResponse) {

        if(transformResponse==null){
            transformResponse = errorMessageListBuilder.getTransformerExceptionResponse("UnknownGenericException");
        }

        flightItemReqResContext.setTransformReqResponse(transformResponse);
        flightItemReqResContext.setTransformSupplierResponseStatus(transformResponse.getSeatMapOutputReqResponse().getResponseInfo().getResponseStatus());

        if (ResponseStatus.SUCCESS.equals(flightItemReqResContext.getTransformSupplierResponseStatus())) {
            if (transformResponse.getSeatMapOutputReqResponse().getOutputResponse().getSegmentResponse().hasSegmentInfo()) {
                flightItemReqResContext.setSegmentResponse(transformResponse.getSeatMapOutputReqResponse().getOutputResponse().getSegmentResponse());
            } else {
                SegmentResponse segmentResponse = SegmentResponse.newBuilder()
                        .setResponseInfo(transformResponse.getSeatMapOutputReqResponse().getOutputResponse().getSegmentResponse().getResponseInfo())
                        .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                        .build();
                flightItemReqResContext.setSegmentResponse(segmentResponse);
            }
        } else {
            SegmentResponse segmentResponse = SegmentResponse.newBuilder()
                    .setResponseInfo(transformResponse.getSeatMapOutputReqResponse().getResponseInfo())
                    .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                    .build();
            flightItemReqResContext.setSegmentResponse(segmentResponse);
        }
    }
    public int getTransformationServiceCallTimeout() {
        return transformationServiceCallTimeout;
    }

    public void setTransformationServiceCallTimeout(int transformationServiceCallTimeout) {
        this.transformationServiceCallTimeout = transformationServiceCallTimeout;
    }

}