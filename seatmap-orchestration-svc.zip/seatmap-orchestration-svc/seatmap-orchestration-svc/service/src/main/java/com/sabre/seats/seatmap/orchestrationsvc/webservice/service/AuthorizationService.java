package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil;
import com.sabre.seats.authorization.protobuf.AuthorizationRequest;
import com.sabre.seats.authorization.protobuf.AuthorizationResponse;
import com.sabre.seats.authorization.protobuf.AuthorizationServiceGrpc;
import com.sabre.seats.common.protobuf.ResponseStatus;
import com.sabre.seats.common.protobuf.SeatAction;
import com.sabre.seats.common.protobuf.SegmentResponse;
import io.grpc.ManagedChannel;
import io.grpc.StatusRuntimeException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class AuthorizationService implements FlightItemProcessor {

    @Value("${authorizationService.callTimeout}")
    private int authorizationServiceCallTimeout;

    @Value("${authorizationService.version}")
    private String authorizationServiceVersion;

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    @Qualifier("authorizationChannel")
    ManagedChannel authorizationChannel;

    @Autowired
    private ServiceTimeoutUtil serviceTimeoutUtil;

    private static final String AUTHORIZATION_SERVICE = "authorizationService";

    @Override
    public void processFlightItem(WebServiceRequestResponseContext requestResponseContext, int segmentId) throws ServiceTimeOutException {
        sendTransformationResponseToAuthorization(requestResponseContext, requestResponseContext.getFlightItemReqResContextMap().get(segmentId));
    }

    private void sendTransformationResponseToAuthorization(WebServiceRequestResponseContext requestResponseContext, FlightItemReqResContext flightItemReqResContext) throws ServiceTimeOutException {
        log.info(EscapeUtil.escape("Inside sendTransformationResponseToAuthorization method"));
        AuthorizationRequest authorizationRequest;
        AuthorizationResponse authorizationResponse =null;
        try {
            AuthorizationServiceGrpc.AuthorizationServiceBlockingStub authorizationServiceBlockingStub = AuthorizationServiceGrpc
                    .newBlockingStub(authorizationChannel).withDeadlineAfter(authorizationServiceCallTimeout, TimeUnit.MILLISECONDS);

            authorizationRequest = AuthorizationRequest.newBuilder()
                    .setRequestInfo(requestResponseContext.getRequestInfo())
                    .setClientInfo(requestResponseContext.getClientInfo())
                    .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                    .setSeatAction(SeatAction.SEAT_VIEW)
                    .addAllPassengers(flightItemReqResContext.getPassengerSeatmapRetrieveRequestList())
                    .build();

            log.info(EscapeUtil.escape("authorizationRequest sent" + authorizationRequest));
            authorizationResponse = getAuthorizationResponse(authorizationServiceBlockingStub, authorizationRequest);
            log.debug(EscapeUtil.escape("authorizationResponse: received" + authorizationResponse));


        } catch (StatusRuntimeException ex) {
            log.info(EscapeUtil.escape("sendTransformationResponseToAuthorization() Catch block-StatusRuntimeException in AuthorizationService :"));
            authorizationResponse = errorMessageListBuilder.getAuthorizationExceptionResponse ("AuthorizationTimeOutException");
            serviceTimeoutUtil.setServiceDown(AUTHORIZATION_SERVICE);
            throw new ServiceTimeOutException("ServiceTimeOutException");
        } catch (Exception ex) {
            log.error(EscapeUtil.escape("Exception in AuthorizationService : " + ex));
        } finally {
            validateResponse(flightItemReqResContext, authorizationResponse);
        }

    }

    private void validateResponse(FlightItemReqResContext flightItemReqResContext, AuthorizationResponse authorizationResponse) {
        log.debug(EscapeUtil.escape("Inside validateResponse method"));

        if(null==authorizationResponse){
            authorizationResponse = errorMessageListBuilder.getAuthorizationExceptionResponse("UnknownGenericException");
        }

        flightItemReqResContext.setAuthorizationResponse(authorizationResponse);
        flightItemReqResContext.setAuthorizationResponseStatus(authorizationResponse.getResponseInfo().getResponseStatus());

        if (ResponseStatus.SUCCESS.equals(flightItemReqResContext.getAuthorizationResponseStatus())
                || ResponseStatus.NOT_OFFLOADED.equals(flightItemReqResContext.getAuthorizationResponseStatus())) {
            flightItemReqResContext.setSupplier(authorizationResponse.getSupplier());

        } else{
            var segmentResponse=SegmentResponse.newBuilder()
                    .setResponseInfo(authorizationResponse.getResponseInfo())
                    .setSegmentInfo(flightItemReqResContext.getSegmentInfo())
                    .build();
            flightItemReqResContext.setSegmentResponse(segmentResponse);
        }

    }

    AuthorizationResponse getAuthorizationResponse(AuthorizationServiceGrpc.AuthorizationServiceBlockingStub authorizationServiceBlockingStub, AuthorizationRequest authorizationRequest){
        return authorizationServiceBlockingStub
                .authorizeRequest(authorizationRequest);
    }

    public int getAuthorizationServiceCallTimeout() {
        return authorizationServiceCallTimeout;
    }

    public void setAuthorizationServiceCallTimeout(int authorizationServiceCallTimeout) {
        this.authorizationServiceCallTimeout = authorizationServiceCallTimeout;
    }

}
