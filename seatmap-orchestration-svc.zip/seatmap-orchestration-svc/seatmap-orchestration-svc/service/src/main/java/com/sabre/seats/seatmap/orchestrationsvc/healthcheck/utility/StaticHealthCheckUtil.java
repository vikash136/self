package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.utility;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@ConfigurationProperties("static.healthcheck")
@Component
public class StaticHealthCheckUtil {

    private Map<String, String> staticHealthCheckMap = new HashMap<> ();

    public Map<String, String> getStaticHealthCheckMap() {
        return staticHealthCheckMap;
    }

    public void setStaticHealthCheckMap(Map<String, String> staticHealthCheckMap) {
        this.staticHealthCheckMap = staticHealthCheckMap;
    }

}
