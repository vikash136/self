package com.sabre.seats.seatmap.orchestrationsvc.webservice.service;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.AirSeatMapResponseBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.EscapeUtil;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class GetAirSeatMapService {

    @Autowired
    private HealthCheckService healthCheckService;

    @Autowired
    private AirSeatMapResponseBuilder airSeatMapResponseBuilder;

    @Autowired
    private ErrorMessageListBuilder errorMessageListBuilder;

    @Autowired
    MeterRegistry meterRegistry;

    @Autowired
    @Qualifier("requestProcessors")
    List<RequestProcessor> requestProcessors;

    public AirSeatMapResponse handleRequest(WebServiceRequestResponseContext requestResponseContext) {

        boolean healthStatus = healthCheckService.isHealthStable();
        if (healthStatus) {
            try {
                for(RequestProcessor requestProcessor:requestProcessors){
                    requestProcessor.processRequest(requestResponseContext);
                }

                return requestResponseContext.getAirSeatMapResponse();
            } catch(Exception ex) {
                log.error(EscapeUtil.escape("Exception in GetAirSeatMap service : " + ex));
                return buildAirSeatMapResponseOnException (requestResponseContext, ex.getClass ().getSimpleName ());
            }
        } else {
            log.info(EscapeUtil.escape("Health is not good to process the request" ));
            Counter.builder("Health.Down").register(meterRegistry).increment();
            return buildAirSeatMapResponseOnException (requestResponseContext, "HealthDown");
        }
    }

    private AirSeatMapResponse buildAirSeatMapResponseOnException(WebServiceRequestResponseContext requestResponseContext, String exceptionName) {
        log.info(EscapeUtil.escape("Exception Occurred while processing AirSeatMap Request : {}" + exceptionName));
        switch(exceptionName) {
            case "HealthDown":
            case "NoJwtDecoderTypeException":
            case "TokenExpiredException":
            case "JWTDecodeException":
            case "JWTVerificationException":
            case "ESSMKeyNotFoundException":
            case "TransformerTimeOutException":
            case "ServiceTimeOutException":
                return airSeatMapResponseBuilder.getAirSeatMapErrorResponse (requestResponseContext, errorMessageListBuilder.getErrorMessageList (exceptionName));
            default:
                return airSeatMapResponseBuilder.getAirSeatMapErrorResponse (requestResponseContext, errorMessageListBuilder.getErrorMessageList ("UnknownGenericException"));
        }
    }
}
