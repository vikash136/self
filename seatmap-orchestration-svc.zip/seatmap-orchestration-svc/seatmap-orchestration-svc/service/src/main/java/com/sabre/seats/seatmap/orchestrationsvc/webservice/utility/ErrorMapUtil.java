package com.sabre.seats.seatmap.orchestrationsvc.webservice.utility;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@ConfigurationProperties("orchestration.service")
@Component
public class ErrorMapUtil {

    private Map<String, Map<String, String>> errormap = new HashMap<> ();

    public Map<String, Map<String, String>> getErrormap() {
        return errormap;
    }

    public void setErrormap(Map<String, Map<String, String>> errormap) {
        this.errormap = errormap;
    }
}
