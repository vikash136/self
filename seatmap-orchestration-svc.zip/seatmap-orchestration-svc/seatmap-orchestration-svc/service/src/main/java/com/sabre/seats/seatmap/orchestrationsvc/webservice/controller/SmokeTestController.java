package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller;

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.scheduler.HealthCheckScheduler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@RestController
public class SmokeTestController {
    private static final Logger log = LoggerFactory.getLogger(SmokeTestController.class);

    @Value("${server.port}")
    private int serverPort;

    private final HealthCheckScheduler healthCheckScheduler;

    public SmokeTestController(HealthCheckScheduler healthCheckScheduler) {
        this.healthCheckScheduler = healthCheckScheduler;
    }

    @GetMapping(path = "/smoke")
    public ResponseEntity<String> smokeTest() {
        try {
            log.info("Running smoke tests...");
            // do what is relevant to your application here
            healthCheckScheduler.checkAllServicesHealth();
            log.info("Smoke tests passed.");
            return ResponseEntity.ok("OK");
        } catch (Exception e) {
            log.error("Error occurred while running smoke tests; service is unable to handle traffic.", e);
            return ResponseEntity.status(INTERNAL_SERVER_ERROR).build();
        }
    }
}
