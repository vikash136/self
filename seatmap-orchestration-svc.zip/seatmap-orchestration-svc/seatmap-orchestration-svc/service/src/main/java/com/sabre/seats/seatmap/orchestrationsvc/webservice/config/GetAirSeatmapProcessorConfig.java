package com.sabre.seats.seatmap.orchestrationsvc.webservice.config;

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.AirSeatMapResponseBuilder;
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class GetAirSeatmapProcessorConfig {

    @Bean("requestProcessors")
    public List<RequestProcessor> getRequestProcessorList(JWTDecoderService jwtDecoderService,
                                                          TransformerAirSeatMapRQToAuthorizationService transformerAirSeatMapRQToAuthorizationService,
                                                          FlightItemService flightItemService,
                                                          TransformerResponseToPOSService transformerResponseToPOSService,
                                                          AirSeatMapResponseBuilder airSeatMapResponseBuilder) {
        List<RequestProcessor> requestProcessors=new ArrayList<>();
        requestProcessors.add(jwtDecoderService);
        requestProcessors.add(transformerAirSeatMapRQToAuthorizationService);
        requestProcessors.add(flightItemService);
        requestProcessors.add(transformerResponseToPOSService);
        requestProcessors.add(airSeatMapResponseBuilder);
        return requestProcessors;
    }

    @Bean("flightItemProcessors")
    public List<FlightItemProcessor> getFlightItemProcessorsProcessorList(AuthorizationService authorizationService,
                                                                          ConnectivityService connectivityService,
                                                                          TransformerConnectivityToSupplierService transformerConnectivityToSupplierService,
                                                                          SeatmapSupplierService seatmapSupplierService,
                                                                          TransformerSupplierToViewService transformerSupplierToViewService,
                                                                          ViewService viewService){
        List<FlightItemProcessor> flightItemProcessors=new ArrayList<>();
        flightItemProcessors.add(authorizationService);
        flightItemProcessors.add(connectivityService);
        flightItemProcessors.add(transformerConnectivityToSupplierService);
        flightItemProcessors.add(seatmapSupplierService);
        flightItemProcessors.add(transformerSupplierToViewService);
        flightItemProcessors.add(viewService);
        return flightItemProcessors;
    }
}
