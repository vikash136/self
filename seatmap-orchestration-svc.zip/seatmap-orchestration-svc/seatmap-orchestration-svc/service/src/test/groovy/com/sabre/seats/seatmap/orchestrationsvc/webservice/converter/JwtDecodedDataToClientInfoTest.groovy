
package com.sabre.seats.seatmap.orchestrationsvc.webservice.converter

import com.google.gson.JsonSyntaxException
import com.sabre.checkin.jwtdecoder.model.JWTDecodedData
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ChannelIdUtil
import com.sabre.seats.common.protobuf.RequesterType
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class JwtDecodedDataToClientInfoTest extends Specification {

    def classUnderTest =  Spy(new JwtDecodedDataToClientInfo())
    def channelMapUtil = Mock(ChannelIdUtil.class)

    def setup() {
        ReflectionTestUtils.setField(classUnderTest,"channelMapUtil", channelMapUtil)
    }

    def "test convertJwtDecodedDataToClientInfo with invalid IataNumber" () {
        given:
        JWTDecodedData jwtDecodedData = new JWTDecodedData()
        String header = "{\"kid\":\"ROOTKEY1CURRENT\",\"typ\":\"JWT\",\"alg\":\"RS256\"}"
        String payload = "{\"iata_number\":\"123\",\"current_prime_host\":\"1S\",\"group\":\"F4X0\",\"agency_name\":\"IA\",\"iat\":\"IATA\",\"domain\":\"clientContext\",\"keywords\": [\"TGASUser\",\"AggregatorUser\",\"CsiMsUser\"]}"
        jwtDecodedData.setHeader(header)
        jwtDecodedData.setPayload(payload)
        Optional<JWTDecodedData> jwtDecodedDataOpl = Optional.of(jwtDecodedData)
        Optional<JWTDecodedData> tjrDecodedDataOpl = Optional.of(jwtDecodedData)

        when:
        def clientInfo = classUnderTest.convertJwtDecodedDataToClientInfo(jwtDecodedDataOpl,tjrDecodedDataOpl)

        then:
        1 * channelMapUtil.getRequesterIds() >> Arrays.asList("1S")
        clientInfo != null
        clientInfo.getAgencyCode() == "F4X0"
        clientInfo.getRequester() == "1S"
        clientInfo.getRequesterType() == RequesterType.GDS
        clientInfo.getClientContext() == "WebService"
        clientInfo.getEprKeywordsList().size() == 3

    }

    def "test convertJwtDecodedDataToClientInfo with valid IataNumber" () {
        given:
        JWTDecodedData jwtDecodedData = new JWTDecodedData()
        String header = "{\"kid\":\"ROOTKEY1CURRENT\",\"typ\":\"JWT\",\"alg\":\"RS256\"}"
        String payload = "{\"iata_number\":\"12345678\",\"current_prime_host\":\"1S\",\"group\":\"F4X0\",\"agency_name\":\"IA\",\"iat\":\"IATA\",\"domain\":\"clientContext\",\"keywords\": [\"TGASUser\",\"AggregatorUser\",\"CsiMsUser\"]}"
        jwtDecodedData.setHeader(header)
        jwtDecodedData.setPayload(payload)
        Optional<JWTDecodedData> jwtDecodedDataOpl = Optional.of(jwtDecodedData)
        Optional<JWTDecodedData> tjrDecodedDataOpl = Optional.of(jwtDecodedData)

        when:
        def clientInfo = classUnderTest.convertJwtDecodedDataToClientInfo(jwtDecodedDataOpl,tjrDecodedDataOpl)

        then:
        1 * channelMapUtil.getRequesterIds() >> Arrays.asList("1S")
        clientInfo != null
        clientInfo.getAgencyCode() == "F4X0"
        clientInfo.getRequester() == "1S"
        clientInfo.getRequesterType() == RequesterType.GDS
        clientInfo.getClientContext() == "WebService"
        clientInfo.getEprKeywordsList().size() == 3

    }


    def "test convertJwtDecodedDataToClientInfo with IataNumber empty" () {
        given:
        JWTDecodedData jwtDecodedData = new JWTDecodedData()
        String header = "{\"kid\":\"ROOTKEY1CURRENT\",\"typ\":\"JWT\",\"alg\":\"RS256\"}"
        String payload = "{\"iata_number\":\"\",\"current_prime_host\":\"1S\",\"group\":\"F4X0\",\"agency_name\":\"IA\",\"iat\":\"IATA\",\"domain\":\"clientContext\",\"keywords\": [\"TGASUser\",\"AggregatorUser\",\"CsiMsUser\"]}"
        jwtDecodedData.setHeader(header)
        jwtDecodedData.setPayload(payload)
        Optional<JWTDecodedData> jwtDecodedDataOpl = Optional.of(jwtDecodedData)
        Optional<JWTDecodedData> tjrDecodedDataOpl = Optional.of(jwtDecodedData)

        when:
        def clientInfo = classUnderTest.convertJwtDecodedDataToClientInfo(jwtDecodedDataOpl,tjrDecodedDataOpl)

        then:
        1 * channelMapUtil.getRequesterIds() >> Arrays.asList("1S")
        clientInfo != null
        clientInfo.getAgencyCode() == "F4X0"
        clientInfo.getRequester() == "1S"
        clientInfo.getRequesterType() == RequesterType.GDS
        clientInfo.getClientContext() == "WebService"
        clientInfo.getEprKeywordsList().size() == 3

    }

    def "test convertJwtDecodedDataToClientInfo with CurrentPrimeHost other than **" () {
        given:
        JWTDecodedData jwtDecodedData = new JWTDecodedData()
        String header = "{\"kid\":\"ROOTKEY1CURRENT\",\"typ\":\"JWT\",\"alg\":\"RS256\"}"
        String payload = "{\"iata_number\":\"12345678\",\"home_prime_host\":\"1S\",\"current_prime_host\":\"1S\",\"group\":\"F4X0\",\"agency_name\":\"IA\",\"iat\":\"IATA\",\"domain\":\"clientContext\",\"keywords\": [\"TGASUser\",\"AggregatorUser\",\"CsiMsUser\"]}"
        jwtDecodedData.setHeader(header)
        jwtDecodedData.setPayload(payload)
        Optional<JWTDecodedData> jwtDecodedDataOpl = Optional.of(jwtDecodedData)
        Optional<JWTDecodedData> tjrDecodedDataOpl = Optional.of(jwtDecodedData)

        when:
        def clientInfo = classUnderTest.convertJwtDecodedDataToClientInfo(jwtDecodedDataOpl,tjrDecodedDataOpl)

        then:
        1 * channelMapUtil.getRequesterIds() >> Arrays.asList("1S")
        clientInfo != null
        clientInfo.getAgencyCode() == "F4X0"
        clientInfo.getRequester() == "1S"
        clientInfo.getRequesterType() == RequesterType.GDS
        clientInfo.getClientContext() == "WebService"
        clientInfo.getEprKeywordsList().size() == 3
    }

    def "test convertJwtDecodedDataToClientInfo with CurrentPrimeHost as **" () {
        given:
        JWTDecodedData jwtDecodedData = new JWTDecodedData()
        String header = "{\"kid\":\"ROOTKEY1CURRENT\",\"typ\":\"JWT\",\"alg\":\"RS256\"}"
        String payload = "{\"iata_number\":\"12345678\",\"home_prime_host\":\"**\",\"current_prime_host\":\"**\",\"group\":\"F4X0\",\"agency_name\":\"IA\",\"iat\":\"IATA\",\"domain\":\"clientContext\",\"keywords\": [\"TGASUser\",\"AggregatorUser\",\"CsiMsUser\"]}"
        jwtDecodedData.setHeader(header)
        jwtDecodedData.setPayload(payload)
        Optional<JWTDecodedData> jwtDecodedDataOpl = Optional.of(jwtDecodedData)
        Optional<JWTDecodedData> tjrDecodedDataOpl = Optional.of(jwtDecodedData)

        when:
        def clientInfo = classUnderTest.convertJwtDecodedDataToClientInfo(jwtDecodedDataOpl,tjrDecodedDataOpl)

        then:
        1 * channelMapUtil.getRequesterIds() >> Arrays.asList("**")
        clientInfo != null
        clientInfo.getAgencyCode() == "F4X0"
        clientInfo.getRequester() == "**"
        clientInfo.getRequesterType() == RequesterType.AIRLINE
        clientInfo.getClientContext() == "WebService"
        clientInfo.getEprKeywordsList().size() == 3

    }

    def "test convertJwtDecodedDataToClientInfo with JsonSyntaxException" () {
        given:
        JWTDecodedData jwtDecodedData = new JWTDecodedData()
        String header = "{\"key\":\"rsaPublicKey\"}"
        jwtDecodedData.setHeader(header)
        jwtDecodedData.setPayload("payload")
        Optional<JWTDecodedData> jwtDecodedDataOpl = Optional.of(jwtDecodedData)
        Optional<JWTDecodedData> tjrDecodedDataOpl = Optional.of(jwtDecodedData)

        when:
        classUnderTest.convertJwtDecodedDataToClientInfo(jwtDecodedDataOpl,tjrDecodedDataOpl)

        then:
        thrown(JsonSyntaxException)
    }

    def "test - null"(){
        given:
        Optional<JWTDecodedData> jwtDecodedDataOpl =Optional.empty()
        Optional<JWTDecodedData> tjrDecodedDataOpl =Optional.empty()
        when:
        def clientInfo=classUnderTest.convertJwtDecodedDataToClientInfo(jwtDecodedDataOpl,tjrDecodedDataOpl)
        then:
        clientInfo.getAgencyCode()==""
        clientInfo.getRequester() == ""
        clientInfo.getRequesterType() == RequesterType.UNKNOWN_REQUESTER_TYPE

    }

}
