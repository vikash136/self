package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.client


import io.grpc.ManagedChannel
import spock.lang.Specification

import java.lang.reflect.Field

class ServiceClientTest extends Specification {

    def classUnderTest = new ServiceClient()
    def managedChannelMock = Mock(ManagedChannel.class)

    def setup() {
        Field authorizationServiceUrl = ServiceClient.class.getDeclaredField("authorizationServiceUrl")
        authorizationServiceUrl.setAccessible(true)
        authorizationServiceUrl.set(classUnderTest,"localhost")

        Field authorizationServicePort = ServiceClient.class.getDeclaredField("authorizationServicePort")
        authorizationServicePort.setAccessible(true)
        authorizationServicePort.set(classUnderTest,8090)

        Field authorizationServiceCallTimeout = ServiceClient.class.getDeclaredField("authorizationServiceCallTimeout")
        authorizationServiceCallTimeout.setAccessible(true)
        authorizationServiceCallTimeout.set(classUnderTest,5000)

        Field transformationServiceUrl = ServiceClient.class.getDeclaredField("transformationServiceUrl")
        transformationServiceUrl.setAccessible(true)
        transformationServiceUrl.set(classUnderTest,"localhost")

        Field transformationServicePort = ServiceClient.class.getDeclaredField("transformationServicePort")
        transformationServicePort.setAccessible(true)
        transformationServicePort.set(classUnderTest,8090)

        Field transformationServiceCallTimeout = ServiceClient.class.getDeclaredField("transformationServiceCallTimeout")
        transformationServiceCallTimeout.setAccessible(true)
        transformationServiceCallTimeout.set(classUnderTest,5000)

        Field connectivityServiceUrl = ServiceClient.class.getDeclaredField("connectivityServiceUrl")
        connectivityServiceUrl.setAccessible(true)
        connectivityServiceUrl.set(classUnderTest,"localhost")

        Field connectivityServicePort = ServiceClient.class.getDeclaredField("connectivityServicePort")
        connectivityServicePort.setAccessible(true)
        connectivityServicePort.set(classUnderTest,8090)

        Field connectivityServiceCallTimeout = ServiceClient.class.getDeclaredField("connectivityServiceCallTimeout")
        connectivityServiceCallTimeout.setAccessible(true)
        connectivityServiceCallTimeout.set(classUnderTest,5000)

        Field viewServiceUrl = ServiceClient.class.getDeclaredField("viewServiceUrl")
        viewServiceUrl.setAccessible(true)
        viewServiceUrl.set(classUnderTest,"localhost")

        Field viewServicePort = ServiceClient.class.getDeclaredField("viewServicePort")
        viewServicePort.setAccessible(true)
        viewServicePort.set(classUnderTest,8090)

        Field viewServiceCallTimeout = ServiceClient.class.getDeclaredField("viewServiceCallTimeout")
        viewServiceCallTimeout.setAccessible(true)
        viewServiceCallTimeout.set(classUnderTest,5000)
    }

    def "getService Status for Auth"() {
        given:
        HashMap<String, String> map = new HashMap<>()
        when:
        classUnderTest.getServiceStatus("authorizationService", map)

        then:
        !map.isEmpty()
        map.containsKey("authorizationService")
    }

    def "getService Status for Transformer"() {
        given:
        HashMap<String, String> map = new HashMap<>()
        when:
        classUnderTest.getServiceStatus("transformerService", map)

        then:
        !map.isEmpty()
        map.containsKey("transformerService")
    }

    def "getService Status for Connectivity"() {
        given:
        HashMap<String, String> map = new HashMap<>()
        when:
        classUnderTest.getServiceStatus("connectivityService", map)

        then:
        !map.isEmpty()
        map.containsKey("connectivityService")
    }

    def "getService Status for View"() {
        given:
        HashMap<String, String> map = new HashMap<>()

        when:
        classUnderTest.getServiceStatus("viewService", map)

        then:
        !map.isEmpty()
        map.containsKey("viewService")
    }

    def "getService Status for other services"() {
        given:
        HashMap<String, String> map = new HashMap<>()

        when:
        classUnderTest.getServiceStatus("orchestrationService", map)

        then:
        !map.isEmpty()
        map.containsKey("orchestrationService")
    }

}
