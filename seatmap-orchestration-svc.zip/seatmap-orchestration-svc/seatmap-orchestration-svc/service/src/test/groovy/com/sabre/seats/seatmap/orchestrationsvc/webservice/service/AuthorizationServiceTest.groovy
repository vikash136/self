
package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.authorization.protobuf.AuthorizationResponse
import com.sabre.seats.common.protobuf.*
import com.sabre.seats.error.protobuf.Description
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.error.protobuf.MessageCode
import io.grpc.ManagedChannelBuilder
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class AuthorizationServiceTest extends Specification{
    def classUnderTest = Spy(AuthorizationService)
    def errorMessageListBuilder = Mock(ErrorMessageListBuilder.class)
    def authorizationChannel = ManagedChannelBuilder.forTarget("localhost").usePlaintext().build()
    def serviceTimeoutUtil = Mock(ServiceTimeoutUtil.class)

    def setup(){
        ReflectionTestUtils.setField(classUnderTest, "authorizationServiceCallTimeout", 5000)
        ReflectionTestUtils.setField(classUnderTest, "errorMessageListBuilder", errorMessageListBuilder)
        ReflectionTestUtils.setField(classUnderTest, "authorizationChannel", authorizationChannel)
        ReflectionTestUtils.setField(classUnderTest, "serviceTimeoutUtil", serviceTimeoutUtil)
        ReflectionTestUtils.setField(classUnderTest, "authorizationServiceVersion", "1")
    }

    def "send processFlightItem"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * classUnderTest.getAuthorizationResponse(_,_) >> getSuccessResponse(serviceRequestResponseContext)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getAuthorizationResponseStatus()==ResponseStatus.SUCCESS
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getSupplier()!=null
    }

    def "send processFlightItem Not offloaded status"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("AA")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * classUnderTest.getAuthorizationResponse(_,_) >> getSuccessResponse(serviceRequestResponseContext)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getAuthorizationResponseStatus()==ResponseStatus.NOT_OFFLOADED
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getSupplier()!=null
    }

    def "send processFlightItem Connection Timeout Exception"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("EY")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * errorMessageListBuilder.getAuthorizationExceptionResponse (_) >> getAuthorizationExceptionResponse()
        1 * serviceTimeoutUtil.setServiceDown(_)
        thrown(ServiceTimeOutException.class)
    }

    def "send processFlightItem - unknown exception"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("AA")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * classUnderTest.getAuthorizationResponse(_,_) >> {throw new Exception("test-error")}
        1 * errorMessageListBuilder.getAuthorizationExceptionResponse (_) >> getAuthorizationExceptionResponse()
        0 * serviceTimeoutUtil.setServiceDown(_)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getAuthorizationResponseStatus()==ResponseStatus.FAILED
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getSegmentResponse()!=null
    }

    def "send setAuthorizationServiceCallTimeout"() {
        when:
        classUnderTest.setAuthorizationServiceCallTimeout(1000)
        def res=classUnderTest.getAuthorizationServiceCallTimeout()
        then:
        res==1000
    }

    def getRequestResponseContext(String airlineCode){

        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setAirlineCode(airlineCode)
        flightDetails.setFlightNumber("123")
        flightDetails.setScheduledDepartureDate(LocalDate.parse("2020-08-20").toString())
        flightDetails.setReservationBookingDesignator("Y")
        flightDetails.setDepartureAirportCode("AUH")
        flightDetails.setArrivalAirportCode("DFW")

        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()
        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.RESERVATION.toString())
        getAirSeatMapRQ.setFlightInfo(List.of(flightDetails))

        ClientInfo clientInfo= ClientInfo.newBuilder()
                .setAgencyCode("AC")
                .setRequester("CID")
                .setRequesterType(RequesterType.GDS)
                .setClientContext("CC")
                .addEprKeywords("EPR1").addEprKeywords("EPR2")
                .build()

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setRequestVersion("1")
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)
        requestResponseContext.setClientInfo(clientInfo)
        requestResponseContext.setRequestInfo(requestInfo)
        requestResponseContext.getFlightItemReqResContextMap().put(1,getFlightItemReqResContext(airlineCode))

        return requestResponseContext
    }

    def getFlightItemReqResContext(String airlineCode){
        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode(airlineCode)
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        FlightItemReqResContext flightItemReqResContext = new FlightItemReqResContext()
        flightItemReqResContext.setSegmentInfo(segmentInfo)

        List<PassengerSeatmapRetrieveRequest> passengerSeatmapRetrieveRequestList = new ArrayList<>()

        PassengerSeatmapRetrieveRequest passengerSeatmapRetrieveRequest = PassengerSeatmapRetrieveRequest.newBuilder()
                .setFirstName("test")
                .setLastName("test")
                .build()

        passengerSeatmapRetrieveRequestList.add(passengerSeatmapRetrieveRequest)
        flightItemReqResContext.setPassengerSeatmapRetrieveRequestList(passengerSeatmapRetrieveRequestList)
        return flightItemReqResContext;
    }

    def getSuccessResponse(WebServiceRequestResponseContext requestResponseContext){
        FlightItemReqResContext flightItemReqResContext=requestResponseContext.getFlightItemReqResContextMap().get(1)

        Supplier mapSupplier = Supplier.newBuilder()
                .setAirlineCode(flightItemReqResContext.getSegmentInfo().getFlightInfo().getAirlineCode())
                .setFlightNumber(flightItemReqResContext.getSegmentInfo().getFlightInfo().getFlightNumber())
                .setDepartureDate(flightItemReqResContext.getSegmentInfo().getFlightInfo().getScheduledDepartureDate())
                .setDepartureAirportCode(flightItemReqResContext.getSegmentInfo().getFlightInfo().getDepartureAirportCode())
                .setArrivalAirportCode(flightItemReqResContext.getSegmentInfo().getFlightInfo().getArrivalAirportCode())
                .build()

        ResponseInfo responseInfoSuccess;

        if(flightItemReqResContext.getSegmentInfo().getFlightInfo().getAirlineCode()=="AA"){
            responseInfoSuccess=ResponseInfo.newBuilder()
                    .setResponseStatus(ResponseStatus.NOT_OFFLOADED)
                    .setReceivedTimestamp(requestResponseContext.getRequestInfo().getTimestamp())
                    .setResponseTimestamp(Instant.now().toString())
                    .build()
        } else{
            responseInfoSuccess=ResponseInfo.newBuilder()
                    .setResponseStatus(ResponseStatus.SUCCESS)
                    .setReceivedTimestamp(requestResponseContext.getRequestInfo().getTimestamp())
                    .setResponseTimestamp(Instant.now().toString())
                    .build()
        }

        return AuthorizationResponse.newBuilder()
                .setRequestInfo(requestResponseContext.getRequestInfo())
                .setResponseInfo(responseInfoSuccess)
                .setSupplier(mapSupplier)
                .build()
    }

    def getAuthorizationExceptionResponse(){

        ResponseInfo responseInfo=ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setResponseTimestamp(Instant.now().toString())
                .addErrorMessages(getProtoErrorMessage()).build()

        return AuthorizationResponse.newBuilder()
                .setResponseInfo(responseInfo)
                .build();
    }

    def getProtoErrorMessage(){
        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("123")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("APPLICATION")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("test")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }
}

