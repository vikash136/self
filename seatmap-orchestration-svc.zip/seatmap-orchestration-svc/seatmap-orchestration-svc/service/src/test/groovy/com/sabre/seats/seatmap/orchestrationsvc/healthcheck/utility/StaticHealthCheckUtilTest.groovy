package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.utility

import spock.lang.Specification

class StaticHealthCheckUtilTest extends Specification {

    def classUnderTest = new StaticHealthCheckUtil()

    def "Test getter and setter"(){
        given:
        Map<String, String> staticHealthCheckMap = new HashMap<>()
        staticHealthCheckMap.put("test","test")
        when:
        classUnderTest.setStaticHealthCheckMap(staticHealthCheckMap)
        def res = classUnderTest.getStaticHealthCheckMap()
        then:
        res == staticHealthCheckMap
    }
}
