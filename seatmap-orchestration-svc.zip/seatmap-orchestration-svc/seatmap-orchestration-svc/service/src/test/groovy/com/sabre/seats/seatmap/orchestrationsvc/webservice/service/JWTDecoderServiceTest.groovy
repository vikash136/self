package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.checkin.jwtdecoder.exception.ESSMKeyNotFoundException
import com.sabre.checkin.jwtdecoder.model.JWTDecodedData
import com.sabre.checkin.jwtdecoder.service.ESSMJwtDecoderService
import com.sabre.checkin.jwtdecoder.service.JWTDecoder
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.service.ESSMService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.converter.JwtDecodedDataToClientInfo
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.NoJwtDecoderTypeException

import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.common.protobuf.ClientInfo
import io.micrometer.core.instrument.simple.SimpleMeterRegistry
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.lang.reflect.Field

class JWTDecoderServiceTest extends Specification {

    def jWTDecoderMock1=Mock(JWTDecoder.class)
    def classUnderTest = Spy(JWTDecoderService)
    JwtDecodedDataToClientInfo jwtDecodedDataToClientInfoClass = Mock(JwtDecodedDataToClientInfo.class)
    ESSMService essmServiceClass = Mock(ESSMService.class)
    def meterRegistry = new SimpleMeterRegistry()

    def setup(){
        Field appId = JWTDecoderService.class.getDeclaredField("appId")
        appId.setAccessible(true)
        appId.set(classUnderTest,"SEATS:SEATMAP_ORCHESTRATION_SVC")

        Field jwtDecoderList = JWTDecoderService.class.getDeclaredField("jwtDecoderList")
        jwtDecoderList.setAccessible(true)
        jwtDecoderList.set(classUnderTest,getJwtDecoder())

        Field essmBaseUrl = JWTDecoderService.class.getDeclaredField("essmBaseUrl")
        essmBaseUrl.setAccessible(true)
        essmBaseUrl.set(classUnderTest,"https://essmws.int.sabre.com/")

        Field jwtDecodedDataToClientInfo = JWTDecoderService.class.getDeclaredField("jwtDecodedDataToClientInfo")
        jwtDecodedDataToClientInfo.setAccessible(true)
        jwtDecodedDataToClientInfo.set(classUnderTest,jwtDecodedDataToClientInfoClass)

        Field essmService = JWTDecoderService.class.getDeclaredField("essmService")
        essmService.setAccessible(true)
        essmService.set(classUnderTest,essmServiceClass)
        ReflectionTestUtils.setField(classUnderTest, "meterRegistry", meterRegistry)

    }

    def "test processRequest"() {
        given:
        WebServiceRequestResponseContext context = new WebServiceRequestResponseContext()
        context.setJwtToken("eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1MjIyMjctQUFTLUFBIiwic2NwIjpbXSwic3ViamVjdF90b2tlbl90eXBlIjoiQVRLIiwia2V5d29yZHMiOlsiQ0hHQUFBIiwiQUdZQUFBIiwiVU5WUEFSIiwiQ1JTQUdUIl0sInN1YmplY3RfdG9rZW5fY3JlYXRpb24iOiIxNjAzMDkxMDUxIiwic3ViamVjdF90b2tlbl9leHBpcmF0aW9uIjoiMTYwMzY5NTg1MSIsImlzcyI6Imh0dHBzOi8vZXNzbXdzLmludC5zYWJyZS5jb20vIiwiZHV0eV9jb2RlcyI6WyIwIiwiMSIsIjIiLCI0IiwiNSIsIjYiLCI3IiwiOCIsIjkiLCIkIiwiIyIsIioiLCItIiwiLyJdLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDU0VBVFM6U0VBVE1BUF9PUkNIRVNUUkFUSU9OX1NWQyIsImF1ZCI6ImludC1hdWQiLCJ1aWQiOiI1MjIyMjciLCJob21lX2NpdHkiOiJIRFEiLCJuYmYiOjE2MDMwOTEwNTEsImFnZW50X3NpZ24iOiJIM00iLCJkb21haW4iOiJBQSIsImV4cCI6MTYwMzA5MTM1MSwiaWF0IjoxNjAzMDkxMDUxLCJpYXRhX251bWJlciI6Ijk5OTk5OTkiLCJzdWJqZWN0X3Rva2VuIjoiVDFSTEFRTERwYVZRS2xTLzN6aHl4KzB0QnEwTElDRXdWUkI0N0dha2NLSHJsaklBRWtKWXRBZHJBQURRMVpzQTVRdG5KQ2pSU3ZaZTJ3em9PQ1U5MjZLMjRmeVFGVkYrL0h5OUUxZWlNSWxCRHdkNm1UYjdJTTNQcHZhNXZzczdjS3hZOFM0OEZ3RW1lSzNSYjVjck1BaEFTSVhPTzVZbUhLcnNtc055QlJHWk1zMWFpUEJWdFVoeEFiZXJZOW56eVNzV0J1c0orcWhyUjdaWlZwdkdoNUwrV1FYZHRWb0ZlcFlCODZISEd0YmRtVStzVHNXZ1hxWC83VE83TzUzTkYzaHRQc242TEh1SjA3eWQwczMwZEdUcWJsS01PMEV3UnhGejFaUUJtZEptbUdTR2ZleHRjREpDYzJOeGRuSU5RTmlpZ2o1VUV3SXJwMXl5RHcqKiIsImp0aSI6IjE2MDMwOTEwNTE5MzgwMDAwMDAiLCJncm91cCI6IkFBUyJ9.I77jsUuKTQiduNWw021UMBWqR0IUz43D6jZ9ig7rsuhuvQz9KlCav6ihDe1sCyb9kW3fDIBdCCSDWaoWtrTnoCXxL4FNBOMXpG663Pkmi9sVPnqieVEhjll02n5IhYHDeieqk7JRA0G05wP2xWDpELED0nSTWzeIXu8VfDUXpkldxrpsvXCHgjDTVrWDqkxZ43IE4f39T8JWV9SLk7I6LJJXJSovnDhAKQBv6YnPirbi5DgETKX5CS8IM07F_efp9Meq-HXRK56V41lnC57fkWerOTovOZbwAxEYua8Y3vOj1bt2CduujA3QCU-rtSh6tM-ItVm776AtxTmzFyl6VQ")
        context.setTjrToken("eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1MjIyMjctQUFTLUFBIiwic2NwIjpbXSwic3ViamVjdF90b2tlbl90eXBlIjoiQVRLIiwia2V5d29yZHMiOlsiQ0hHQUFBIiwiQUdZQUFBIiwiVU5WUEFSIiwiQ1JTQUdUIl0sInN1YmplY3RfdG9rZW5fY3JlYXRpb24iOiIxNjAzMDkxMDUxIiwic3ViamVjdF90b2tlbl9leHBpcmF0aW9uIjoiMTYwMzY5NTg1MSIsImlzcyI6Imh0dHBzOi8vZXNzbXdzLmludC5zYWJyZS5jb20vIiwiZHV0eV9jb2RlcyI6WyIwIiwiMSIsIjIiLCI0IiwiNSIsIjYiLCI3IiwiOCIsIjkiLCIkIiwiIyIsIioiLCItIiwiLyJdLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDU0VBVFM6U0VBVE1BUF9PUkNIRVNUUkFUSU9OX1NWQyIsImF1ZCI6ImludC1hdWQiLCJ1aWQiOiI1MjIyMjciLCJob21lX2NpdHkiOiJIRFEiLCJuYmYiOjE2MDMwOTEwNTEsImFnZW50X3NpZ24iOiJIM00iLCJkb21haW4iOiJBQSIsImV4cCI6MTYwMzA5MTM1MSwiaWF0IjoxNjAzMDkxMDUxLCJpYXRhX251bWJlciI6Ijk5OTk5OTkiLCJzdWJqZWN0X3Rva2VuIjoiVDFSTEFRTERwYVZRS2xTLzN6aHl4KzB0QnEwTElDRXdWUkI0N0dha2NLSHJsaklBRWtKWXRBZHJBQURRMVpzQTVRdG5KQ2pSU3ZaZTJ3em9PQ1U5MjZLMjRmeVFGVkYrL0h5OUUxZWlNSWxCRHdkNm1UYjdJTTNQcHZhNXZzczdjS3hZOFM0OEZ3RW1lSzNSYjVjck1BaEFTSVhPTzVZbUhLcnNtc055QlJHWk1zMWFpUEJWdFVoeEFiZXJZOW56eVNzV0J1c0orcWhyUjdaWlZwdkdoNUwrV1FYZHRWb0ZlcFlCODZISEd0YmRtVStzVHNXZ1hxWC83VE83TzUzTkYzaHRQc242TEh1SjA3eWQwczMwZEdUcWJsS01PMEV3UnhGejFaUUJtZEptbUdTR2ZleHRjREpDYzJOeGRuSU5RTmlpZ2o1VUV3SXJwMXl5RHcqKiIsImp0aSI6IjE2MDMwOTEwNTE5MzgwMDAwMDAiLCJncm91cCI6IkFBUyJ9.I77jsUuKTQiduNWw021UMBWqR0IUz43D6jZ9ig7rsuhuvQz9KlCav6ihDe1sCyb9kW3fDIBdCCSDWaoWtrTnoCXxL4FNBOMXpG663Pkmi9sVPnqieVEhjll02n5IhYHDeieqk7JRA0G05wP2xWDpELED0nSTWzeIXu8VfDUXpkldxrpsvXCHgjDTVrWDqkxZ43IE4f39T8JWV9SLk7I6LJJXJSovnDhAKQBv6YnPirbi5DgETKX5CS8IM07F_efp9Meq-HXRK56V41lnC57fkWerOTovOZbwAxEYua8Y3vOj1bt2CduujA3QCU-rtSh6tM-ItVm776AtxTmzFyl6VQ")
        when:
        classUnderTest.processRequest(context)
        then:
        2 * classUnderTest.getJwtDecoder(_) >> jWTDecoderMock1
        2 * jWTDecoderMock1.validateAndDecodeJWTToken(_) >> Optional.of(new JWTDecodedData())

    }


    def "test Decode for NoJwtDecoderTypeException"() {
        given:
        Field decoderType = JWTDecoderService.class.getDeclaredField("decoderType")
        decoderType.setAccessible(true)
        decoderType.set(classUnderTest,"dummy")

        when:
        classUnderTest.processRequest(new WebServiceRequestResponseContext())

        then:
        thrown(NoJwtDecoderTypeException)
    }

    def "test Decode for ESSMKeyNotFoundException"() {
        given:
        WebServiceRequestResponseContext context = new WebServiceRequestResponseContext()
        context.setJwtToken("eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1MjIyMjctQUFTLUFBIiwic2NwIjpbXSwic3ViamVjdF90b2tlbl90eXBlIjoiQVRLIiwia2V5d29yZHMiOlsiQ0hHQUFBIiwiQUdZQUFBIiwiVU5WUEFSIiwiQ1JTQUdUIl0sInN1YmplY3RfdG9rZW5fY3JlYXRpb24iOiIxNjAzMDkxMDUxIiwic3ViamVjdF90b2tlbl9leHBpcmF0aW9uIjoiMTYwMzY5NTg1MSIsImlzcyI6Imh0dHBzOi8vZXNzbXdzLmludC5zYWJyZS5jb20vIiwiZHV0eV9jb2RlcyI6WyIwIiwiMSIsIjIiLCI0IiwiNSIsIjYiLCI3IiwiOCIsIjkiLCIkIiwiIyIsIioiLCItIiwiLyJdLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDU0VBVFM6U0VBVE1BUF9PUkNIRVNUUkFUSU9OX1NWQyIsImF1ZCI6ImludC1hdWQiLCJ1aWQiOiI1MjIyMjciLCJob21lX2NpdHkiOiJIRFEiLCJuYmYiOjE2MDMwOTEwNTEsImFnZW50X3NpZ24iOiJIM00iLCJkb21haW4iOiJBQSIsImV4cCI6MTYwMzA5MTM1MSwiaWF0IjoxNjAzMDkxMDUxLCJpYXRhX251bWJlciI6Ijk5OTk5OTkiLCJzdWJqZWN0X3Rva2VuIjoiVDFSTEFRTERwYVZRS2xTLzN6aHl4KzB0QnEwTElDRXdWUkI0N0dha2NLSHJsaklBRWtKWXRBZHJBQURRMVpzQTVRdG5KQ2pSU3ZaZTJ3em9PQ1U5MjZLMjRmeVFGVkYrL0h5OUUxZWlNSWxCRHdkNm1UYjdJTTNQcHZhNXZzczdjS3hZOFM0OEZ3RW1lSzNSYjVjck1BaEFTSVhPTzVZbUhLcnNtc055QlJHWk1zMWFpUEJWdFVoeEFiZXJZOW56eVNzV0J1c0orcWhyUjdaWlZwdkdoNUwrV1FYZHRWb0ZlcFlCODZISEd0YmRtVStzVHNXZ1hxWC83VE83TzUzTkYzaHRQc242TEh1SjA3eWQwczMwZEdUcWJsS01PMEV3UnhGejFaUUJtZEptbUdTR2ZleHRjREpDYzJOeGRuSU5RTmlpZ2o1VUV3SXJwMXl5RHcqKiIsImp0aSI6IjE2MDMwOTEwNTE5MzgwMDAwMDAiLCJncm91cCI6IkFBUyJ9.I77jsUuKTQiduNWw021UMBWqR0IUz43D6jZ9ig7rsuhuvQz9KlCav6ihDe1sCyb9kW3fDIBdCCSDWaoWtrTnoCXxL4FNBOMXpG663Pkmi9sVPnqieVEhjll02n5IhYHDeieqk7JRA0G05wP2xWDpELED0nSTWzeIXu8VfDUXpkldxrpsvXCHgjDTVrWDqkxZ43IE4f39T8JWV9SLk7I6LJJXJSovnDhAKQBv6YnPirbi5DgETKX5CS8IM07F_efp9Meq-HXRK56V41lnC57fkWerOTovOZbwAxEYua8Y3vOj1bt2CduujA3QCU-rtSh6tM-ItVm776AtxTmzFyl6VQ")
        context.setTjrToken("eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1MjIyMjctQUFTLUFBIiwic2NwIjpbXSwic3ViamVjdF90b2tlbl90eXBlIjoiQVRLIiwia2V5d29yZHMiOlsiQ0hHQUFBIiwiQUdZQUFBIiwiVU5WUEFSIiwiQ1JTQUdUIl0sInN1YmplY3RfdG9rZW5fY3JlYXRpb24iOiIxNjAzMDkxMDUxIiwic3ViamVjdF90b2tlbl9leHBpcmF0aW9uIjoiMTYwMzY5NTg1MSIsImlzcyI6Imh0dHBzOi8vZXNzbXdzLmludC5zYWJyZS5jb20vIiwiZHV0eV9jb2RlcyI6WyIwIiwiMSIsIjIiLCI0IiwiNSIsIjYiLCI3IiwiOCIsIjkiLCIkIiwiIyIsIioiLCItIiwiLyJdLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDU0VBVFM6U0VBVE1BUF9PUkNIRVNUUkFUSU9OX1NWQyIsImF1ZCI6ImludC1hdWQiLCJ1aWQiOiI1MjIyMjciLCJob21lX2NpdHkiOiJIRFEiLCJuYmYiOjE2MDMwOTEwNTEsImFnZW50X3NpZ24iOiJIM00iLCJkb21haW4iOiJBQSIsImV4cCI6MTYwMzA5MTM1MSwiaWF0IjoxNjAzMDkxMDUxLCJpYXRhX251bWJlciI6Ijk5OTk5OTkiLCJzdWJqZWN0X3Rva2VuIjoiVDFSTEFRTERwYVZRS2xTLzN6aHl4KzB0QnEwTElDRXdWUkI0N0dha2NLSHJsaklBRWtKWXRBZHJBQURRMVpzQTVRdG5KQ2pSU3ZaZTJ3em9PQ1U5MjZLMjRmeVFGVkYrL0h5OUUxZWlNSWxCRHdkNm1UYjdJTTNQcHZhNXZzczdjS3hZOFM0OEZ3RW1lSzNSYjVjck1BaEFTSVhPTzVZbUhLcnNtc055QlJHWk1zMWFpUEJWdFVoeEFiZXJZOW56eVNzV0J1c0orcWhyUjdaWlZwdkdoNUwrV1FYZHRWb0ZlcFlCODZISEd0YmRtVStzVHNXZ1hxWC83VE83TzUzTkYzaHRQc242TEh1SjA3eWQwczMwZEdUcWJsS01PMEV3UnhGejFaUUJtZEptbUdTR2ZleHRjREpDYzJOeGRuSU5RTmlpZ2o1VUV3SXJwMXl5RHcqKiIsImp0aSI6IjE2MDMwOTEwNTE5MzgwMDAwMDAiLCJncm91cCI6IkFBUyJ9.I77jsUuKTQiduNWw021UMBWqR0IUz43D6jZ9ig7rsuhuvQz9KlCav6ihDe1sCyb9kW3fDIBdCCSDWaoWtrTnoCXxL4FNBOMXpG663Pkmi9sVPnqieVEhjll02n5IhYHDeieqk7JRA0G05wP2xWDpELED0nSTWzeIXu8VfDUXpkldxrpsvXCHgjDTVrWDqkxZ43IE4f39T8JWV9SLk7I6LJJXJSovnDhAKQBv6YnPirbi5DgETKX5CS8IM07F_efp9Meq-HXRK56V41lnC57fkWerOTovOZbwAxEYua8Y3vOj1bt2CduujA3QCU-rtSh6tM-ItVm776AtxTmzFyl6VQ")
        when:
        classUnderTest.processRequest(context)

        then:
        1 * classUnderTest.getJwtDecoder(_) >> jWTDecoderMock1
        1 * jWTDecoderMock1.validateAndDecodeJWTToken(_) >> {throw new ESSMKeyNotFoundException()}
        thrown(ESSMKeyNotFoundException)
    }


    def "test RefreshJWTTokens"() {
        when:
        def status = classUnderTest.refreshJWTTokens()

        then:
        1 * classUnderTest.getJwtDecoder(_) >> jWTDecoderMock1
        1 * jWTDecoderMock1.refreshJWTTokens(_) >> true
        status
    }

    def "test RefreshJWTTokens for invalid decoder"() {
        given:
        Field decoderType = JWTDecoderService.class.getDeclaredField("decoderType")
        decoderType.setAccessible(true)
        decoderType.set(classUnderTest,"dummy")

        when:
        def status = classUnderTest.refreshJWTTokens()

        then:
        !status
    }

    def "test getJwtDecoder"() {
        when:
        def result = classUnderTest.getJwtDecoder("essm")

        then:
        result != null
    }


    def getJwtDecoder() {
        List<JWTDecoder> jwtDecoderList = new ArrayList<>()
        jwtDecoderList.add(new ESSMJwtDecoderService())
        return jwtDecoderList
    }

}
