package com.sabre.seats.seatmap.orchestrationsvc.webservice.config

import com.marcnuri.yakc.KubernetesClient
import com.marcnuri.yakc.config.Configuration
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class KubernetesClientClusterServiceTest extends Specification {

    def SEATS_EDGE_CLUSTER_NAMESPACE = "test-seats-edge-cluster"
    def SEATS_AUTHORIZATION_SERVICE_NAME = "test-seats-authorization-service"
    def mockKubernetesClient = Mock(KubernetesClient.class)
    def mockConfiguration = Mock(Configuration.class)
    def kubernetesClientClusterService = new KubernetesClientClusterConfigService()

    def setup() {
        kubernetesClientClusterService.authorizationServiceName = SEATS_AUTHORIZATION_SERVICE_NAME
        ReflectionTestUtils.setField(kubernetesClientClusterService, "kubernetesClient", mockKubernetesClient)
    }

    def "test get kubernetes namespace"() {
        when:
        kubernetesClientClusterService.init()
        def namespace = kubernetesClientClusterService.getNamespace()

        then:
        2 * mockKubernetesClient.getConfiguration() >> mockConfiguration
        1 * mockConfiguration.getNamespace() >> SEATS_EDGE_CLUSTER_NAMESPACE
        namespace == SEATS_EDGE_CLUSTER_NAMESPACE
    }

    def "test get kubernetes namespace when no configuration available"() {
        when:
        kubernetesClientClusterService.init()
        def namespace = kubernetesClientClusterService.getNamespace()

        then:
        1 * mockKubernetesClient.getConfiguration() >> null
        namespace == ""
    }

    def "test get get seats connectivity service host name"() {
        when:
        kubernetesClientClusterService.init()
        def authorizationServiceHostName = kubernetesClientClusterService.getAuthorizationServiceHostName()

        then:
        2 * mockKubernetesClient.getConfiguration() >> mockConfiguration
        1 * mockConfiguration.getNamespace() >> SEATS_EDGE_CLUSTER_NAMESPACE
        authorizationServiceHostName == String.format("%s.%s.svc.cluster.local", SEATS_AUTHORIZATION_SERVICE_NAME, SEATS_EDGE_CLUSTER_NAMESPACE)
    }

}
