package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller


import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TestGrpcService
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import spock.lang.Specification

class TestGrpcServiceControllerTest extends Specification{

    def controller = new TestGrpcServiceController()
    def testGrpcServiceMock= Mock(TestGrpcService.class)


    def setup(){
        controller.testGrpcService=testGrpcServiceMock
    }

    def "test getResponseFromGrpcService"(){

        when:
        def res=controller.getResponseFromGrpcService(new AirSeatMapRequest(), "token","1","123","12345")

        then:
        1 * testGrpcServiceMock.testGrpcService(_) >> "Sample Result"
        res!=null
    }
}
