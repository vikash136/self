package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.service


import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServerResponse
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.JWTDecoderService
import spock.lang.Specification

import java.util.concurrent.atomic.AtomicInteger

class ESSMServiceTest extends Specification {

    def serviceHealthCheckStore = Mock(ServiceHealthCheckStore.class)
    def jwtDecoderService = Mock(JWTDecoderService.class)

    def classUnderTest = new ESSMService(dynamicServiceRetryCount: 3)

    def setup() {
        classUnderTest.serviceHealthCheckStore=serviceHealthCheckStore
        classUnderTest.jwtDecoderService=jwtDecoderService
    }

    def "Increase retry count of essm service and set Essm Down if retry count 2"() {
        when:
        classUnderTest.setEssmDown()
        then:
        1 * serviceHealthCheckStore.getRetryCount(_) >> new AtomicInteger(2)
        1 * serviceHealthCheckStore.setRetryCount(_,_)
        1 * serviceHealthCheckStore.getDynamicHealthCheckMap() >> new HashMap<>()
        1 * serviceHealthCheckStore.setServiceComponentDown(_,_)
    }

    def "Increase retry count of essm service if retry count 0"() {
        when:
        classUnderTest.setEssmDown()
        then:
        1 * serviceHealthCheckStore.getRetryCount(_) >> new AtomicInteger(0)
        1 * serviceHealthCheckStore.setRetryCount(_,_)
        0 * serviceHealthCheckStore.getDynamicHealthCheckMap() >> new HashMap<>()
        0 * serviceHealthCheckStore.setServiceComponentDown(_,_)
    }

    def "keep retry count same if retry count greaer than or equal to 3"() {
        when:
        classUnderTest.setEssmDown()
        then:
        1 * serviceHealthCheckStore.getRetryCount(_) >> new AtomicInteger(4)
        0 * serviceHealthCheckStore.setRetryCount(_,_)
        0 * serviceHealthCheckStore.getDynamicHealthCheckMap() >> new HashMap<>()
        0 * serviceHealthCheckStore.setServiceComponentDown(_,_)
    }

    def "should return Essm Status equals Serving if refreshJWTTokens return true"() {
        when:
        String status= classUnderTest.getEssmStatus(new HashMap<String, String>())
        then:
        1 * jwtDecoderService.refreshJWTTokens() >> true
        status.equals(ServerResponse.SERVING.name())
    }

    def "should return Essm Status equals Serving if refreshJWTTokens return false"() {
        when:
        String status= classUnderTest.getEssmStatus(new HashMap<String, String>())
        then:
        1 * jwtDecoderService.refreshJWTTokens() >> false
        status.equals(ServerResponse.NOT_SERVING.name())
    }
}
