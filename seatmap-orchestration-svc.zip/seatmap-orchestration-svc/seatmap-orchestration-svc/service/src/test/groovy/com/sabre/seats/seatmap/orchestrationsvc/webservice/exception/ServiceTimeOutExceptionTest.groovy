package com.sabre.seats.seatmap.orchestrationsvc.webservice.exception

import spock.lang.Specification

class ServiceTimeOutExceptionTest extends Specification{

    def "Test Constructor"(){

        when :
           def res = new ServiceTimeOutException("Test")
        then :
            res.getMessage().equalsIgnoreCase("Test")

    }
}
