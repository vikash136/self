package com.sabre.seats.seatmap.orchestrationsvc

import com.sabre.seats.seatmap.orchestrationsvc.configuration.OpenAPIConfig
import spock.lang.Specification

class OpenAPIConfigTest extends Specification{

    def classUnderTest = new OpenAPIConfig()
    def " test - api"() {
        when:
        def response = classUnderTest.customOpenAPI()
        then:
        response != null
    }
}
