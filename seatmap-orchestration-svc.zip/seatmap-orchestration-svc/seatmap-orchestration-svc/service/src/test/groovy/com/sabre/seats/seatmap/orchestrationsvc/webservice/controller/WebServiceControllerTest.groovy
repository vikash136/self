package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller

import com.sabre.checkin.jwtdecoder.handler.ESSMKeyStoreHandler
import com.sabre.checkin.jwtdecoder.keystore.ESSMPublicKeyStore
import com.sabre.checkin.jwtdecoder.model.ESSMKeyValue
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.ServiceTimeoutEnum
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.GetAirSeatMapService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.SeatmapSupplierService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import spock.lang.Specification

class WebServiceControllerTest extends Specification{
    def controller = new WebServiceController()
    def getAirSeatMapService = Mock(GetAirSeatMapService.class)
    def essmPublicKeyStore=Mock(ESSMPublicKeyStore.class)
    def essmKeyStoreHandler = Mock(ESSMKeyStoreHandler.class)
    def seatmapCoreService = Mock(SeatmapSupplierService.class)
    def serviceTimeoutUtil = Mock(ServiceTimeoutUtil.class)
    def token="eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9"

    def setup(){
        controller.getAirSeatMapService = getAirSeatMapService
        controller.essmPublicKeyStore = essmPublicKeyStore
        controller.essmKeyStoreHandler = essmKeyStoreHandler
        controller.seatmapSupplierService = seatmapCoreService
        controller.serviceTimeoutUtil = serviceTimeoutUtil
    }

    def "test getResponseFromGrpcService"(){

        when:
        def res=controller.getSeatMap(new AirSeatMapRequest(), "token","tjrtoken","123","12345","123")

        then:
        1 * getAirSeatMapService.handleRequest(_) >> new AirSeatMapResponse()
        res!=null
    }

    def "test getResponseFromGrpcServicevaluesNull"(){

        when:
        def res=controller.getSeatMap(new AirSeatMapRequest(), "token","tjrtoken","","","123")

        then:
        1 * getAirSeatMapService.handleRequest(_) >> new AirSeatMapResponse()
        res!=null
    }

    def "test changeEssmServiceState"(){

        given:
        Map<String, ESSMKeyValue> keyStore = new HashMap<>()
        keyStore.put("test1", new ESSMKeyValue())
        keyStore.put("test2", new ESSMKeyValue())

        when:
        controller.changeEssmServiceState(true, true)

        then:
        1 * essmPublicKeyStore.getEssmPublicKeyStore() >> keyStore
        1 * essmKeyStoreHandler.setToggleEssmService(_)

        when:
        controller.changeEssmServiceState(true, false)

        then:
        0 * essmPublicKeyStore.getEssmPublicKeyStore()
        1 * essmKeyStoreHandler.setToggleEssmService(_)
    }

    def "test getServiceTimeout"(){
        when:
        def res=controller.getServiceTimeout(ServiceTimeoutEnum.AUTH_TRANSFORMATION)

        then:
        1 * serviceTimeoutUtil.getServiceTimeout(_) >> 5000
        res.body==5000
    }

    def "test setServiceTimeout"(){
        when:
       controller.setServiceTimeout(ServiceTimeoutEnum.AUTH_TRANSFORMATION,"5000")

        then:
        1 * serviceTimeoutUtil.setServiceTimeout(_,_)
    }


    def "test getSeatMapFromCore"(){
        given:
        String url = "Sample URL"
        String request = "Sample body"
        String transactionId = "1234"
        String correlationId = "567"

        when:
        controller.getSeatMapFromCore(request, url,token, transactionId, correlationId)

        then:
        1 * seatmapCoreService.getSeatMapFromCore(url, request,token, transactionId, correlationId) >> "Sample Result"
    }
}
