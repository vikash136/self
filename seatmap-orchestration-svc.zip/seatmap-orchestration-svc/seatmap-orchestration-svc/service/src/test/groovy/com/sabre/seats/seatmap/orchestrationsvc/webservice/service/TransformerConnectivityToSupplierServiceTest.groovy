package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.google.protobuf.LazyStringArrayList
import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.common.protobuf.*
import com.sabre.seats.connectivity.protobuf.ConnectivityConfiguration
import com.sabre.seats.error.protobuf.Description
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.error.protobuf.MessageCode
import com.sabre.seats.transformation.protobuf.MessageType
import com.sabre.seats.transformation.protobuf.SeatMapOutputReqResponse
import com.sabre.seats.transformation.protobuf.TransformReqResponse
import io.grpc.ManagedChannelBuilder
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class TransformerConnectivityToSupplierServiceTest extends Specification {

    def classUnderTest = Spy(TransformerConnectivityToSupplierService)
    def errorMessageListBuilder = Mock(ErrorMessageListBuilder.class)
    def serviceTimeoutUtil = Mock(ServiceTimeoutUtil.class)
    def transformChannel = ManagedChannelBuilder.forTarget("localhost").usePlaintext().build()

    def setup() {
        ReflectionTestUtils.setField(classUnderTest, "transformationServiceCallTimeout", 5000)
        ReflectionTestUtils.setField(classUnderTest, "errorMessageListBuilder", errorMessageListBuilder)
        ReflectionTestUtils.setField(classUnderTest, "serviceTimeoutUtil", serviceTimeoutUtil)
        ReflectionTestUtils.setField(classUnderTest, "transformationServiceVersion", "1")
        ReflectionTestUtils.setField(classUnderTest, "transformChannel", transformChannel)
    }

    def "send processRequest"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(reqRespContext,1)

        then:
        1 * classUnderTest.getTransformationResponse(_,_) >> getSuccessTransformationResponse()
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierRequestStatus()==ResponseStatus.SUCCESS
        reqRespContext.getFlightItemReqResContextMap().get(1).getSupplierRequestFromTransformer()=="test"
    }

    def "send processRequest - TPF"() {
        given:
        def reqRespContext=getRequestResponseContext("MN")

        when:
        classUnderTest.processFlightItem(reqRespContext,1)

        then:
        1 * classUnderTest.getTransformationResponse(_,_) >> getSuccessTransformationResponse()
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierRequestStatus()==ResponseStatus.SUCCESS
        reqRespContext.getFlightItemReqResContextMap().get(1).getSupplierRequestFromTransformer()=="test"
    }

    def "send processRequest - connection time out"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(reqRespContext, 1)

        then:
        1 * serviceTimeoutUtil.setServiceDown(_)
        1 * errorMessageListBuilder.getTransformerExceptionResponse(_) >> getFailedTransformationResponse()
        thrown(ServiceTimeOutException.class)
    }

    def "send processRequest - Unknown exception"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(reqRespContext, 1)

        then:
        1 * classUnderTest.getTransformationResponse(_,_) >> {throw new Exception("test error")}
        1 * errorMessageListBuilder.getTransformerExceptionResponse(_) >> getFailedTransformationResponse()
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierRequestStatus()==ResponseStatus.FAILED
        reqRespContext.getFlightItemReqResContextMap().get(1).getSupplierRequestFromTransformer()==null
    }

    def "send processRequest - connectivity service call is failed"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")
        reqRespContext.getFlightItemReqResContextMap().get(1).setConnectivityResponseStatus(ResponseStatus.FAILED)

        when:
        classUnderTest.processFlightItem(reqRespContext,1)
        then:
        0 * classUnderTest.getTransformationResponse(_,_)
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierRequestStatus()==null
        reqRespContext.getFlightItemReqResContextMap().get(1).getSupplierRequestFromTransformer()==null

        when:
        reqRespContext.getFlightItemReqResContextMap().get(1).setConnectivityResponseStatus(ResponseStatus.SUCCESS)
        reqRespContext.getFlightItemReqResContextMap().get(1).setConnectivityConfiguration(null)
        classUnderTest.processFlightItem(reqRespContext,1)
        then:
        0 * classUnderTest.getTransformationResponse(_,_)
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierRequestStatus()==null
        reqRespContext.getFlightItemReqResContextMap().get(1).getSupplierRequestFromTransformer()==null

        when:
        reqRespContext.getFlightItemReqResContextMap().get(1).setConnectivityResponseStatus(ResponseStatus.FAILED)
        reqRespContext.getFlightItemReqResContextMap().get(1).setConnectivityConfiguration(null)
        classUnderTest.processFlightItem(reqRespContext,1)
        then:
        0 * classUnderTest.getTransformationResponse(_,_)
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierRequestStatus()==null
        reqRespContext.getFlightItemReqResContextMap().get(1).getSupplierRequestFromTransformer()==null
    }

    def "send setTransformationServiceCallTimeout"() {
        when:
        classUnderTest.setTransformationServiceCallTimeout(5000)
        def res=classUnderTest.getTransformationServiceCallTimeout()
        then:
        res==5000
    }

    def getRequestResponseContext(String airlineCode){
        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setAirlineCode(airlineCode)
        flightDetails.setFlightNumber("123")
        flightDetails.setScheduledDepartureDate(LocalDate.parse("2020-08-20").toString())
        flightDetails.setReservationBookingDesignator("Y")
        flightDetails.setDepartureAirportCode("AUH")
        flightDetails.setArrivalAirportCode("DFW")

        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()

        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.RESERVATION.toString())
        getAirSeatMapRQ.setFlightInfo(List.of(flightDetails))

        ClientInfo clientInfo= ClientInfo.newBuilder()
                .setAgencyCode("AC")
                .setRequester(airlineCode=="I0"?"CID":"")
                .setRequesterType(RequesterType.GDS)
                .setClientContext("CC")
                .addEprKeywords("EPR1").addEprKeywords("EPR2")
                .build()

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setRequestVersion("1")
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)
        requestResponseContext.setClientInfo(clientInfo)
        requestResponseContext.setRequestInfo(requestInfo)
        requestResponseContext.getFlightItemReqResContextMap().put(1,getFlightItemReqResContext(airlineCode))

        return requestResponseContext
    }

    def getFlightItemReqResContext(String airlineCode){
        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode(airlineCode)
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        Supplier supplier = Supplier.newBuilder()
                .setAirlineCode(airlineCode)
                .build()

        FlightItemReqResContext flightItemReqResContext = new FlightItemReqResContext()
        flightItemReqResContext.setSegmentInfo(segmentInfo)
        flightItemReqResContext.setSupplier(supplier)
        flightItemReqResContext.setPassengerSeatmapRetrieveRequestList(getPassengerList())
        flightItemReqResContext.setConnectivityResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setConnectivityConfiguration(getConnectivityConfiguration(airlineCode))

        return flightItemReqResContext
    }

    def getConnectivityConfiguration(String airlineCode){

        if(airlineCode == "MN"){
            return ConnectivityConfiguration.newBuilder()
                    .setPlatform("TPF")
                    .setApiVersion("01")
                    .setMessageFormat(MessageFormat.ATB)
                    .setMessageRequestType(MessageType.SMPREQ)
                    .setApiVersion("1")
                    .setConnectivityType("Mock TPF Connection")
                    .setConnectivityDestination("http://localhost:8080/tpf/mock")
                    .build()

        } else{
            return ConnectivityConfiguration.newBuilder()
                    .setPlatform("SMH")
                    .setApiVersion("1")
                    .setMessageRequestType(MessageType.SEAT_MAP_CORE_REQUEST)
                    .setApiVersion("1")
                    .setMessageFormat(MessageFormat.JSON)
                    .setConnectivityType("Mock Connection")
                    .setConnectivityDestination("http://localhost:8080/v1/seatscore/seatmap")
                    .build()
        }

    }
    def getSuccessTransformationResponse(){

        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setTransformReqResponse("test")
                .build()

        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build()
    }

    def getFailedTransformationResponse(){
        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getFailedResponse())
                .build();

        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build();
    }

    def getSuccessResponse(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.SUCCESS)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .build()
    }

    def getFailedResponse(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .addErrorMessages(getProtoErrorMessage())
                .build()
    }

    def getProtoErrorMessage(){
        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("123")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("APPLICATION")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("test")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }

    def getPassengerList () {
        List<PassengerSeatmapRetrieveRequest> passengerSeatmapRetrieveRequestList = new ArrayList<>()
        PassengerSeatmapRetrieveRequest passengerSeatmapRetrieveRequest = PassengerSeatmapRetrieveRequest.newBuilder()
                .setPassengerReferenceId("27817218")
                .setLastName("ANIL")
                .setFirstName("SHARMA")
                .addPassengerCharacteristics(getCharacteristics())
                .build()
        passengerSeatmapRetrieveRequestList.add(passengerSeatmapRetrieveRequest)
        return passengerSeatmapRetrieveRequestList
    }

    def getCharacteristics () {
        List<Characteristics> characteristicsList = new ArrayList<>()
        Characteristics characteristics = Characteristics.newBuilder()
                .setCodeContext(CodeContext.PAX_TIER)
                .addCodes("2")
                .build()
        characteristicsList.add(characteristics)
        return characteristicsList
    }
}
