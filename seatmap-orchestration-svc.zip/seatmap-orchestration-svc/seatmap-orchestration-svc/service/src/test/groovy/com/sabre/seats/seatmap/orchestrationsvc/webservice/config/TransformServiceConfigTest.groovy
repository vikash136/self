package com.sabre.seats.seatmap.orchestrationsvc.webservice.config

import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class TransformServiceConfigTest extends Specification{

    def transformServiceConfig= new TransformServiceConfig()

    def setup() {
        ReflectionTestUtils.setField(transformServiceConfig, "transformServiceUrl", "test-seats-transformation-service.seats-edge-cluster.svc.cluster.local")
        ReflectionTestUtils.setField(transformServiceConfig, "transformServicePort", 8090)
        ReflectionTestUtils.setField(transformServiceConfig, "keepAliveTime", 30000)
    }

    def "test"(){
        when:
        def channel=transformServiceConfig.getTransformManagedChannel()
        then:
        channel!=null
    }
}
