package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers


import io.grpc.health.v1.HealthCheckRequest
import io.grpc.health.v1.HealthCheckResponse
import io.grpc.stub.StreamObserver
import spock.lang.Specification

class MockHealthCheckServiceTest extends Specification{

    def classUnderTest = Spy(MockHealthCheckService.class)

    def "test getMockHealthCheckResponse"() {

        when:
        classUnderTest.check(getHealthCheckRequest(), getResponseObserver())

        then:
        true
    }

    def getResponseObserver() {
        return new StreamObserver<HealthCheckResponse>() {

            @Override
            void onNext(HealthCheckResponse healthCheckResponse) {
                System.out.println("HealthCheckResponse response " + HealthCheckResponse.toString())
            }

            @Override
            void onError(Throwable throwable) {
            }

            @Override
            void onCompleted() {
            }
        }
    }

    def "test getMockHealthCheckResponse -Failure"() {
        when:
        classUnderTest.check(getFailedHealthCheckRequest(), getResponseObserver())
        then:
        true
    }

    def getHealthCheckRequest(){
        return HealthCheckRequest.newBuilder()
                .setService("orchestrationService")
                .build()
    }

    def getFailedHealthCheckRequest(){
        return HealthCheckRequest.newBuilder()
                .setService("getSeatmap")
                .build()
    }
}
