package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers

import com.sabre.seats.common.protobuf.RequestInfo
import com.sabre.seats.common.protobuf.SeatAction
import com.sabre.seats.common.protobuf.SupplierType
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationRequest
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationResponse
import io.grpc.stub.StreamObserver
import spock.lang.Specification

import java.time.Instant

class MockConnectivityServiceTest extends Specification{

    def classUnderTest = Spy(MockConectivityService.class)

    def "test getMockConnectivityResponse"() {

        when:
        classUnderTest.getConnectivityConfiguration(getConnectivityConfigurationRequest("I0"), getResponseObserver())

        then:
        true
    }

    def "test getMockConnectivityResponseForNonOffloaded"() {

        when:
        classUnderTest.getConnectivityConfiguration(getConnectivityConfigurationRequest("MN"), getResponseObserver())

        then:
        true
    }


    def "test getMockConnectivityResponse -Failure"() {
        when:
        classUnderTest.getConnectivityConfiguration(getConnectivityConfigurationRequest("EY"), getResponseObserver())
        then:
        true
    }

    def "test getMockConnectivityResponse exception"() {
        when:
        classUnderTest.getConnectivityConfiguration(null, getResponseObserver())
        then:
        true
    }

    def getConnectivityConfigurationRequest(String airlineCode){

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        return ConnectivityConfigurationRequest.newBuilder()
                .setRequestInfo(requestInfo)
                .setSupplier(airlineCode)
                .setSupplierType(SupplierType.AIR)
                .setSeatAction(SeatAction.SEAT_VIEW)
                .build();
    }

    def getResponseObserver() {
        return new StreamObserver<ConnectivityConfigurationResponse>() {

            @Override
            void onNext(ConnectivityConfigurationResponse connectivityConfigurationResponse) {
                System.out.println("ConnectivityConfigurationResponse response " + ConnectivityConfigurationResponse.toString())
            }

            @Override
            void onError(Throwable throwable) {
            }

            @Override
            void onCompleted() {
            }
        }
    }
}
