package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.controller


import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.OptionalServiceHealthStatus
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServiceHealthStatus
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServiceStatus
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore
import spock.lang.Specification

class HealthCheckControllerTest extends Specification {

    def serviceHealthCheckStore= Mock(ServiceHealthCheckStore.class)
    def classUnderTest = new HealthCheckController()

    def setup() {
        classUnderTest.serviceHealthCheckStore=serviceHealthCheckStore
    }

    def "get overall health status"() {
        when:
        classUnderTest.getOverallHealthstatus()
        then:
        1 * serviceHealthCheckStore.getOverallHealthStatus() >> ServiceStatus.UP.getStatus()
    }

    def "get health status for all services"() {
        given:
        ServiceHealthStatus serviceHealthStatus = new ServiceHealthStatus()
        serviceHealthStatus.setStatus(ServiceStatus.UP)
        when:
        classUnderTest.getHealthStatusForAllServices()
        then:
        2 * serviceHealthCheckStore.getHealthStatusForAllServices() >> serviceHealthStatus
    }

    def "get health status for all services if getHealthStatusForAllServices return null"() {
        given:
        ServiceHealthStatus serviceHealthStatus = new ServiceHealthStatus()
        serviceHealthStatus.setStatus(ServiceStatus.UP)
        when:
        classUnderTest.getHealthStatusForAllServices()
        then:
        1 * serviceHealthCheckStore.getHealthStatusForAllServices() >> null
    }

    def "get health status for optional services"() {
        given:
        OptionalServiceHealthStatus optionalServiceHealthStatus = new OptionalServiceHealthStatus()
        optionalServiceHealthStatus.setStatus(ServiceStatus.UP)
        when:
        classUnderTest.getHealthStatusForOptionalServices()
        then:
        2 * serviceHealthCheckStore.getHealthStatusForOptionalServices() >> optionalServiceHealthStatus
    }

    def "get health status for all services if getHealthStatusForOptionalServices return null"() {
        given:
        OptionalServiceHealthStatus optionalServiceHealthStatus = new OptionalServiceHealthStatus()
        optionalServiceHealthStatus.setStatus(ServiceStatus.UP)
        when:
        classUnderTest.getHealthStatusForOptionalServices()
        then:
        1 * serviceHealthCheckStore.getHealthStatusForOptionalServices() >> null
    }
}
