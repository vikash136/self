package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.scheduler.HealthCheckScheduler
import spock.lang.Specification

class SmokeTestControllerTest extends Specification{

    def healthCheckScheduler = Mock(HealthCheckScheduler.class)
    def smokeTestController = Spy(new SmokeTestController(healthCheckScheduler))

    def "test"(){
        when:
        def response=smokeTestController.smokeTest()
        then:
        1 * healthCheckScheduler.checkAllServicesHealth()
        response.getStatusCode().value()==200
        response.body.toString()=="OK"

    }

    def "test exception"(){
        when:
        def response=smokeTestController.smokeTest()
        then:
        1 * healthCheckScheduler.checkAllServicesHealth() >> {throw  new Exception("test")}
        response.getStatusCode().value()==500
    }
}
