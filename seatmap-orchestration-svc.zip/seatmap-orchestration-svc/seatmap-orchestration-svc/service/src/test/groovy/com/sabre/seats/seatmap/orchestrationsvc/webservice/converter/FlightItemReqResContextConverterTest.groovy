package com.sabre.seats.seatmap.orchestrationsvc.webservice.converter

import com.sabre.seats.common.protobuf.PaxSegmentInfo
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.common.protobuf.FlightInfo
import com.sabre.seats.common.protobuf.RequestInfo
import com.sabre.seats.common.protobuf.ResponseInfo
import com.sabre.seats.common.protobuf.ResponseStatus
import com.sabre.seats.common.protobuf.SeatmapRequest
import com.sabre.seats.common.protobuf.SeatmapViewType
import com.sabre.seats.common.protobuf.SegmentInfo
import com.sabre.seats.common.protobuf.SupplierType
import com.sabre.seats.transformation.protobuf.InputRequest
import com.sabre.seats.transformation.protobuf.SeatMapOutputReqResponse
import com.sabre.seats.transformation.protobuf.TransformReqResponse
import spock.lang.Specification

import java.time.Instant

class FlightItemReqResContextConverterTest extends Specification{

    def flightItemReqResContextConverter = Spy(FlightItemReqResContextConverter.class)

    def "test"(){
        given:
        WebServiceRequestResponseContext requestResponseContext=new WebServiceRequestResponseContext()

        when:
        flightItemReqResContextConverter.createFlightItemContextMap(requestResponseContext,getTransformerResponse())

        then:
        requestResponseContext.getFlightItemReqResContextMap().size()==1
    }

    def getTransformerResponse(){

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode("I0")
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        PaxSegmentInfo paxSegmentInfo= PaxSegmentInfo.newBuilder().setSegmentInfo(segmentInfo).build()

        SeatmapRequest seatMapRequest= SeatmapRequest.newBuilder()
                .setRequestInfo(requestInfo)
                .addPaxSegmentInfo(paxSegmentInfo)
                .build()

        ResponseInfo responseInfo=ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.SUCCESS)
                .build()

        InputRequest inputRequest= InputRequest.newBuilder()
                .setSeatMapRequest(seatMapRequest)
                .build()

        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(responseInfo)
                .setOutputResponse(inputRequest)
                .build()

        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build()
    }
}
