package com.sabre.seats.seatmap.orchestrationsvc.webservice.utility


import spock.lang.Specification

class ChannelIdUtilTest extends Specification {

    def "test"() {

        given:
        ChannelIdUtil channelIdUtil = new ChannelIdUtil()
        List<String> channelIdList = new ArrayList<>();
        channelIdList.add("1S")
        when:
        channelIdUtil.setRequesterIds(channelIdList)
        then:
        channelIdUtil.getRequesterIds().size() != 0
    }
}
