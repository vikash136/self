package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.scheduler


import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.client.ServiceClient
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServerResponse
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.service.ESSMService
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.utility.OptionalHealthCheckUtil
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.utility.StaticHealthCheckUtil
import spock.lang.Specification

class HealthCheckschedulerTest extends Specification {

    def staticHealthCheckMap = Mock(StaticHealthCheckUtil.class)
    def optionalHealthCheckMap = Mock(OptionalHealthCheckUtil.class)
    def serviceHealthCheckStore = Mock(ServiceHealthCheckStore.class)
    def serviceClient = Mock(ServiceClient.class)
    def essmService = Mock(ESSMService.class)

    def classUnderTest = new HealthCheckScheduler(connectionTimeout: 10, poolSize: 5)

    def setup() {
        classUnderTest.staticHealthCheckMap=staticHealthCheckMap
        classUnderTest.optionalHealthCheckMap=optionalHealthCheckMap
        classUnderTest.serviceHealthCheckStore=serviceHealthCheckStore
        classUnderTest.serviceClient=serviceClient
        classUnderTest.essmService=essmService
    }

    def "Test health check scheduler"() {
        given:
        Map<String,String> staticHealthMap = getStaticHealthCheckMap()
        Map<String, String> dynamicHealthMap = getDynamicHealthCheckMap()
        Map<String, String> optionalHealthMap = getOptionalHealthCheckMap()

        when:
        classUnderTest.checkAllServicesHealth()
        then:
        1 * staticHealthCheckMap.getStaticHealthCheckMap() >> staticHealthMap
        1 * optionalHealthCheckMap.getOptionalHealthCheckMap() >> optionalHealthMap
        4 * serviceClient.getServiceStatus(_,_) >> ServerResponse.SERVING.name()
        1 * serviceHealthCheckStore.getDynamicHealthCheckMap() >> dynamicHealthMap
        1 * essmService.getEssmStatus(_) >> ServerResponse.SERVING.name()
        1 * serviceHealthCheckStore.updateStaticServiceHealthStatus(_)
        1 * serviceHealthCheckStore.updateDynamicServiceHealthStatus(_)
        1 * serviceHealthCheckStore.updateOptionalServiceHealthStatus(_)

    }

    def "Test health check scheduler if dynamic Health Check map is empty"() {
        given:
        Map<String,String> staticHealthMap = getStaticHealthCheckMap()
        Map<String, String> optionalHealthMap = getOptionalHealthCheckMap()
        when:
        classUnderTest.checkAllServicesHealth()
        then:
        1 * staticHealthCheckMap.getStaticHealthCheckMap() >> staticHealthMap
        1 * optionalHealthCheckMap.getOptionalHealthCheckMap() >> optionalHealthMap
        4 * serviceClient.getServiceStatus(_,_) >> ServerResponse.SERVING.name()
        1 * serviceHealthCheckStore.getDynamicHealthCheckMap() >> new HashMap<>()
        0 * essmService.getEssmStatus(_) >> ServerResponse.SERVING.name()
        1 * serviceHealthCheckStore.updateStaticServiceHealthStatus(_)
        1 * serviceHealthCheckStore.updateDynamicServiceHealthStatus(_)
        1 * serviceHealthCheckStore.updateOptionalServiceHealthStatus(_)
    }

    def "Test health check scheduler Exception"() {
        given:
        Map<String,String> staticHealthMap = getStaticHealthCheckMap()
        Map<String, String> optionalHealthMap = getOptionalHealthCheckMap()
        when:
        classUnderTest.checkAllServicesHealth()
        then:
        1 * staticHealthCheckMap.getStaticHealthCheckMap() >> staticHealthMap
        1 * optionalHealthCheckMap.getOptionalHealthCheckMap() >> optionalHealthMap
        4 * serviceClient.getServiceStatus(_,_) >> ServerResponse.SERVING.name()
        1 * serviceHealthCheckStore.getDynamicHealthCheckMap() >> Exception
        0 * essmService.getEssmStatus(_) >> ServerResponse.SERVING.name()
        0 * serviceHealthCheckStore.updateStaticServiceHealthStatus(_)
        0 * serviceHealthCheckStore.updateDynamicServiceHealthStatus(_)
        0 * serviceHealthCheckStore.updateOptionalServiceHealthStatus(_)
    }

    def getStaticHealthCheckMap() {
        Map<String,String> staticHealthMap = new HashMap<>()
        staticHealthMap.put("transformerService", "transformerServiceUrl")
        staticHealthMap.put("authorizationService", "authorizationServiceUrl")
        staticHealthMap.put("connectivityService", "connectivityServiceUrl")
        return staticHealthMap;
    }

    def getDynamicHealthCheckMap() {
        Map<String,String> dynamicHealthMap = new HashMap<>()
        dynamicHealthMap.put("essmService", "essmServiceUrl")
        return dynamicHealthMap;
    }

    def getOptionalHealthCheckMap() {
        Map<String,String> optionalHealthMap = new HashMap<>()
        optionalHealthMap.put("viewService", "viewServiceUrl")
        return optionalHealthMap;
    }

}
