package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers


import com.sabre.seats.common.protobuf.FlightInfo
import com.sabre.seats.common.protobuf.MessageFormat
import com.sabre.seats.common.protobuf.RequestInfo
import com.sabre.seats.common.protobuf.ResponseInfo
import com.sabre.seats.common.protobuf.SeatmapResponse
import com.sabre.seats.common.protobuf.SeatmapViewType
import com.sabre.seats.common.protobuf.SegmentInfo
import com.sabre.seats.common.protobuf.SegmentResponse
import com.sabre.seats.common.protobuf.SupplierType
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.error.protobuf.MessageCode
import com.sabre.seats.error.protobuf.WarningMessage
import com.sabre.seats.transformation.protobuf.*
import com.sabre.seats.error.protobuf.Description;
import io.grpc.stub.StreamObserver
import spock.lang.Specification



class MockTransformationServiceTest extends Specification {

    def classUnderTest = Spy(MockTransformationService.class)

    def seatmapRequestString = "{\"version\": \"1\",\"transactionId\": \"9876543210\",\"correlationId\": \"1987654321\",\"requestDateTime\": \"2021-03-26T12:52:00.237Z\",\"flightInfo\": [{\"airlineCode\": \"I0\",\"flightNumber\": \"105\",\"scheduledDepartureDate\": \"2021-04-15\",\"reservationBookingDesignator\": \"Y\",\"departureAirportCode\": \"KWI\",\"arrivalAirportCode\": \"AUH\"}],\"seatMapViewType\": \"RESERVATION\"}"

    def seatmapResponseFromSupplier = "{\"version\":\"1\",\"transactionId\":\"9876543210\",\"correlationId\":\"1987654321\",\"requestDateTime\":\"2021-04-29T16:49:59.328496100Z\",\"responseDateTime\":\"2021-04-29T16:50:13.491004Z\",\"status\":\"SUCCESS\",\"warningMessages\":[],\"flightInfo\":{\"airlineCode\":\"I0\",\"flightNumber\":\"105\",\"reservationBookingDesignator\":\"Y\",\"scheduleDepartureDate\":\"2021-04-15\",\"departureAirportCode\":\"KWI\",\"arrivalAirportCode\":\"AUH\"},\"seatmaps\":[{\"departureAirportCode\":\"KWI\",\"arrivalAirportCode\":\"AUH\",\"iataConfigurationCode\":\"105\",\"physicalAircraftName\":\"TEST\",\"physicalAircraftDescription\":\"TESTED\",\"cabinJumpSeatCount\":\"5\",\"cockpitJumpSeatCount\":\"2\",\"isAnimalAllowed\":true,\"isSmoking\":false,\"scheduleDepartureDateTime\":\"2021-04-15\",\"scheduleArrivalDateTime\":\"<ARRIVAL_DATE>\",\"cabins\":[{\"seatRows\":[{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"}],\"rowNumber\":\"8\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"9\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"10\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"11\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"12\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"13\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"14\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"W\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window-BulkHead  \",\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"LS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"K\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisel-BulkHead\",\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"K\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisel-BulkHead\",\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"RS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"W\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window-BulkHead  \",\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"15\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"16\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"17\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"18\",\"rowCharacteristics\":[]}],\"cabinLayout\":{\"cabinCode\":\"Y\",\"cabinNumber\":\"2\",\"facilities\":[],\"firstRow\":\"8\",\"cabinCodeDescription\":\"ECONOMY\",\"lastRow\":\"18\",\"seatCount\":61,\"missingRowNumbers\":[],\"seatAlphabetList\":[{\"columnCode\":\"A\",\"position\":\"W\"},{\"columnCode\":\"B\",\"position\":\"9\"},{\"columnCode\":\"C\",\"position\":\"A\"},{\"columnCode\":\"D\",\"position\":\"A\"},{\"columnCode\":\"E\",\"position\":\"9\"},{\"columnCode\":\"F\",\"position\":\"W\"}],\"missingSeatList\":[]}}]}]} "

    def seatmapResponseFromSupplierForTpf = "{\"version\":\"1\",\"transactionId\":\"9876543210\",\"correlationId\":\"1987654321\",\"requestDateTime\":\"2021-04-29T16:49:59.328496100Z\",\"responseDateTime\":\"2021-04-29T16:50:13.491004Z\",\"status\":\"SUCCESS\",\"warningMessages\":[],\"flightInfo\":{\"airlineCode\":\"MN\",\"flightNumber\":\"105\",\"reservationBookingDesignator\":\"Y\",\"scheduleDepartureDate\":\"2021-04-15\",\"departureAirportCode\":\"KWI\",\"arrivalAirportCode\":\"AUH\"},\"seatmaps\":[{\"departureAirportCode\":\"KWI\",\"arrivalAirportCode\":\"AUH\",\"iataConfigurationCode\":\"105\",\"physicalAircraftName\":\"TEST\",\"physicalAircraftDescription\":\"TESTED\",\"cabinJumpSeatCount\":\"5\",\"cockpitJumpSeatCount\":\"2\",\"isAnimalAllowed\":true,\"isSmoking\":false,\"scheduleDepartureDateTime\":\"2021-04-15\",\"scheduleArrivalDateTime\":\"<ARRIVAL_DATE>\",\"cabins\":[{\"seatRows\":[{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"}],\"rowNumber\":\"8\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"9\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"10\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"11\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"12\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"13\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"14\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"W\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window-BulkHead  \",\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"LS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"K\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisel-BulkHead\",\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"K\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisel-BulkHead\",\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"RS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"K\",\"W\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window-BulkHead  \",\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"15\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\",\"V\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\",\"V\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"16\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"17\",\"rowCharacteristics\":[]},{\"oxygenMasks\":[{\"additionalMaskCount\":0,\"section\":\"L\"},{\"additionalMaskCount\":0,\"section\":\"R\"}],\"seats\":[{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"A\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"LS\",\"14\",\"9\"]}],\"columnCode\":\"B\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"LS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"C\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"A\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Aisle seat\",\"RKENG\",\"VUEBN\",\"NYIFW\",\"PRCAD\",\"SGQDO\",\"VDGGL\",\"ODOMG\"]}],\"columnCode\":\"D\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"RS\",\"14\",\"9\"]}],\"columnCode\":\"E\",\"seatStatus\":\"F\"},{\"characteristics\":[{\"codeContext\":\"SEATS_PADIS\",\"codes\":[\"W\",\"RS\",\"14\"]},{\"codeContext\":\"SEATS_PADIS_GROUPING\",\"codes\":[\"Window\"]}],\"columnCode\":\"F\",\"seatStatus\":\"F\"}],\"rowNumber\":\"18\",\"rowCharacteristics\":[]}],\"cabinLayout\":{\"cabinCode\":\"Y\",\"cabinNumber\":\"2\",\"facilities\":[],\"firstRow\":\"8\",\"cabinCodeDescription\":\"ECONOMY\",\"lastRow\":\"18\",\"seatCount\":61,\"missingRowNumbers\":[],\"seatAlphabetList\":[{\"columnCode\":\"A\",\"position\":\"W\"},{\"columnCode\":\"B\",\"position\":\"9\"},{\"columnCode\":\"C\",\"position\":\"A\"},{\"columnCode\":\"D\",\"position\":\"A\"},{\"columnCode\":\"E\",\"position\":\"9\"},{\"columnCode\":\"F\",\"position\":\"W\"}],\"missingSeatList\":[]}}]}]} "

    def seatmapResponseFromSupplierFailure = "AIR"

    TransformReqResponse transformResponse = TransformReqResponse.newBuilder().build()

    SegmentResponse segmentResponse =SegmentResponse.newBuilder().build()

    def 'test getSeatmapRequest'() {

        when:
        classUnderTest.transform(getSeatmapRequest(), getResponseObserver())

        then:
        true
    }


    def 'test getTransformerConnectivityToSupplier'() {

        when:
        classUnderTest.transform(getTransformerConnectivityToSupplier(), getResponseObserver())

        then:
        true
    }


    def 'test getTransformSupplierToviewSource'(){
        when:
        classUnderTest.transform(getTransformSupplierToViewSource(), getResponseObserver())

        then:
        true
    }

    def 'test getTransformSupplierToviewSource1'(){
        when:
        classUnderTest.transform(getTransformSupplierToViewSource1(), getResponseObserver())

        then:
        true
    }

    def 'test getTransResponsetoPOS'(){
        when:

        classUnderTest.transform(getTransformSupplierToViewSource(), getResponseObserver())
        classUnderTest.transform(getTransResponsetoPOS(segmentResponse), getResponseObserver())

        then:
        true
    }

    def getResponseObserver() {
        return new StreamObserver<TransformReqResponse>() {

            @Override
            void onNext(TransformReqResponse transformReqResponse) {
                transformResponse = transformReqResponse
                segmentResponse = transformReqResponse.getSeatMapOutputReqResponse().getOutputResponse().getSegmentResponse()
            }

            @Override
            void onError(Throwable throwable) {
            }

            @Override
            void onCompleted() {

            }
        }
    }


    def getSeatmapRequest() {
        MessageInfo inputMessageInfo = getMessageInfo(MessageType.SEAT_MAP_REQUEST,MessageFormat.JSON)
        MessageInfo desiredMessageInfo = getMessageInfo(MessageType.SEAT_MAP_REQUEST,MessageFormat.PROTOBUF)


        Input input = Input.newBuilder()
                .setRequest(seatmapRequestString)
                .build()

        Request request = Request.newBuilder()
                .setRequestInfo(getRequestInfo())
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .build()
        return TransformRequest.newBuilder()
                .setRequest(request)
                .build()
    }


    def getTransformerConnectivityToSupplier() {

        MessageInfo inputMessageInfo = getMessageInfo(MessageType.SEGMENT_INFO,MessageFormat.PROTOBUF)
        MessageInfo desiredMessageInfo = getMessageInfo(MessageType.SEAT_MAP_CORE_REQUEST,MessageFormat.JSON)

        FlightInfo flightInfo = FlightInfo.newBuilder()
                .setAirlineCode("I0")
                .setFlightNumber("105")
                .setScheduledDepartureDate("2021-04-15")
                .setArrivalAirportCode("KWI")
                .setDepartureAirportCode("AUH")
                .build()

        SegmentInfo segmentInfo = SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        InputRequest inputRequest = InputRequest.newBuilder()
                .setSegmentInfo(segmentInfo)
                .build()

        Input input = Input.newBuilder()
                .setInputRequest(inputRequest)
                .build()

        Request request = Request.newBuilder()
                .setRequestInfo(getRequestInfo())
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .build()
        return TransformRequest.newBuilder()
                .setRequest(request)
                .build()

    }


    def getTransformSupplierToViewSource(){

        MessageInfo inputMessageInfo = getMessageInfo(MessageType.SEAT_MAP_CORE_RESPONSE,MessageFormat.JSON)
        MessageInfo desiredMessageInfo = getMessageInfo(MessageType.SEGMENT_RESPONSE,MessageFormat.PROTOBUF)

        Input input = Input.newBuilder()
                .setRequest(seatmapResponseFromSupplier)
                .build()

        Request request = Request.newBuilder()
                .setRequestInfo(getRequestInfo())
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .build()
        return  TransformRequest.newBuilder()
                .setRequest(request)
                .build()
    }

    def getTransformSupplierToViewSource1(){

        MessageInfo inputMessageInfo = getMessageInfo(MessageType.SEAT_MAP_CORE_RESPONSE,MessageFormat.JSON)
        MessageInfo desiredMessageInfo = getMessageInfo(MessageType.SEGMENT_RESPONSE,MessageFormat.PROTOBUF)

        Input input = Input.newBuilder()
                .setRequest(seatmapResponseFromSupplierFailure)
                .build()

        Request request = Request.newBuilder()
                .setRequestInfo(getRequestInfo())
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .build()
        return  TransformRequest.newBuilder()
                .setRequest(request)
                .build()
    }

    def getTransResponsetoPOS(segmentResponse){

        MessageInfo inputMessageInfo = getMessageInfo(MessageType.SEAT_MAP_RESPONSE,MessageFormat.PROTOBUF)
        MessageInfo desiredMessageInfo = getMessageInfo(MessageType.SEAT_MAP_RESPONSE,MessageFormat.JSON)
        RequestInfo requestInfo = getRequestInfo()

        List<WarningMessage> warningMessageList = new ArrayList<>()
        List<MessageCode> warnMessageCodeList = new ArrayList<>();
        MessageCode warnMessageCode =  MessageCode.newBuilder()
                .setCode("CORE-3001")
                .setCodeContext("IATAErrorCode").build();
        warnMessageCodeList.add(warnMessageCode);

        WarningMessage warningMessage = WarningMessage.newBuilder()
                .setCategory("INTERNAL_SERVER_ERROR")
                .setType("BUSINESS")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("ViewServiceTimeout")
                        .build())
                .addAllWarningCode(warnMessageCodeList)
                .build();
        warningMessageList.add(warningMessage)


        List<ErrorMessage> errorMessageList = new ArrayList<>()
        List<MessageCode> messageCodeList = new ArrayList<>();
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("CORE-3001")
                .setCodeContext("IATAErrorCode").build();
        messageCodeList.add(messageCode);

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setCategory("INTERNAL_SERVER_ERROR")
                .setType("BUSINESS")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("ViewServiceTimeout")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build();
        errorMessageList.add(errorMessage)

        ResponseInfo responseInfo = ResponseInfo.newBuilder()
                .setResponseStatus(transformResponse.getSeatMapOutputReqResponse().getResponseInfo().responseStatus)
                .addAllWarningMessages(warningMessageList)
                .addErrorMessages(errorMessageList)
                .build()

        List<SegmentResponse> finalSegmentResponseList =  new ArrayList<>()


        for(SegmentResponse segmentResponse1: Arrays.asList(segmentResponse)){
            SegmentResponse segmentResponse2 = SegmentResponse.newBuilder()
            .setResponseInfo(responseInfo)
            .setSegmentInfo(segmentResponse.getSegmentInfo())
            .setFlightSeatmap(segmentResponse.getFlightSeatmap())
            .build()

            finalSegmentResponseList.add(segmentResponse2)
        }

        ResponseInfo seatmapResponseInfo = ResponseInfo.newBuilder()
            .setResponseStatus(transformResponse.getSeatMapOutputReqResponse().getResponseInfo().responseStatus)
            .build()

        SeatmapResponse seatmapResponse = SeatmapResponse.newBuilder()
                .setRequestInfo(requestInfo)
                .setResponseInfo(seatmapResponseInfo)
                .addAllSegmentResponse(finalSegmentResponseList)
                .build()

        InputRequest inputRequest = InputRequest.newBuilder()
                .setSeatMapResponse(seatmapResponse)
                .build()

        Input input = Input.newBuilder()
                .setInputRequest(inputRequest)
                .build()

        Request request = Request.newBuilder()
                .setRequestInfo(getRequestInfo())
                .setInputMessageInfo(inputMessageInfo)
                .setDesiredMessageInfo(desiredMessageInfo)
                .setInputRequest(input)
                .build()
        return TransformRequest.newBuilder()
                .setRequest(request)
                .build()
    }


    static def getMessageInfo(MessageType messaageType, MessageFormat messageFormat){
        MessageInfo messageInfo = MessageInfo.newBuilder()
                .setMsgType(messaageType )
                .setFormat(messageFormat)
                .setVersion("1")
                .build()
        return messageInfo

    }

    static def getRequestInfo(){
        RequestInfo requestInfo = RequestInfo.newBuilder()
                .setCorrelationId("1987654321")
                .setTransactionId("9876543210")
                .setTimestamp("2021-04-29T15:45:10.539809100Z")
                .setVersion("1")
                .build()
        return requestInfo
    }

}

