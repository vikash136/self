package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore
import spock.lang.Specification

class HealthCheckServiceTest extends Specification {

    def classUnderTest = new HealthCheckService()
    ServiceHealthCheckStore serviceHealthCheckStore = Mock()

    def setup() {
        classUnderTest.serviceHealthCheckStore = serviceHealthCheckStore
    }

    def "test isHealthStable"() {

        when:
        classUnderTest.isHealthStable()

        then:
        1 * serviceHealthCheckStore.getOverallHealthStatus() >> true
    }

    def "test isHealthStable for not stable"() {

        when:
        def status = classUnderTest.isHealthStable()

        then:
        1 * serviceHealthCheckStore.getOverallHealthStatus() >> null
        status == false
    }
}
