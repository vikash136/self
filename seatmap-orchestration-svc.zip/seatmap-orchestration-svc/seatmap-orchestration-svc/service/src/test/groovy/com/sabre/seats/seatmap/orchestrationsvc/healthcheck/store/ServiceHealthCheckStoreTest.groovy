package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store


import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServerResponse
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model.ServiceStatus
import spock.lang.Specification

class ServiceHealthCheckStoreTest extends Specification {

    def classUnderTest = new ServiceHealthCheckStore()

    def "update static service health check status as up if all service status up"() {
        given:
        Map<String,String> staticHealthMap = getStaticHealthCheckMap()
        when:
        classUnderTest.updateStaticServiceHealthStatus(staticHealthMap)
        then:
        true
    }

    def "update static service health check status as down if any service status is down"() {
        given:
        Map<String,String> staticHealthMap = getStaticHealthCheckMap()
        staticHealthMap.put("transformerService", ServerResponse.NOT_SERVING.name())
        when:
        classUnderTest.updateStaticServiceHealthStatus(staticHealthMap)
        then:
        true
    }

    def "update optional service health check status as up if all service status up"() {
        given:
        Map<String,String> optionalHealthMap = getOptionalHealthCheckMap()
        when:
        classUnderTest.updateOptionalServiceHealthStatus(optionalHealthMap)
        then:
        true
    }

    def "update optional service health check status as down if any service status is down"() {
        given:
        Map<String,String> optionalHealthMap = getOptionalHealthCheckMap()
        optionalHealthMap.put("viewService", ServerResponse.NOT_SERVING.name())
        when:
        classUnderTest.updateOptionalServiceHealthStatus(optionalHealthMap)
        then:
        true
    }

    def "update dynamic service health check status as up if all service status up"() {
        given:
        Map<String, String> dynamicHealthMap = getDynamicHealthCheckMap()
        when:
        classUnderTest.updateDynamicServiceHealthStatus(dynamicHealthMap)
        then:
        true
    }

    def "update dynamic service health check status as down if any service status is down"() {
        given:
        Map<String, String> dynamicHealthMap = getDynamicHealthCheckMap()
        dynamicHealthMap.put("essmService", ServerResponse.NOT_SERVING.name())
        when:
        classUnderTest.updateDynamicServiceHealthStatus(dynamicHealthMap)
        then:
        true
    }

    def "set service component down"() {
        when:
        classUnderTest.setServiceComponentDown("test", ServiceStatus.UP.getStatus())
        then:
        true
    }

    def "get Dynamic Health Check Map"() {
        when:
        classUnderTest.getDynamicHealthCheckMap()
        then:
        true
    }

    def "get Optional Health Check Map"() {
        when:
        classUnderTest.getOptionalHealthCheckMap()
        then:
        true
    }

    def "get overall health status"() {
        when:
        classUnderTest.getOverallHealthStatus()
        then:
        true
    }

    def "get health status for all services"() {
        when:
        classUnderTest.getHealthStatusForAllServices()
        then:
        true
    }

    def "get health status for optional services"() {
        when:
        classUnderTest.getHealthStatusForOptionalServices()
        then:
        true
    }

    def "get retryCount by service"() {
        when:
        classUnderTest.getRetryCount("test")
        then:
        true
    }

    def getStaticHealthCheckMap() {
        Map<String,String> staticHealthMap = new HashMap<>()
        staticHealthMap.put("transformerService", ServerResponse.SERVING.name())
        staticHealthMap.put("authorizationService", ServerResponse.SERVING.name())
        staticHealthMap.put("connectivityService", ServerResponse.SERVING.name())
        return staticHealthMap
    }

    def getDynamicHealthCheckMap() {
        Map<String,String> dynamicHealthMap = new HashMap<>()
        dynamicHealthMap.put("essmService", ServerResponse.SERVING.name())
        return dynamicHealthMap;
    }

    def getOptionalHealthCheckMap() {
        Map<String,String> optionalHealthMap = new HashMap<>()
        optionalHealthMap.put("viewService", ServerResponse.SERVING.name())
        return optionalHealthMap;
    }
}
