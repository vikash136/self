package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers


import spock.lang.Specification

class MockSeatmapSupplierServiceTest extends Specification{

    def mockSeatmapCoreService = Spy(MockSeatmapSupplierService.class)
    def successRequest ="{\"correlationId\": \"323232323\",\"flightInfo\": {\"airlineCode\": \"I0\",\"arrivalAirportCode\": \"AUH\",\"departureAirportCode\": \"LHR\",\"scheduleDepartureDate\": \"2021-02-28\",\"flightNumber\": \"12\"},\"requestDateTime\": \"2021-02-15T11:52:00.237Z\",\"reservationBookingDesignator\": \"Y\",\"responseOptions\": [\"ALL\"],\"transactionId\": \"238328338\",\"version\": \"1.0\"}"
    def successRequestFlightCountTwo ="{\"correlationId\": \"323232323\",\"flightInfo\": {\"airlineCode\": \"I0\",\"arrivalAirportCode\": \"AUH\",\"departureAirportCode\": \"LHR\",\"scheduleDepartureDate\": \"2021-02-28\",\"flightNumber\": \"1212\"},\"requestDateTime\": \"2021-02-15T11:52:00.237Z\",\"reservationBookingDesignator\": \"Y\",\"responseOptions\": [\"ALL\"],\"transactionId\": \"238328338\",\"version\": \"1.0\"}"
    def successRequestFlightCountThree ="{\"correlationId\": \"323232323\",\"flightInfo\": {\"airlineCode\": \"I0\",\"arrivalAirportCode\": \"AUH\",\"departureAirportCode\": \"LHR\",\"scheduleDepartureDate\": \"2021-02-28\",\"flightNumber\": \"1213\"},\"requestDateTime\": \"2021-02-15T11:52:00.237Z\",\"reservationBookingDesignator\": \"Y\",\"responseOptions\": [\"ALL\"],\"transactionId\": \"238328338\",\"version\": \"1.0\"}"
    def successRequestFlightCountFour ="{\"correlationId\": \"323232323\",\"flightInfo\": {\"airlineCode\": \"I0\",\"arrivalAirportCode\": \"AUH\",\"departureAirportCode\": \"LHR\",\"scheduleDepartureDate\": \"2021-02-28\",\"flightNumber\": \"1214\"},\"requestDateTime\": \"2021-02-15T11:52:00.237Z\",\"reservationBookingDesignator\": \"Y\",\"responseOptions\": [\"ALL\"],\"transactionId\": \"238328338\",\"version\": \"1.0\"}"
    def failureRequest ="{\"correlationId\": \"323232323\",\"flightInfo\": {\"airlineCode\": \"AA\",\"arrivalAirportCode\": \"AUH\",\"departureAirportCode\": \"LHR\",\"scheduleDepartureDate\": \"2021-02-28\",\"flightNumber\": \"12\"},\"requestDateTime\": \"2021-02-15T11:52:00.237Z\",\"reservationBookingDesignator\": \"Y\",\"responseOptions\": [\"ALL\"],\"transactionId\": \"238328338\",\"version\": \"1.0\"}"
    def token="eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxMDAyLWNraS1zYWJyZSIsInNjcCI6W10sInN1YmplY3RfdG9rZW5fdHlwZSI6IkFUSyIsImtleXdvcmRzIjpbXSwiaG9tZV9wcmltZV9ob3N0IjoiKioiLCJzdWJqZWN0X3Rva2VuX2NyZWF0aW9uIjoiMTYxNDIzMTg5NSIsInN1YmplY3RfdG9rZW5fZXhwaXJhdGlvbiI6IjE2MTQ4MzY2OTUiLCJpc3MiOiJodHRwczovL2Vzc213cy5pbnQuc2FicmUuY29tLyIsImR1dHlfY29kZXMiOltdLCJsYXN0X25hbWUiOiJXZWIgQXBwIiwiY3VycmVudF9wcmltZV9ob3N0IjoiKioiLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDIiwiYXVkIjoiaW50LWF1ZCIsInVpZCI6IjEwMDIiLCJuYmYiOjE2MTQyMzE4OTUsImRvbWFpbiI6InNhYnJlIiwiZXhwIjoxNjE0MjMyMTk1LCJpYXQiOjE2MTQyMzE4OTUsInN1YmplY3RfdG9rZW4iOiJUMVJMQVFKTk5qeVZDbzRRMkI1ZmZvRzA3bDRnK1gwQ2p4RDVCT0tVOXE1dDN6UC9IOE5ETzM5REFBRFFEQWRnQjJMVmtqNzdSWVMybE5vRVpONVdqdFR2OFBiWkVJaW5iMk9idkR3MXdiKzlLMDlsU0w1ak51Umx4Qml3QkxuQmt4Tk5sZnMrUWpERWRPQzIvZitEMXhnWjVMcU4zcW5QbHBmKzFBVlgvWE9lcW9OTjJtMEUvUElVRzZhMmZTTFA1YnpMeXk2dGdkVVM2c0c4SUtmRG44RkVPRWlHbjBNZzFsNEl3T1lNNlkyTzN1M1NqUkMyanJyQWwreUlobThUaGV2Q2NIUW5HdTVsVzB5dFZMdy9VU0tjTGhMT1QvWFZITWxPZXFNdHg1QVJPczBKV3Q2ZWEwNnA1YkcyamRoaHkxWDdJanhMNXdRcXpMdzd1USoqIiwianRpIjoiMTYxNDIzMTg5NTU1MzAwMDAwMCIsImdyb3VwIjoiY2tpIn0.OeFIZ9QUOPmLu6lUcALwDvD6LJXY6UM388i5OyuatV230sr3sRergsIAO8YCfw6oUyA8kf_hLkYEHUlpVNAIpk7_mojNrSHn7cpsKmFS4EXQgVVq8-r4gSamef9SHsSUf3pQwbjZfJXdJBDDD7U3kJDqK4n5xYspV5UlZcCXBKzpfpaXKxO1YkLjNUfJ1kDnZH6bC911ry3oOd5t-MFwi7bOnAB0WvsMxsvWFhbK2fRvXXdtpkYzE0QHQhieC1-Iir5PCuMLe5gtvH04Mdnm10Y91Vp0alKxHXqiVW49Vrjoah6a19SDsZ9zyUwk5NbPxJKZltJjrIfsp0wZHnJrkg"
    def correlationId = "323232323"
    def transactionId = "22be9a0f832910"
    def tpfPayload = "{\"transactionId\":\"22be9a0f832910\",\"correlationId\":\"323232323\",\"lnIata\":\"\",\"lockId\":\"\",\"requestorInformation\":{\"channelId\":\"1S\",\"iataNumber\":\"99999992\",\"pseudoCityCd\":\"F4X0\",\"agentCityCd\":\"F4X0\",\"countryCode\":\"US\",\"currencyCode\":\"USD\",\"requesterType\":\"GDS\"},\"requesteeInformation\":{\"requesteeChannelId\":\"MN\",\"supplierType\":\"AIR\"},\"mapType\":\"IMAP\",\"sdsInput\":true,\"requestDataLst\":[{\"payloadType\":\"ATB\",\"payloadLength\":240,\"payload\":\"SMPREQ:AIRAALSMPREQ0001...TVL000.D...01Y5.290521...0086.MCT...0086.BAH...008O.MN...008U.12...008V.Y...SRP001.D...005A.N\"}]}"

    def "test getSeatMapFromCore Success"(){
        when:
        def resp=mockSeatmapCoreService.getSeatMapFromCore(successRequest,token,correlationId,transactionId)
        then:
        resp.statusCodeValue==200
        resp.body.toString().contains("200")
    }

    def "test getSeatMapFromCoretwoSeatmap Success"(){
        when:
        def resp=mockSeatmapCoreService.getSeatMapFromCore(successRequestFlightCountTwo,token,correlationId,transactionId)
        then:
        resp.statusCodeValue==200
        resp.body.toString().contains("200")
    }
    def "test getSeatMapFromCoreThreeSeatmap Success"(){
        when:
        def resp=mockSeatmapCoreService.getSeatMapFromCore(successRequestFlightCountThree,token,correlationId,transactionId)
        then:
        resp.statusCodeValue==200
        resp.body.toString().contains("200")
    }
    def "test getSeatMapFromCoreSeatmap Success"(){
        when:
        def resp=mockSeatmapCoreService.getSeatMapFromCore(successRequestFlightCountFour,token,correlationId,transactionId)
        then:
        resp.statusCodeValue==200
        resp.body.toString().contains("200")
    }

    def "test getSeatMapFromCore Failed"(){
        when:
        def resp=mockSeatmapCoreService.getSeatMapFromCore(failureRequest,token,correlationId,transactionId)
        then:
        resp.statusCodeValue==200
        resp.body.toString().contains("500")
    }

    def "test getMockTpf Success"(){
        when:
        def resp=mockSeatmapCoreService.mockTpf(tpfPayload)
        then:
        resp.statusCodeValue==200
        resp.body.toString().contains("200")
    }

}
