package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller

import spock.lang.Specification

class GenericRootControllerTest extends Specification{

    def genericRootController = new GenericRootController("APP")

    def "test"(){
        when:
        def response = genericRootController.root()

        then:
        response.getStatusCode().value()==200
        response.body.toString()=="This is auto-generated 'APP' application"
    }
}
