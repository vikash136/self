package com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response

import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.JsonSEATMAPRESPONSEV1
import spock.lang.Specification

class AirSeatMapResponseTest extends Specification {
    JsonSEATMAPRESPONSEV1 seatmapresponse
    def "test"() {
        given:
        AirSeatMapResponse responsePayload = new AirSeatMapResponse()

        when:
        responsePayload.setSeatmapResponse(seatmapresponse)

        then:
        responsePayload.toString() != null
        responsePayload.getSeatmapResponse() == seatmapresponse
    }
}
