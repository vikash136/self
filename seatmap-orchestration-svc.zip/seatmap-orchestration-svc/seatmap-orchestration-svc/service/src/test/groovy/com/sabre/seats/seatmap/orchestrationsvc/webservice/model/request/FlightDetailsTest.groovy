package com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request

import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import spock.lang.Specification

import java.time.LocalDate

class FlightDetailsTest extends Specification {

    def "test"() {
        given:
        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()

        when:
        flightDetails.setFlightNumber("567")
        flightDetails.setAirlineCode("AA")
        flightDetails.setArrivalAirportCode("AUH")
        flightDetails.setDepartureAirportCode("DFA")
        flightDetails.setScheduledDepartureDate(LocalDate.now().toString())
        flightDetails.setReservationBookingDesignator("aa")

        then:
        flightDetails.toString()!=null
        flightDetails.getFlightNumber()=="567"
        flightDetails.getAirlineCode()=="AA"
        flightDetails.getArrivalAirportCode()=="AUH"
        flightDetails.getDepartureAirportCode()=="DFA"
        flightDetails.getScheduledDepartureDate()!=null
        flightDetails.getReservationBookingDesignator()=="aa"
    }
}
