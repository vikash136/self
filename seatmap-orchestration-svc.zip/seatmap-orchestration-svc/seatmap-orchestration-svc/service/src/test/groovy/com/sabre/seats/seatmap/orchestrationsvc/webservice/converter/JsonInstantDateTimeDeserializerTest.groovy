package com.sabre.seats.seatmap.orchestrationsvc.webservice.converter

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.databind.DeserializationContext
import spock.lang.Specification

class JsonInstantDateTimeDeserializerTest extends Specification{

    def jsonParser = Mock(JsonParser.class)
    def deserializationContext =Mock(DeserializationContext.class)

    def jsonInstantDateTimeDeserializer = Spy(JsonInstantDateTimeDeserializer.class)

    def "test"(){
        when:
        def time=jsonInstantDateTimeDeserializer.deserialize(jsonParser,deserializationContext)

        then:
        1 * jsonParser.getText() >> "2021-03-26T12:52:00.237Z"
        time != null
    }

}
