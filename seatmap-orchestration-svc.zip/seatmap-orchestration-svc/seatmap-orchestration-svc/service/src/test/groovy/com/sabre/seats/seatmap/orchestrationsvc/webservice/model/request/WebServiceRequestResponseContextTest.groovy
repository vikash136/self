
package com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request

import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.common.protobuf.ClientInfo
import com.sabre.seats.transformation.protobuf.TransformReqResponse
import spock.lang.Specification

class WebServiceRequestResponseContextTest extends Specification{

    def "test"() {
        given:
        WebServiceRequestResponseContext webServiceRequestResponseContext=new WebServiceRequestResponseContext()

        when:
        webServiceRequestResponseContext.setAirSeatMapRQ(new AirSeatMapRequest())
        webServiceRequestResponseContext.setRequestVersion("1")
        webServiceRequestResponseContext.setJwtToken("test")
        webServiceRequestResponseContext.setClientInfo(ClientInfo.newBuilder().build())
        webServiceRequestResponseContext.setTransformReqResponse(TransformReqResponse.newBuilder().build())
        webServiceRequestResponseContext.setFlightItemReqResContextMap(null)
        webServiceRequestResponseContext.setAirSeatMapResponse(new AirSeatMapResponse())
        webServiceRequestResponseContext.setTjrToken("dummy")

        then:
        webServiceRequestResponseContext.getAirSeatMapRQ()!=null
        webServiceRequestResponseContext.getRequestVersion()=="1"
        webServiceRequestResponseContext.getJwtToken()=="test"
        webServiceRequestResponseContext.getClientInfo()!=null
        webServiceRequestResponseContext.getTransformReqResponse()!=null
        webServiceRequestResponseContext.getFlightItemReqResContextMap()!=null
        webServiceRequestResponseContext.getAirSeatMapResponse()!=null
        webServiceRequestResponseContext.getTjrToken()=="dummy"
        webServiceRequestResponseContext.getRequestInfo()!=null
    }
}

