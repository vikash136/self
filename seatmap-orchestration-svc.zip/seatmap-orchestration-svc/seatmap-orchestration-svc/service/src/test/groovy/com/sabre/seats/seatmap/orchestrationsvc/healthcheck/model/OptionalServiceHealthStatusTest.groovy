package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model


import spock.lang.Specification

class OptionalServiceHealthStatusTest extends Specification {

    def "test"() {

        given:
        OptionalServiceHealthStatus  optionalServiceHealthStatus = new OptionalServiceHealthStatus()
        when:
        optionalServiceHealthStatus.setStatus(ServiceStatus.UP)
        optionalServiceHealthStatus.setComponent(new HashMap<String, ServiceInfo>())
        then:
        optionalServiceHealthStatus.getStatus().toString() == "UP"
        optionalServiceHealthStatus.getComponent().isEmpty()
    }

}
