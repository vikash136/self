package com.sabre.seats.seatmap.orchestrationsvc.webservice.connection

import io.grpc.ManagedChannel
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class AuthorizationChannelConnectionPoolTest extends Specification{

    def authorizationChannelConnectionLoadBalancer = new AuthorizationChannelConnectionLoadBalancer()
    def authChannelMock = Mock(ManagedChannel.class)
    def authorizationChannelList = Mock(ArrayList.class)

    def setup() {
        ReflectionTestUtils.setField(authorizationChannelConnectionLoadBalancer, "authorizationChannelList", authorizationChannelList)
    }

    def "test"(){
        when:
        def channel=authorizationChannelConnectionLoadBalancer.getManagedChannel();
        then:
        1 * authorizationChannelList.size() >> 2
        1 * authorizationChannelList.get(_) >> authChannelMock
        channel!=null

        when:
        def channel1=authorizationChannelConnectionLoadBalancer.getManagedChannel();
        then:
        1 * authorizationChannelList.size() >> 2
        1 * authorizationChannelList.get(_) >> authChannelMock
        channel1!=null

    }
}
