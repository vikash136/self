package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.authorization.protobuf.AuthorizationResponse
import com.sabre.seats.common.protobuf.*
import com.sabre.seats.connectivity.protobuf.ConnectivityConfiguration
import com.sabre.seats.error.protobuf.Description
import com.sabre.seats.error.protobuf.MessageCode
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.transformation.protobuf.InputRequest
import com.sabre.seats.transformation.protobuf.SeatMapOutputReqResponse
import com.sabre.seats.transformation.protobuf.TransformReqResponse
import io.grpc.ManagedChannelBuilder
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class TransformerSupplierToViewServiceTest extends Specification {

    def classUnderTest = Spy(TransformerSupplierToViewService)
    def errorMessageListBuilder = Mock(ErrorMessageListBuilder.class)
    def serviceTimeoutUtil = Mock(ServiceTimeoutUtil.class)
    def transformSeatMapRespToProtoChannel = ManagedChannelBuilder.forTarget("localhost").usePlaintext().build()

    def setup() {
        ReflectionTestUtils.setField(classUnderTest, "transformationServiceCallTimeout", 5000)
        ReflectionTestUtils.setField(classUnderTest, "transformationServiceVersion", "1")
        ReflectionTestUtils.setField(classUnderTest, "errorMessageListBuilder", errorMessageListBuilder)
        ReflectionTestUtils.setField(classUnderTest, "serviceTimeoutUtil", serviceTimeoutUtil)
        ReflectionTestUtils.setField(classUnderTest, "transformSeatMapRespToProtoChannel", transformSeatMapRespToProtoChannel)
    }

    def "send processRequest"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(reqRespContext,1)

        then:
        1 * classUnderTest.getTransformationResponse(_,_) >> getSuccessTransformationResponse()
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierResponseStatus()==ResponseStatus.SUCCESS
        reqRespContext.getFlightItemReqResContextMap().get(1).getSegmentResponse()!=null
    }

    def "send processRequestNonOffloaded"() {
        given:
        def reqRespContext=getRequestResponseContext("MN")

        when:
        classUnderTest.processFlightItem(reqRespContext,1)

        then:
        1 * classUnderTest.getTransformationResponse(_,_) >> getSuccessTransformationResponse()
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierResponseStatus()==ResponseStatus.SUCCESS
        reqRespContext.getFlightItemReqResContextMap().get(1).getSegmentResponse()!=null
    }

    def "send processRequest - connection time out"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(reqRespContext, 1)

        then:
        1 * serviceTimeoutUtil.setServiceDown(_)
        1 * errorMessageListBuilder.getTransformerExceptionResponse(_) >> getFailedTransformationResponse()
        thrown(ServiceTimeOutException.class)
    }

    def "send processRequest - Unknown exception"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(reqRespContext, 1)

        then:
        1 * classUnderTest.getTransformationResponse(_,_) >> {throw new Exception("test error")}
        1 * errorMessageListBuilder.getTransformerExceptionResponse(_) >> getFailedTransformationResponse()
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierResponseStatus()==ResponseStatus.FAILED
        reqRespContext.getFlightItemReqResContextMap().get(1).getSegmentResponse()!=null
    }

    def "send processRequest - core service call is failed"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")
        reqRespContext.getFlightItemReqResContextMap().get(1).setSupplierResponseStatus(ResponseStatus.FAILED)

        when:
        classUnderTest.processFlightItem(reqRespContext,1)
        then:
        0 * classUnderTest.getTransformationResponse(_,_)
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierResponseStatus()==null
        reqRespContext.getFlightItemReqResContextMap().get(1).getSegmentResponse()==null

        when:
        reqRespContext.getFlightItemReqResContextMap().get(1).setSupplierResponseStatus(ResponseStatus.SUCCESS)
        reqRespContext.getFlightItemReqResContextMap().get(1).setSeatmapResponseFromSupplier(null)
        classUnderTest.processFlightItem(reqRespContext,1)
        then:
        0 * classUnderTest.getTransformationResponse(_,_)
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierResponseStatus()==null
        reqRespContext.getFlightItemReqResContextMap().get(1).getSegmentResponse()==null

        when:
        reqRespContext.getFlightItemReqResContextMap().get(1).setSupplierResponseStatus(ResponseStatus.FAILED)
        reqRespContext.getFlightItemReqResContextMap().get(1).setSeatmapResponseFromSupplier(null)
        classUnderTest.processFlightItem(reqRespContext,1)
        then:
        0 * classUnderTest.getTransformationResponse(_,_)
        reqRespContext.getFlightItemReqResContextMap().get(1).getTransformSupplierResponseStatus()==null
        reqRespContext.getFlightItemReqResContextMap().get(1).getSegmentResponse()==null
    }

    def "send setTransformationServiceCallTimeout"() {
        when:
        classUnderTest.setTransformationServiceCallTimeout(5000)
        def res=classUnderTest.getTransformationServiceCallTimeout()
        then:
        res==5000
    }

    def getRequestResponseContext(String airlineCode){
        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setAirlineCode(airlineCode)
        flightDetails.setFlightNumber("12")
        flightDetails.setScheduledDepartureDate(LocalDate.parse("2021-06-26").toString())
        flightDetails.setReservationBookingDesignator("Y")
        flightDetails.setDepartureAirportCode("MCT")
        flightDetails.setArrivalAirportCode("BAH")

        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()
        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.RESERVATION.toString())
        getAirSeatMapRQ.setFlightInfo(List.of(flightDetails))

        ClientInfo clientInfo= ClientInfo.newBuilder()
                .setAgencyCode("AC")
                .setRequester(airlineCode=="MN"?"CID":"")
                .setRequesterType(RequesterType.GDS)
                .setClientContext("CC")
                .addEprKeywords("EPR1").addEprKeywords("EPR2")
                .build()

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setRequestVersion("1")
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)
        requestResponseContext.setClientInfo(clientInfo)
        requestResponseContext.setRequestInfo(requestInfo)
        requestResponseContext.getFlightItemReqResContextMap().put(1,getFlightItemReqResContext(airlineCode))

        return requestResponseContext
    }

    def getFlightItemReqResContext(String airlineCode){
        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode(airlineCode)
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        ConnectivityConfiguration connectivityConfiguration = ConnectivityConfiguration.newBuilder()
                .setApiVersion("1")
                .setMessageFormat(MessageFormat.JSON)
                .setConnectivityType("Mock Connection")
                .setConnectivityDestination("http://localhost:8080/v1/seatscore/seatmap")
                .build()

        ResponseInfo responseInfo = null

        if (airlineCode =="MN"){
            responseInfo = ResponseInfo.newBuilder()
                    .setResponseStatus(ResponseStatus.SUCCESS)
                    .build()
        }else {
            responseInfo = ResponseInfo.newBuilder()
                    .setResponseStatus(ResponseStatus.NOT_OFFLOADED)
                    .build()
        }

        AuthorizationResponse authorizationResponse = AuthorizationResponse.newBuilder()
                .setResponseInfo(responseInfo)
                .build()
        FlightItemReqResContext flightItemReqResContext = new FlightItemReqResContext()
        flightItemReqResContext.setSegmentInfo(segmentInfo)
        flightItemReqResContext.setSupplierResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setConnectivityConfiguration(connectivityConfiguration)
        flightItemReqResContext.setSeatmapResponseFromSupplier("test")
        flightItemReqResContext.setAuthorizationResponse(authorizationResponse)
        return flightItemReqResContext
    }

    def getSuccessTransformationResponse(){

        FlightSeatMap flightSeatMap=FlightSeatMap.newBuilder()
                .addSeatmap(Seatmap.newBuilder().addCabins(Cabin.newBuilder().build()).setDepartureAirportCode("AUH").build())
                .build()

        SegmentResponse segmentResponse= SegmentResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setFlightSeatmap(flightSeatMap).build()

        InputRequest outputResponse = InputRequest.newBuilder()
                .setSegmentResponse(segmentResponse)
                .build()

        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setOutputResponse(outputResponse)
                .build()

        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build()
    }

    def getFailedTransformationResponse(){
        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getFailedResponse())
                .build();

        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build();
    }

    def getSuccessResponse(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.SUCCESS)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .build()
    }

    def getFailedResponse(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .addErrorMessages(getProtoErrorMessage())
                .build()
    }

    def getProtoErrorMessage(){
        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("123")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("APPLICATION")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("test")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }
}
