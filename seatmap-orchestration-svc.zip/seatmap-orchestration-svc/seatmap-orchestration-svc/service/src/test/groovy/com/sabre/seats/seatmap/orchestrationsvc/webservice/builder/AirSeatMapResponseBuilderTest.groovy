package com.sabre.seats.seatmap.orchestrationsvc.webservice.builder

import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.common.protobuf.ResponseInfo
import com.sabre.seats.common.protobuf.ResponseStatus
import com.sabre.seats.common.protobuf.SeatmapViewType
import com.sabre.seats.error.protobuf.Description
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.error.protobuf.MessageCode
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class AirSeatMapResponseBuilderTest extends Specification {

    def classUnderTest = Spy(AirSeatMapResponseBuilder.class)
    def errorMessageListBuilder= Mock(ErrorMessageListBuilder.class)
    String mockPosResponseFromTransformer="{\"transactionId\":\"9876543210\",\"requestDateTime\":\"2021-03-26T12:52:00.237Z\",\"version\":\"1\",\"correlationId\":\"1987654321\",\"status\":\"2\",\"supplierType\":\"AIR\",\"warningMessages\":[],\"errorMessages\":[],\"flightSeatMaps\":[{\"flightInfo\":{\"airlineCode\":\"AA\",\"arrivalAirportCode\":\"AUH\",\"departureAirportCode\":\"KWI\",\"flightNumber\":\"105\",\"reservationBookingDesignator\":\"Y\",\"scheduleDepartureDate\":\"2021-04-15\"},\"seatmaps\":[],\"warningMessages\":[],\"errorMessages\":[{\"errorCode\":\"IATAErrorCode\",\"descText\":\"NotAuthorisedtoviewseatmap\",\"errorId\":\"AUTH-2001\",\"errorType\":\"BUSINESS\"}]}]}"

    def setup() {
        ReflectionTestUtils.setField(classUnderTest, "errorMessageListBuilder", errorMessageListBuilder)
    }

    def "test processRequest Success"() {
        given:
        WebServiceRequestResponseContext requestResponseContext = getRequestResponseContext()
        requestResponseContext.setTransformPosResponseToJsonStatus(ResponseStatus.SUCCESS)
        requestResponseContext.setSeatmapResponseToPOS(mockPosResponseFromTransformer)

        when:
        classUnderTest.processRequest(requestResponseContext)
        then:
        requestResponseContext.getAirSeatMapResponse()!=null
    }

    def "test processRequest Failure"() {
        given:
        WebServiceRequestResponseContext requestResponseContext = getRequestResponseContext()
        requestResponseContext.setTransformPosResponseToJsonStatus(ResponseStatus.FAILED)
        requestResponseContext.setResponseInfo(getFailedResponseInfo())

        when:
        classUnderTest.processRequest(requestResponseContext)
        then:
        1 * errorMessageListBuilder.getErrorMessageListForFinalResp(_) >> getSabreErrorMessageList()
        requestResponseContext.getAirSeatMapResponse()!=null

    }

    def "test processRequest Failure - with timestamp & departureDate is null "() {
        given:
        WebServiceRequestResponseContext requestResponseContext = getRequestResponseContext()
        requestResponseContext.getAirSeatMapRQ().setRequestDateTime(null)
        requestResponseContext.getAirSeatMapRQ().getFlightInfo().get(0).setScheduledDepartureDate(null)
        requestResponseContext.setTransformPosResponseToJsonStatus(ResponseStatus.FAILED)
        requestResponseContext.setResponseInfo(getFailedResponseInfo())

        when:
        classUnderTest.processRequest(requestResponseContext)
        then:
        1 * errorMessageListBuilder.getErrorMessageListForFinalResp(_) >> getSabreErrorMessageList()
        requestResponseContext.getAirSeatMapResponse()!=null

    }

    def getRequestResponseContext() {
        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.RESERVATION.toString())
        getAirSeatMapRQ.setFlightInfo(getFlightList())
        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)

        return requestResponseContext
    }

    def getFlightList() {
        List<FlightCriteriaRequest> flightDetailsList = new ArrayList<>()
        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setFlightNumber("567")
        flightDetails.setAirlineCode("AA")
        flightDetails.setArrivalAirportCode("AUH")
        flightDetails.setDepartureAirportCode("DFA")
        flightDetails.setScheduledDepartureDate(LocalDate.now().toString())
        flightDetails.setReservationBookingDesignator("aa")
        flightDetailsList.add(flightDetails);
        return flightDetailsList
    }

    def getFailedResponseInfo(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .addErrorMessages(getProtoErrorMessage())
                .build()
    }

    def getProtoErrorMessage() {
        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("1001")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("BUSINESS")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("Test Error")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }

    def getSabreErrorMessageList() {
        com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage errorMessage=new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage()
        errorMessage.setCategory("Test")
        errorMessage.setType("test")

        return Arrays.asList(errorMessage)
    }


}
