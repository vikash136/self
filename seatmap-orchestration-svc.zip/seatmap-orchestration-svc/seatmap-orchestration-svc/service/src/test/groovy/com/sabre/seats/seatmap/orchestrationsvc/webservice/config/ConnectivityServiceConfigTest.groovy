package com.sabre.seats.seatmap.orchestrationsvc.webservice.config

import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class ConnectivityServiceConfigTest extends Specification{
    def connectivityServiceConfig=new ConnectivityServiceConfig()

    def setup() {
        ReflectionTestUtils.setField(connectivityServiceConfig, "connectivityServiceUrl", "localhost")
        ReflectionTestUtils.setField(connectivityServiceConfig, "connectivityServicePort", 8090)
        ReflectionTestUtils.setField(connectivityServiceConfig, "keepAliveTime", 30000)
    }

    def "test"(){
        when:
        def channel=connectivityServiceConfig.getConnectivityServiceManagedChannel()
        then:
        channel!=null
    }
}
