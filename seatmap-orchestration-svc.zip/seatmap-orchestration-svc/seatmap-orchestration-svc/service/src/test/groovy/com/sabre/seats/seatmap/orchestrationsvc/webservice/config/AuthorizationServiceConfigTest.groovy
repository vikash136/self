package com.sabre.seats.seatmap.orchestrationsvc.webservice.config


import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class AuthorizationServiceConfigTest extends Specification {

    def authorizationServiceConfig = new AuthorizationServiceConfig()

    def setup() {
        ReflectionTestUtils.setField(authorizationServiceConfig, "authorizationServiceUrl", "test-seats-authorization-service.seats-edge-cluster.svc.cluster.local")
        ReflectionTestUtils.setField(authorizationServiceConfig, "authorizationServicePort", 8090)
        ReflectionTestUtils.setField(authorizationServiceConfig, "keepAliveTime", 30000)
    }

    def "test - getAuthorizationChannel"(){
        when:
        def channel=authorizationServiceConfig.getAuthorizationChannel()
        then:
        channel!=null

    }

}
