package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.common.protobuf.ResponseStatus
import spock.lang.Specification

class FlightItemServiceTest extends Specification {

    def flightItemProcessors=new ArrayList<FlightItemProcessor>()
    def classUnderTest = new FlightItemService()
    AuthorizationService authorizationService = Mock()
    ConnectivityService connectivityService = Mock()
    ViewService viewService =Mock()
    TransformerConnectivityToSupplierService connectivityToCoreTransformerService = Mock()
    SeatmapSupplierService seatmapCoreService = Mock()
    TransformerSupplierToViewService transformCoreSeatMapResponseToViewService = Mock()

    def setup() {
        flightItemProcessors.add(authorizationService)
        flightItemProcessors.add(connectivityService)
        flightItemProcessors.add(connectivityToCoreTransformerService)
        flightItemProcessors.add(seatmapCoreService)
        flightItemProcessors.add(transformCoreSeatMapResponseToViewService)
        flightItemProcessors.add(viewService)
        classUnderTest.flightItemProcessors = flightItemProcessors
    }

    def "test processFlightItem"() {
        given:
        WebServiceRequestResponseContext webContext = new WebServiceRequestResponseContext()
        webContext.setTransformPosRequestToProtoStatus(ResponseStatus.SUCCESS)
        webContext.getFlightItemReqResContextMap().put(1, new FlightItemReqResContext())

        when:
        classUnderTest.processRequest(webContext)

        then:
        1 * authorizationService.processFlightItem(_, _)
        1 * connectivityService.processFlightItem(_, _)
        1 * connectivityToCoreTransformerService.processFlightItem(_, _)
        1 * seatmapCoreService.processFlightItem(_, _)
        1 * transformCoreSeatMapResponseToViewService.processFlightItem(_,_)
        1 * viewService.processFlightItem(_, _) >> {throw new ServiceTimeOutException("test error")}
    }

    def 'test processFlightItem - empty flightItemReqResContextList'() {
        given:
        WebServiceRequestResponseContext webContext = new WebServiceRequestResponseContext()
        webContext.setTransformPosRequestToProtoStatus(ResponseStatus.SUCCESS)

        when:
        classUnderTest.processRequest(webContext)
        then:
        0 * authorizationService.processFlightItem(_, _)

        when:
        webContext.setTransformPosRequestToProtoStatus(ResponseStatus.FAILED)
        webContext.getFlightItemReqResContextMap().put(1, new FlightItemReqResContext())
        classUnderTest.processRequest(webContext)
        then:
        0 * authorizationService.processFlightItem(_, _)

        when:
        webContext.setTransformPosRequestToProtoStatus(ResponseStatus.FAILED)
        classUnderTest.processRequest(webContext)
        then:
        0 * authorizationService.processFlightItem(_, _)

        when:
        webContext.setFlightItemReqResContextMap(null)
        webContext.setTransformPosRequestToProtoStatus(null)
        classUnderTest.processRequest(webContext)
        then:
        0 * authorizationService.processFlightItem(_, _)
    }

}
