package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers

import com.sabre.seats.common.protobuf.Cabin
import com.sabre.seats.common.protobuf.RequesterType
import com.sabre.seats.common.protobuf.ClientInfo
import com.sabre.seats.common.protobuf.FlightInfo
import com.sabre.seats.common.protobuf.FlightSeatMap
import com.sabre.seats.common.protobuf.RequestInfo
import com.sabre.seats.common.protobuf.Seatmap
import com.sabre.seats.common.protobuf.SegmentInfo
import com.sabre.seats.common.protobuf.SeatmapViewType
import com.sabre.seats.common.protobuf.SupplierType
import com.sabre.seats.seatmapView.protobuf.*
import io.grpc.stub.StreamObserver
import spock.lang.Specification

import java.time.Instant

class MockViewServiceTest extends Specification{

    def classUnderTest = Spy(MockViewService.class)

    def "test getMockViewResponse"() {

        when:
        classUnderTest.view(getSeatMapViewRequest("I0"), getResponseObserver())

        then:
        true
    }

    def "test getMockViewResponse -Failure"() {
        when:
        classUnderTest.view(getSeatMapViewRequest("AA"), getResponseObserver())

        then:
        true
    }

    def "test getMockViewResponse exception"() {
        when:
        classUnderTest.view(null, getResponseObserver())

        then:
        true
    }

    def getSeatMapViewRequest(String airlineCode){

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        ClientInfo clientInfo=ClientInfo.newBuilder()
                .setRequester("I0")
                .setRequesterType(RequesterType.GDS)
                .setAgencyCode("1234")
                .setClientContext("sabre")
                .build()

        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode(airlineCode)
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        FlightSeatMap flightSeatMap=FlightSeatMap.newBuilder()
                .addSeatmap(Seatmap.newBuilder().addCabins(Cabin.newBuilder().build()).setDepartureAirportCode("AUH").build())
                .build()

        return  SeatmapViewRequest.newBuilder()
                .setSupplierCode(airlineCode)
                .setRequestInfo(requestInfo)
                .setSegmentInfo(segmentInfo)
                .setClientInfo(clientInfo)
                .setFlightSeatmap(flightSeatMap)
                .build()

    }

    def getResponseObserver() {
        return new StreamObserver<SeatmapViewResponse>() {

            @Override
            void onNext(SeatmapViewResponse seatmapViewResponse) {
                System.out.println("SeatmapViewResponse response " + seatmapViewResponse.toString())
            }


            @Override
            void onError(Throwable throwable) {
            }

            @Override
            void onCompleted() {
            }
        }
    }

}
