package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.AirSeatMapResponseBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse

import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.common.protobuf.SeatmapViewType
import io.micrometer.core.instrument.simple.SimpleMeterRegistry
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class GetAirSeatMapServiceTest extends Specification {

    def classUnderTest = new GetAirSeatMapService()

    def healthCheckService= Mock(HealthCheckService.class)
    def jwtDecoderService= Mock(JWTDecoderService.class)
    def transformerAirSeatMapRQToAuthorizationService= Mock(TransformerAirSeatMapRQToAuthorizationService.class)
    def flightItemService = Mock(FlightItemService.class)
    def requestProcessors=new ArrayList<RequestProcessor>()
    def airSeatMapResponseBuilder = Mock(AirSeatMapResponseBuilder.class)
    def errorMessageListBuilder= Mock(ErrorMessageListBuilder.class)
    def meterRegistry = new SimpleMeterRegistry();

    def setup() {
        classUnderTest.healthCheckService=healthCheckService
        requestProcessors.add(jwtDecoderService)
        requestProcessors.add(transformerAirSeatMapRQToAuthorizationService)
        requestProcessors.add(flightItemService)
        requestProcessors.add(airSeatMapResponseBuilder)
        classUnderTest.airSeatMapResponseBuilder=airSeatMapResponseBuilder
        classUnderTest.errorMessageListBuilder=errorMessageListBuilder
        classUnderTest.requestProcessors=requestProcessors
        ReflectionTestUtils.setField(classUnderTest, "meterRegistry", meterRegistry)
    }

    def "handle air seat map request when success"() {
        given:
        WebServiceRequestResponseContext requestResponseContext = getRequestResponseContext()

        when:
        def resp=classUnderTest.handleRequest(requestResponseContext)

        then:
        1 * healthCheckService.isHealthStable() >> true
        1 * jwtDecoderService.processRequest (_)
        1 * transformerAirSeatMapRQToAuthorizationService.processRequest(_)
        1 * flightItemService.processRequest(_)
        1 * airSeatMapResponseBuilder.processRequest(_)
        null!=resp
    }

    def "handle air seat map request when health down exception occurred"() {
        given:
        WebServiceRequestResponseContext requestResponseContext = getRequestResponseContext()

        when:
        def resp=classUnderTest.handleRequest(requestResponseContext)

        then:
        1 * healthCheckService.isHealthStable() >> false
        0 * jwtDecoderService.processRequest (_)
        0 * transformerAirSeatMapRQToAuthorizationService.processRequest(_)
        0 * flightItemService.processRequest(_)
        0 * airSeatMapResponseBuilder.processRequest(_)
        1 * errorMessageListBuilder.getErrorMessageList (_) >> Arrays.asList(new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage())
        1 * airSeatMapResponseBuilder.getAirSeatMapErrorResponse(_,_) >> new AirSeatMapResponse()
        null!=resp
    }

    def "handle air seat map request when timeout exception occurred"() {
        given:
        WebServiceRequestResponseContext requestResponseContext = getRequestResponseContext()

        when:
        classUnderTest.handleRequest(requestResponseContext)

        then:
        1 * healthCheckService.isHealthStable() >> true
        1 * jwtDecoderService.processRequest (_)
        1 * transformerAirSeatMapRQToAuthorizationService.processRequest(_) >> { throw new ServiceTimeOutException("Time out Exception") }
        0 * flightItemService.processRequest(_)
        1 * errorMessageListBuilder.getErrorMessageList (_) >> Arrays.asList(new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage())
        1 * airSeatMapResponseBuilder.getAirSeatMapErrorResponse(_,_) >> new AirSeatMapResponse()
    }

    def "handle air seat map request when unknown exception occurred"() {
        given:
        WebServiceRequestResponseContext requestResponseContext = getRequestResponseContext()

        when:
        classUnderTest.handleRequest(requestResponseContext)

        then:
        1 * healthCheckService.isHealthStable() >> true
        1 * jwtDecoderService.processRequest (_)
        1 * transformerAirSeatMapRQToAuthorizationService.processRequest(_)
        1 * flightItemService.processRequest(_) >> { throw new Exception("Test-Exception") }
        1 * errorMessageListBuilder.getErrorMessageList (_) >> Arrays.asList(new com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage())
        1 * airSeatMapResponseBuilder.getAirSeatMapErrorResponse(_,_) >> new AirSeatMapResponse()
    }

    def getRequestResponseContext() {
        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.CHECK_IN.toString())
        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())
        getAirSeatMapRQ.setFlightInfo(getFlightList())

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setRequestVersion("1")
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)
        requestResponseContext.setAirSeatMapResponse(new AirSeatMapResponse())

        return requestResponseContext
    }

    def getFlightList() {
        List<FlightCriteriaRequest> flightDetailsList = new ArrayList<>()
        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setFlightNumber("567")
        flightDetails.setAirlineCode("AA")
        flightDetails.setArrivalAirportCode("AUH")
        flightDetails.setDepartureAirportCode("DFA")
        flightDetails.setScheduledDepartureDate(LocalDate.now().toString())
        flightDetails.setReservationBookingDesignator("aa")
        flightDetailsList.add(flightDetails);
        return flightDetailsList
    }

}
