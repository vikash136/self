package com.sabre.seats.seatmap.orchestrationsvc.webservice.connection

import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class EssmHttpPublicKeyConnectionPropertyTest extends Specification {

    def essmHttpPublicKeyConnectionProperty=Spy(EssmHttpPublicKeyConnectionProperty.class)
    def setup() {
        ReflectionTestUtils.setField(essmHttpPublicKeyConnectionProperty, "connectTimeout", 50000)
        ReflectionTestUtils.setField(essmHttpPublicKeyConnectionProperty, "socketTimeout", 50000)
    }

    def "test"(){
        when:
        essmHttpPublicKeyConnectionProperty.init()
        then:
        true
    }
}
