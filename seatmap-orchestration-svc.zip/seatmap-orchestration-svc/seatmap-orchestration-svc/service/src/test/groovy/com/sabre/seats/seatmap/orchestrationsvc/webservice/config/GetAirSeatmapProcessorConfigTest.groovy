package com.sabre.seats.seatmap.orchestrationsvc.webservice.config

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.AirSeatMapResponseBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.AuthorizationService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.ConnectivityService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TransformerConnectivityToSupplierService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.FlightItemService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.JWTDecoderService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.SeatmapSupplierService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TransformerAirSeatMapRQToAuthorizationService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TransformerSupplierToViewService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TransformerResponseToPOSService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.ViewService
import spock.lang.Specification

class GetAirSeatmapProcessorConfigTest extends Specification{

    def getAirSeatmapProcessorConfig = new GetAirSeatmapProcessorConfig()

    def "test"(){
        when:
        def requestProcessors=getAirSeatmapProcessorConfig.getRequestProcessorList(Mock(JWTDecoderService.class),
                Mock(TransformerAirSeatMapRQToAuthorizationService.class),
                Mock(FlightItemService.class),
                Mock(TransformerResponseToPOSService.class),
                Mock(AirSeatMapResponseBuilder.class))
        then:
        requestProcessors.size()==5

        when:
        def flightItemProcessors=getAirSeatmapProcessorConfig.getFlightItemProcessorsProcessorList(Mock(AuthorizationService.class),
                Mock(ConnectivityService.class),
                Mock(TransformerConnectivityToSupplierService.class),
                Mock(SeatmapSupplierService.class),
                Mock(TransformerSupplierToViewService.class),
                Mock(ViewService.class))
        then:
        flightItemProcessors.size()==6
    }
}
