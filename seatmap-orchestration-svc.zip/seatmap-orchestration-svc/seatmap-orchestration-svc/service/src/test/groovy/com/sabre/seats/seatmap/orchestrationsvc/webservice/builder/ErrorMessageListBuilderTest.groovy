package com.sabre.seats.seatmap.orchestrationsvc.webservice.builder

import com.sabre.connector.model.ConnectorResponse
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ErrorMapUtil
import com.sabre.seats.authorization.protobuf.AuthorizationResponse
import com.sabre.seats.common.protobuf.ResponseInfo
import com.sabre.seats.common.protobuf.ResponseStatus
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationResponse
import com.sabre.seats.error.protobuf.Description
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.error.protobuf.MessageCode
import com.sabre.seats.seatmapView.protobuf.SeatmapViewResponse
import com.sabre.seats.transformation.protobuf.TransformReqResponse
import spock.lang.Specification

class ErrorMessageListBuilderTest extends Specification {

    def errorMapUtil = getErrorMapUtil()
    def classUnderTest = new ErrorMessageListBuilder(errorMap: errorMapUtil)

    def "get Sabre Error Message List"() {
        when:
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage> errorMessageList = classUnderTest.getErrorMessageList("HealthDown")

        then:
        errorMessageList.get(0) != null
    }

    def "get Converted Sabre Error Message List"() {
        when:
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage> errorMessageList = classUnderTest.getErrorMessageListForFinalResp(getProtoErrorMessageList())

        then:
        errorMessageList.get(0) != null
    }

    def "get Converted Sabre Error Message null"() {
        when:
        List<com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.ErrorMessage> errorMessageList = classUnderTest.getErrorMessageListForFinalResp(getProtoErrorMessageNullList())

        then:
        errorMessageList.get(0) != null
    }

    def "get getTransformerExceptionResponse"() {
        when:
        TransformReqResponse transformReqResponse = classUnderTest.getTransformerExceptionResponse("HealthDown")

        then:
        transformReqResponse.getSeatMapOutputReqResponse().getResponseInfo().getErrorMessagesList().size()==1
    }

    def "get getAuthorizationExceptionResponse"() {
        when:
        AuthorizationResponse authorizationResponse = classUnderTest.getAuthorizationExceptionResponse("HealthDown")

        then:
        authorizationResponse.getResponseInfo().getErrorMessagesList().size()==1
    }

    def "get getConnectivityExceptionResponse"() {
        when:
        ConnectivityConfigurationResponse connectivityConfigurationResponse = classUnderTest.getConnectivityExceptionResponse("HealthDown")

        then:
        connectivityConfigurationResponse.getResponseInfo().getErrorMessagesList().size()==1
    }

    def "get getSeatmapViewExceptionResponse"() {
        when:
        SeatmapViewResponse seatmapViewResponse = classUnderTest.getSeatmapViewExceptionResponse("HealthDown")

        then:
        seatmapViewResponse.getResponseInfo().getErrorMessagesList().size()==1
    }

    def "get getWarningResponseInfo"() {
        when:
        ResponseInfo responseInfo = classUnderTest.getWarningResponseInfo("HealthDown")

        then:
        responseInfo.getResponseStatus()== ResponseStatus.SUCCESS
    }

    def "get Error Message List"() {
        when:
        ResponseInfo responseInfo = classUnderTest.getResponseInfo(getConnectorResponse())

        then:
        responseInfo.getErrorMessages(0) != null
    }


    def getErrorMapUtil() {
        Map<String, String> map = new HashMap<>()
        map.put("category", "INTERNAL_SERVER_ERROR")
        map.put("type", "DOWNLINE_SERVICE_DOWN")
        map.put("description-languageTag", "UTF-11111")
        map.put("description-message", "Downline service is down")
        map.put("errorCodeIata-code", "102")
        map.put("errorCodeIata-codeContext", "IATA")
        map.put("errorCodeInternal-code", "3001")
        map.put("errorCodeInternal-codeContext", "INTERNAL")

        Map<String, Map<String, String>> errorMap = new HashMap<>()
        errorMap.put("HealthDown", map)

        ErrorMapUtil errorMapUtil = new ErrorMapUtil()
        errorMapUtil.setErrormap(errorMap)

        return errorMapUtil
    }

    def getProtoErrorMessageList() {
        List<ErrorMessage> errorMessageList = new ArrayList<>()
        errorMessageList.add(getProtoErrorMessage())
        return errorMessageList
    }

    def getProtoErrorMessage() {
        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("123")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("APPLICATION")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("healthDown")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }

    def getConnectorResponse() {
        ConnectorResponse connectorResponse = new ConnectorResponse()
        List<com.sabre.connector.model.ErrorMessage> errorMessageList = new ArrayList<>()
        errorMessageList.add(getTpfErrorMessage())
        connectorResponse.setErrorMessages(errorMessageList)
        return connectorResponse
    }



    def getTpfErrorMessage() {
        com.sabre.connector.model.ErrorMessage errorMessage = new com.sabre.connector.model.ErrorMessage()
        errorMessage.setCategory("Internal error")
        errorMessage.setType("Validation")
        errorMessage.setIataMessage("Application Temporarily Unavailable")
        errorMessage.setErrorCodeIata("102")
        errorMessage.setErrorCodeInternal("TPFC-3001")
        errorMessage.setFieldName("")
        errorMessage.setFieldPath("")
        return errorMessage
    }

    def getProtoErrorMessageNullList() {
        List<ErrorMessage> errorMessageList = new ArrayList<>()
        errorMessageList.add(getProtoErrorMessage())
        return errorMessageList
    }

    def getProtoErrorMessageDescNull() {
        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("123")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("APPLICATION")
                .setDescription(null)
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }

}
