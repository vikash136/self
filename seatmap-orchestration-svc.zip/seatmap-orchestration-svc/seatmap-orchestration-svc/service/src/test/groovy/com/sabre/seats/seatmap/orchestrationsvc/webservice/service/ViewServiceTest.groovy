package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.client.ServiceClient
import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore
import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.common.protobuf.*
import com.sabre.seats.error.protobuf.Description
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.error.protobuf.MessageCode
import com.sabre.seats.seatmapView.protobuf.SeatmapViewResponse
import io.grpc.ManagedChannelBuilder
import io.grpc.health.v1.HealthCheckResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class ViewServiceTest extends Specification{

    def classUnderTest = Spy(ViewService.class)
    def errorMessageListBuilder = Mock(ErrorMessageListBuilder.class)
    def viewServiceChannel = ManagedChannelBuilder.forTarget("localhost").usePlaintext().build()
    def serviceClient = Mock(ServiceClient.class)
    def serviceHealthCheckStore = Mock(ServiceHealthCheckStore.class)

    def setup(){
        ReflectionTestUtils.setField(classUnderTest, "viewServiceCallTimeout", 5000)
        ReflectionTestUtils.setField(classUnderTest, "errorMessageListBuilder", errorMessageListBuilder)
        ReflectionTestUtils.setField(classUnderTest, "viewServiceChannel", viewServiceChannel)
        ReflectionTestUtils.setField(classUnderTest, "viewServiceVersion", "1")
        ReflectionTestUtils.setField(classUnderTest, "serviceClient", serviceClient)
        ReflectionTestUtils.setField(classUnderTest, "serviceHealthCheckStore", serviceHealthCheckStore)
    }

    def "send processFlightItem"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * serviceClient.getServiceStatus(_, _) >> HealthCheckResponse.ServingStatus.SERVING.name()
        1 * classUnderTest.getResponseFromViewService(_,_) >> getSuccessViewResponse(serviceRequestResponseContext)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()==ResponseStatus.SUCCESS
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getSegmentResponse().getFlightSeatmap()!=null
    }

    def "send processFlightItem - CNot serving status"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * serviceClient.getServiceStatus(_, _) >> HealthCheckResponse.ServingStatus.NOT_SERVING.name()
        1 * errorMessageListBuilder.getWarningResponseInfo(_) >> getSuccessResponse()
        0 * serviceHealthCheckStore.updateOptionalServiceHealthStatus(_)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()==ResponseStatus.SUCCESS
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getSegmentResponse().getFlightSeatmap()!=null
    }

    def "send processFlightItem - Connection timeout exception"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * serviceClient.getServiceStatus(_, _) >> HealthCheckResponse.ServingStatus.SERVING.name()
        1 * serviceHealthCheckStore.updateOptionalServiceHealthStatus(_)
        1 * errorMessageListBuilder.getWarningResponseInfo(_) >> getSuccessResponse()
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()==ResponseStatus.SUCCESS
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getSegmentResponse().getFlightSeatmap()!=null
    }

    def "send processFlightItem - unknown exception"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * serviceClient.getServiceStatus(_, _) >> HealthCheckResponse.ServingStatus.SERVING.name()
        1 * classUnderTest.getResponseFromViewService(_,_) >> {throw new Exception("test error")}
        1 * errorMessageListBuilder.getSeatmapViewExceptionResponse(_) >> getSeatmapViewExceptionResponse()
        0 * serviceHealthCheckStore.updateOptionalServiceHealthStatus(_)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()==ResponseStatus.FAILED
    }

    def "test processFlightItem - previous call is failed" () {
        given:
        WebServiceRequestResponseContext webContext = getRequestResponseContext("I0")

        when:
        webContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(ResponseStatus.NOT_OFFLOADED)
        classUnderTest.processFlightItem(webContext,1)
        then:
        null==webContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()

        when:
        webContext.getFlightItemReqResContextMap().get(1).setSegmentResponse(getSegmentResponse_with_empty_FlightSeatmap())
        webContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(ResponseStatus.SUCCESS)
        classUnderTest.processFlightItem(webContext,1)
        then:
        null==webContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()

        when:
        webContext.getFlightItemReqResContextMap().get(1).setSegmentResponse(getSegmentResponse_with_Failure())
        webContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(ResponseStatus.FAILED)
        classUnderTest.processFlightItem(webContext,1)
        then:
        null==webContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()

        when:
        webContext.getFlightItemReqResContextMap().get(1).setTransformSupplierResponseStatus(ResponseStatus.FAILED)
        webContext.getFlightItemReqResContextMap().get(1).setSegmentResponse(getSegmentResponse())
        webContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(ResponseStatus.SUCCESS)
        classUnderTest.processFlightItem(webContext,1)
        then:
        null==webContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()

        when:
        webContext.getFlightItemReqResContextMap().get(1).setTransformSupplierResponseStatus(ResponseStatus.FAILED)
        webContext.getFlightItemReqResContextMap().get(1).setSegmentResponse(getSegmentResponse_with_empty_FlightSeatmap())
        webContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(ResponseStatus.FAILED)
        classUnderTest.processFlightItem(webContext,1)
        then:
        null==webContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()

        when:
        webContext.getFlightItemReqResContextMap().get(1).setTransformSupplierResponseStatus(ResponseStatus.FAILED)
        webContext.getFlightItemReqResContextMap().get(1).setSegmentResponse(getSegmentResponse_with_Failure())
        webContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(ResponseStatus.NOT_OFFLOADED)
        classUnderTest.processFlightItem(webContext,1)
        then:
        null==webContext.getFlightItemReqResContextMap().get(1).getViewResponseStatus()

    }

    def "send setViewServiceCallTimeout"() {
        when:
        classUnderTest.setViewServiceCallTimeout(1000)
        def res=classUnderTest.getViewServiceCallTimeout()
        then:
        res==1000
    }

    def getRequestResponseContext(String airlineCode){
        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setAirlineCode(airlineCode)
        flightDetails.setFlightNumber("123")
        flightDetails.setScheduledDepartureDate(LocalDate.parse("2020-08-20").toString())
        flightDetails.setReservationBookingDesignator("Y")
        flightDetails.setDepartureAirportCode("AUH")
        flightDetails.setArrivalAirportCode("DFW")

        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()
        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.RESERVATION.toString())
        getAirSeatMapRQ.setFlightInfo(List.of(flightDetails))

        ClientInfo clientInfo= ClientInfo.newBuilder()
                .setAgencyCode("AC")
                .setRequester("CID")
                .setRequesterType(RequesterType.GDS)
                .setClientContext("CC")
                .addEprKeywords("EPR1").addEprKeywords("EPR2")
                .build()

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setRequestVersion("1")
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)
        requestResponseContext.setClientInfo(clientInfo)
        requestResponseContext.setRequestInfo(requestInfo)
        requestResponseContext.getFlightItemReqResContextMap().put(1,getFlightItemReqResContext(airlineCode))

        return requestResponseContext
    }

    def getFlightItemReqResContext(String airlineCode){
        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode(airlineCode)
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        Supplier supplier = Supplier.newBuilder()
                .setAirlineCode(airlineCode)
                .build()

        FlightItemReqResContext flightItemReqResContext = new FlightItemReqResContext()
        flightItemReqResContext.setSegmentInfo(segmentInfo)
        flightItemReqResContext.setAuthorizationResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setTransformSupplierResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setSegmentResponse(getSegmentResponse())
        flightItemReqResContext.setSupplier(supplier)

        List<PassengerSeatmapRetrieveRequest> passengerSeatmapRetrieveRequestList = new ArrayList<>()

        PassengerSeatmapRetrieveRequest passengerSeatmapRetrieveRequest = PassengerSeatmapRetrieveRequest.newBuilder()
                .setFirstName("test")
                .setLastName("test")
                .build()

        passengerSeatmapRetrieveRequestList.add(passengerSeatmapRetrieveRequest)
        flightItemReqResContext.setPassengerSeatmapRetrieveRequestList(passengerSeatmapRetrieveRequestList)


        return flightItemReqResContext
    }

    def getSegmentResponse(){
        FlightSeatMap flightSeatMap=FlightSeatMap.newBuilder()
                .addSeatmap(Seatmap.newBuilder().addCabins(Cabin.newBuilder().build()).setDepartureAirportCode("AUH").build())
                .build()

        return SegmentResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setFlightSeatmap(flightSeatMap).build()
    }

    def getSegmentResponse_with_empty_FlightSeatmap(){
        return SegmentResponse.newBuilder()
                .setResponseInfo(getSuccessResponse()).build()
    }

    def getSegmentResponse_with_Failure(){
        return SegmentResponse.newBuilder()
                .setResponseInfo(getFailedResponse()).build()
    }

    def getSuccessResponse(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.SUCCESS)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .build()
    }

    def getFailedResponse(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .build()
    }

    def getSuccessViewResponse(WebServiceRequestResponseContext requestResponseContext){
        return SeatmapViewResponse.newBuilder()
                .setRequestInfo(requestResponseContext.getRequestInfo())
                .setSegmentInfo(requestResponseContext.getFlightItemReqResContextMap().get(1).getSegmentInfo())
                .setClientInfo(requestResponseContext.getClientInfo())
                .setFlightSeatmap(requestResponseContext.getFlightItemReqResContextMap().get(1).getSegmentResponse().getFlightSeatmap())
                .setResponseInfo(getSuccessResponse())
                .build()
    }

    def getSeatmapViewExceptionResponse(){
        ResponseInfo responseInfo=ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setResponseTimestamp(Instant.now().toString())
                .addErrorMessages(getProtoErrorMessage()).build()

        return SeatmapViewResponse.newBuilder().setResponseInfo(responseInfo).build()
    }

    def getProtoErrorMessage(){
        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("123")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("APPLICATION")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("test")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }
}
