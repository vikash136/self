package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.model

import spock.lang.Specification

import java.time.Instant

class ServiceInfoTest extends Specification{

    def "test"(){
        given:
        ServiceInfo serviceInfo=new ServiceInfo()
        long t=Instant.now().toEpochMilli()

        when:
        serviceInfo.setUpdateTimestamp(t)
        serviceInfo.setName("test")
        serviceInfo.setStatus(ServiceStatus.UP)

        then:
        serviceInfo.getUpdateTimestamp()==t
        serviceInfo.getName()=="test"
        serviceInfo.getStatus()==ServiceStatus.UP
    }
}
