package com.sabre.seats.seatmap.orchestrationsvc.grpcmockservers

import com.google.protobuf.Timestamp
import com.sabre.seats.authorization.protobuf.AuthorizationRequest
import com.sabre.seats.authorization.protobuf.AuthorizationResponse
import com.sabre.seats.common.protobuf.FlightInfo
import com.sabre.seats.common.protobuf.RequestInfo
import com.sabre.seats.common.protobuf.SegmentInfo
import com.sabre.seats.common.protobuf.RequesterType
import com.sabre.seats.common.protobuf.ClientInfo
import com.sabre.seats.common.protobuf.SeatmapViewType
import com.sabre.seats.common.protobuf.SupplierType
import io.grpc.stub.StreamObserver
import spock.lang.Specification

import java.time.Instant

class MockAuthorizationServiceTest extends Specification{

    def classUnderTest = Spy(MockAuthorizationService.class)

    def "test getMockAuthorizeResponse"() {

        when:
        classUnderTest.authorizeRequest(getAuthorizationRequest("I0"), getResponseObserver())

        then:
        true
    }

    def "test getMockAuthorizeResponse for Not offloaded"() {

        when:
        classUnderTest.authorizeRequest(getAuthorizationRequest("MN"), getResponseObserver())

        then:
        true
    }

    def "test getMockAuthorizeResponse Failure"() {
        when:
        classUnderTest.authorizeRequest(getAuthorizationRequest("AA"), getResponseObserver())

        then:
        true
    }

    def "test getMockAuthorizeResponse Exception"() {
        when:
        classUnderTest.authorizeRequest(null, getResponseObserver())

        then:
        true
    }

    def getAuthorizationRequest(String airlineCode){

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        ClientInfo clientInfo=ClientInfo.newBuilder()
                .setRequester("I0")
                .setRequesterType(RequesterType.GDS)
                .setAgencyCode("1234")
                .setClientContext("sabre")
                .build()

        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode(airlineCode)
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-05-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        return AuthorizationRequest.newBuilder()
                .setRequestInfo(requestInfo)
                .setClientInfo(clientInfo)
                .setSegmentInfo(segmentInfo)
                .build()

    }

    def getResponseObserver() {
        return new StreamObserver<AuthorizationResponse>() {

            @Override
            void onNext(AuthorizationResponse authorizationResponse) {
                System.out.println("authorizationResponse response " + authorizationResponse.toString())
            }


            @Override
            void onError(Throwable throwable) {
            }

            @Override
            void onCompleted() {
            }
        }
    }

    private Timestamp setTime(){
        Instant instant = Instant.now();
        return Timestamp.newBuilder()
                .setSeconds(instant.getEpochSecond())
                .setNanos(instant.getNano())
                .build();
    }
}

