package com.sabre.seats.seatmap.orchestrationsvc.webservice.converter

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.databind.SerializerProvider
import spock.lang.Specification

import java.time.Instant

class JsonInstantDateTimeSerializerTest extends Specification{

    def jsonGenerator=Mock(JsonGenerator.class)
    def serializerProvider = Mock(SerializerProvider.class)

    def jsonInstantDateTimeSerializer = Spy(JsonInstantDateTimeSerializer.class)

    def "test"(){
        when:
        jsonInstantDateTimeSerializer.serialize(Instant.now(),jsonGenerator,serializerProvider)

        then:
        true
    }
}
