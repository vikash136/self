package com.sabre.seats.seatmap.orchestrationsvc.webservice.config

import spock.lang.Specification

class KubernetesClientConfigTest extends Specification {
    def KubernetesClientConfig = new KubernetesClientConfig()

    def "KubernetesClient"() {
        when:
        def kubernetesClient = KubernetesClientConfig.kubernetesClient()

        then:
        kubernetesClient.getConfiguration().getServer() != null
        kubernetesClient.getConfiguration().getNamespace() != null
    }

}
