package com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request

import com.sabre.seats.common.protobuf.PaxSegmentInfo
import com.sabre.seats.common.protobuf.ResponseStatus
import com.sabre.seats.common.protobuf.SegmentInfo
import com.sabre.seats.common.protobuf.SegmentResponse
import com.sabre.seats.common.protobuf.SupplierType
import com.sabre.seats.connectivity.protobuf.ConnectivityConfiguration
import spock.lang.Specification
import com.sabre.seats.common.protobuf.Supplier;

class FlightItemReqResContextTest extends Specification {

    def "test"(){
        given:
        FlightItemReqResContext flightItemReqResContext=new FlightItemReqResContext()

        when:

        SegmentInfo segmentInfo= SegmentInfo.newBuilder().setSupplierType(SupplierType.AIR).build()
        flightItemReqResContext.setSegmentInfo(segmentInfo)
        flightItemReqResContext.setAuthorizationResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setSupplier(Supplier.newBuilder().setAirlineCode("I0").build())
        flightItemReqResContext.setConnectivityResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setConnectivityConfiguration(ConnectivityConfiguration.newBuilder().build())
        flightItemReqResContext.setTransformSupplierRequestStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setSupplierRequestFromTransformer("test")
        flightItemReqResContext.setSupplierResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setSeatmapResponseFromSupplier("test")
        flightItemReqResContext.setTransformSupplierResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setViewResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setSegmentResponse(SegmentResponse.newBuilder().build())

        then:
        flightItemReqResContext.getSegmentInfo()!=null
        flightItemReqResContext.getAuthorizationResponseStatus()==ResponseStatus.SUCCESS
        flightItemReqResContext.getSupplier()!=null
        flightItemReqResContext.getConnectivityResponseStatus()==ResponseStatus.SUCCESS
        flightItemReqResContext.getConnectivityConfiguration()!=null
        flightItemReqResContext.getTransformSupplierRequestStatus()==ResponseStatus.SUCCESS
        flightItemReqResContext.getSupplierRequestFromTransformer()=="test"
        flightItemReqResContext.getSupplierResponseStatus()==ResponseStatus.SUCCESS
        flightItemReqResContext.getSeatmapResponseFromSupplier()=="test"
        flightItemReqResContext.getTransformSupplierResponseStatus()==ResponseStatus.SUCCESS
        flightItemReqResContext.getViewResponseStatus()==ResponseStatus.SUCCESS
        flightItemReqResContext.getSegmentResponse()!=null
        flightItemReqResContext.toString()!=null
    }
}
