package com.sabre.seats.seatmap.orchestrationsvc.webservice.model

import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.Payload
import spock.lang.Specification

class PayloadTest extends Specification{

    def TEST="test"

    def "test"(){
        given:
        def payload=new Payload();
        when:
        payload.setAgencyName(TEST)
        payload.setAgentSign(TEST)
        payload.setAud(TEST)
        payload.setCountryCode(TEST)
        payload.setDefaultCurrency(TEST)
        payload.setDomain(TEST)
        payload.setDutyCodes(Arrays.asList(TEST))
        payload.setExp(TEST)
        payload.setGroup(TEST)
        payload.setHomeCity(TEST)
        payload.setUid(TEST)
        payload.setSubjectTokenType(TEST)
        payload.setScp(Arrays.asList(TEST))
        payload.setNbf(TEST)
        payload.setKeywords(Arrays.asList(TEST))
        payload.setJti(TEST)
        payload.setIss(TEST)
        payload.setIataNumber(TEST)
        payload.setSubjectToken(TEST)
        payload.setIat(TEST)
        payload.setSub(TEST)
        payload.setHomePrimeHost(TEST)

        then:
        payload.toString()!=null
        payload.getAgencyName()==TEST
        payload.getAgentSign()==TEST
        payload.getAud()==TEST
        payload.getCountryCode()==TEST
        payload.getDefaultCurrency()==TEST
        payload.getDomain()==TEST
        payload.getDutyCodes().get(0)==TEST
        payload.getExp()==TEST
        payload.getGroup()==TEST
        payload.getHomeCity()==TEST
        payload.getUid()==TEST
        payload.getSubjectTokenType()==TEST
        payload.getScp().get(0)==TEST
        payload.getNbf()==TEST
        payload.getKeywords().get(0)==TEST
        payload.getJti()==TEST
        payload.getIss()==TEST
        payload.getIataNumber()==TEST
        payload.getSubjectToken()==TEST
        payload.getIat()==TEST
        payload.getSub()==TEST
        payload.getHomePrimeHost()==TEST
    }
}
