package com.sabre.seats.seatmap.orchestrationsvc.webservice.config

import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class ViewServiceConfigTest extends Specification{

   def viewServiceConfig = new ViewServiceConfig()

    def setup() {
        ReflectionTestUtils.setField(viewServiceConfig, "viewServiceUrl", "test-seats-transformation-service.seats-edge-cluster.svc.cluster.local")
        ReflectionTestUtils.setField(viewServiceConfig, "viewServicePort", 8090)
        ReflectionTestUtils.setField(viewServiceConfig, "keepAliveTime", 30000)
    }

    def "test"(){
        when:
        def channel=viewServiceConfig.getViewServiceManagedChannel()
        then:
        channel!=null

    }
}
