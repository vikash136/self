package com.sabre.seats.seatmap.orchestrationsvc.healthcheck.utility

import spock.lang.Specification

class OptionalHealthCheckUtilTest extends Specification {

    def classUnderTest = new OptionalHealthCheckUtil()

    def "Test getter and setter"(){
        given:
        Map<String, String> optionalHealthCheckMap = new HashMap<>()
        optionalHealthCheckMap.put("test","test")
        when:
        classUnderTest.setOptionalHealthCheckMap(optionalHealthCheckMap)
        def res = classUnderTest.getOptionalHealthCheckMap()
        then:
        res == optionalHealthCheckMap
    }
}
