package com.sabre.seats.seatmap.orchestrationsvc.webservice.utility

import com.sabre.seats.seatmap.orchestrationsvc.healthcheck.store.ServiceHealthCheckStore
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.ServiceTimeoutEnum
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.AuthorizationService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.ConnectivityService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TransformerAirSeatMapRQToAuthorizationService
import com.sabre.seats.seatmap.orchestrationsvc.webservice.service.TransformerConnectivityToSupplierService
import io.micrometer.core.instrument.simple.SimpleMeterRegistry
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.util.concurrent.atomic.AtomicInteger

class ServiceTimeoutUtilTest extends Specification {

    def classUnderTest = new ServiceTimeoutUtil()
    def serviceHealthCheckStore = Mock(ServiceHealthCheckStore.class)
    def meterRegistry = new SimpleMeterRegistry();
    def airSeatMapRQToAuthorizationService = Mock(TransformerAirSeatMapRQToAuthorizationService.class)
    def authorizationService = Mock(AuthorizationService.class)
    def connectivityService = Mock(ConnectivityService.class)
    def connectivityToCoreTransformerService = Mock(TransformerConnectivityToSupplierService.class)

    def setup() {
        ReflectionTestUtils.setField(classUnderTest, "serviceHealthCheckStore", serviceHealthCheckStore)
        ReflectionTestUtils.setField(classUnderTest, "serviceRetryCount", 3)
        ReflectionTestUtils.setField(classUnderTest, "meterRegistry", meterRegistry)
        ReflectionTestUtils.setField(classUnderTest, "airSeatMapRQToAuthorizationService", airSeatMapRQToAuthorizationService)
        ReflectionTestUtils.setField(classUnderTest, "connectivityService", connectivityService)
        ReflectionTestUtils.setField(classUnderTest, "authorizationService", authorizationService)
        ReflectionTestUtils.setField(classUnderTest, "connectivityToCoreTransformerService", connectivityToCoreTransformerService)
    }

    def "Test Authorization time out"(){
        when:
        classUnderTest.setServiceDown("authorizationService")
        then:
        1 * serviceHealthCheckStore.getRetryCount(_) >>  new AtomicInteger(0)
    }

    def "Test Transformer time out"(){
        when:
        classUnderTest.setServiceDown("transformerService")
        then:
        1 * serviceHealthCheckStore.getRetryCount(_) >>  new AtomicInteger(0)
    }

    def "Test Authorization service down"(){
        when:
        classUnderTest.setServiceDown("authorizationService")
        then:
        1 * serviceHealthCheckStore.getRetryCount(_) >>  new AtomicInteger(2)
        1 * serviceHealthCheckStore.getDynamicHealthCheckMap() >> getDynamicHealthCheckMap()
    }

    def "Test transformer service down"(){
        when:
        classUnderTest.setServiceDown("transformerService")
        then:
        1 * serviceHealthCheckStore.getRetryCount(_) >>  new AtomicInteger(2)
        1 * serviceHealthCheckStore.getDynamicHealthCheckMap() >> getDynamicHealthCheckMap()
    }

    def "Test setServiceTimeout "(){
        when:
        classUnderTest.setServiceTimeout(ServiceTimeoutEnum.CONNECTIVITY, "1000")
        then:
        1 * connectivityService.setConnectivityServiceCallTimeout(_)

        when:
        classUnderTest.setServiceTimeout(ServiceTimeoutEnum.AUTHORIZATION, "1000")
        then:
        1 * authorizationService.setAuthorizationServiceCallTimeout(_)

        when:
        classUnderTest.setServiceTimeout(ServiceTimeoutEnum.AUTH_TRANSFORMATION, "1000")
        then:
        1 * airSeatMapRQToAuthorizationService.setTransformationServiceCallTimeout(_)

        when:
        classUnderTest.setServiceTimeout(ServiceTimeoutEnum.CONN_TRANSFORMATION, "1000")
        then:
        1 * connectivityToCoreTransformerService.setTransformationServiceCallTimeout(_)

        when:
        classUnderTest.setServiceTimeout(null, "1000")
        then:
        0 * connectivityToCoreTransformerService.setTransformationServiceCallTimeout(_)
        0 * airSeatMapRQToAuthorizationService.setTransformationServiceCallTimeout(_)
        0 * authorizationService.setAuthorizationServiceCallTimeout(_)
    }

    def "Test getServiceTimeout "(){
        when:
        def res1=classUnderTest.getServiceTimeout(ServiceTimeoutEnum.CONNECTIVITY)
        then:
        1 * connectivityService.getConnectivityServiceCallTimeout() >> 1000
        res1==1000

        when:
        def res2=classUnderTest.getServiceTimeout(ServiceTimeoutEnum.AUTHORIZATION)
        then:
        1 * authorizationService.getAuthorizationServiceCallTimeout() >> 2000
        res2==2000

        when:
        def res3=classUnderTest.getServiceTimeout(ServiceTimeoutEnum.AUTH_TRANSFORMATION)
        then:
        1 * airSeatMapRQToAuthorizationService.getTransformationServiceCallTimeout() >> 3000
        res3==3000

        when:
        def res4=classUnderTest.getServiceTimeout(ServiceTimeoutEnum.CONN_TRANSFORMATION)
        then:
        1 * connectivityToCoreTransformerService.getTransformationServiceCallTimeout() >> 4000
        res4==4000

        when:
        def res5=classUnderTest.getServiceTimeout(null)
        then:
        null==res5
        0 * connectivityToCoreTransformerService.getTransformationServiceCallTimeout()
        0 * airSeatMapRQToAuthorizationService.getTransformationServiceCallTimeout(_)
        0 * authorizationService.getAuthorizationServiceCallTimeout(_)
    }

    def getDynamicHealthCheckMap() {
        Map<String, String> dynamicHealthCheckMap = new HashMap<>()
        dynamicHealthCheckMap.put("authorizationService", "DOWN")
        dynamicHealthCheckMap.put("transformerService", "DOWN")
        return dynamicHealthCheckMap
    }
}
