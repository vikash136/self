package com.sabre.seats.seatmap.orchestrationsvc.webservice.controller

import com.fasterxml.jackson.databind.ObjectMapper
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.response.AirSeatMapResponse
import org.apache.http.HttpStatus
import org.checkerframework.checker.units.qual.A
import org.spockframework.runtime.condition.ObjectRendererService
import org.springframework.mock.web.MockHttpServletRequest
import spock.lang.Specification

import javax.servlet.http.HttpServletRequest
import java.net.http.HttpClient

class SeatMapRetrieveApiControllerTest extends Specification {

    def objectMapper= (new ObjectMapper())
    def request=Mock(HttpServletRequest.class)
    def controller =new SeatMapRetrieveApiController(objectMapper,request)
    def securityToken="eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9"

    def "test getSeatMapRetrieve"(){

        when:
        def ref=controller.seatMapRetrieveVersionSeatsSeatmapPost("123",securityToken,"123","12345",new AirSeatMapRequest())

        then:
        1 * request.getHeader("Accept") >> "application/json"
        Objects.nonNull(ref)
    }
    def "test getSeatMapRetrieve1"(){

        when:
        def ref=controller.seatMapRetrieveVersionSeatsSeatmapPost("123",securityToken,"123","12345",new AirSeatMapRequest())

        then:
        Objects.nonNull(ref)
    }

}
