
package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.converter.FlightItemReqResContextConverter
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.common.protobuf.*
import com.sabre.seats.error.protobuf.Description
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.error.protobuf.MessageCode
import com.sabre.seats.transformation.protobuf.InputRequest
import com.sabre.seats.transformation.protobuf.SeatMapOutputReqResponse
import com.sabre.seats.transformation.protobuf.TransformReqResponse
import io.grpc.ManagedChannelBuilder
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class TransformerAirSeatMapRQToAuthorizationServiceTest extends Specification {
    def classUnderTest = Spy(TransformerAirSeatMapRQToAuthorizationService)
    def transformPosReqToProtoChannel = ManagedChannelBuilder.forTarget("localhost").usePlaintext().build()
    def serviceTimeoutUtil = Mock(ServiceTimeoutUtil.class)
    def errorMessageListBuilder = Mock(ErrorMessageListBuilder.class)
    def flightItemReqResContextConverter=Mock(FlightItemReqResContextConverter.class)

    def setup() {
        ReflectionTestUtils.setField(classUnderTest, "transformationServiceCallTimeout", 5000)
        ReflectionTestUtils.setField(classUnderTest, "serviceTimeoutUtil", serviceTimeoutUtil)
        ReflectionTestUtils.setField(classUnderTest, "transformPosReqToProtoChannel", transformPosReqToProtoChannel)
        ReflectionTestUtils.setField(classUnderTest, "transformationServiceVersion", "1")
        ReflectionTestUtils.setField(classUnderTest, "errorMessageListBuilder", errorMessageListBuilder)
        ReflectionTestUtils.setField(classUnderTest, "flightItemReqResContextConverter", flightItemReqResContextConverter)
    }

    def "send processRequest"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processRequest(reqRespContext)

        then:
        1 * classUnderTest.getTransformationResponse(_,_) >> getSuccessTransformationResponse()
        1 * flightItemReqResContextConverter.createFlightItemContextMap(_,_)
        reqRespContext.getTransformPosRequestToProtoStatus()==ResponseStatus.SUCCESS
        reqRespContext.getRequestInfo()!=null
    }

    def "send processRequest - connection time out"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processRequest(reqRespContext)

        then:
        1 * serviceTimeoutUtil.setServiceDown(_)
        0 * flightItemReqResContextConverter.createFlightItemContextMap(_,_)
        thrown(ServiceTimeOutException.class)
    }

    def "send processRequest - Unknown exception"() {
        given:
        def reqRespContext=getRequestResponseContext("I0")

        when:
        classUnderTest.processRequest(reqRespContext)

        then:
        1 * classUnderTest.getTransformationResponse(_,_) >> {throw new Exception("test error")}
        1 * errorMessageListBuilder.getTransformerExceptionResponse(_) >> getFailedTransformationResponse()
        0 * flightItemReqResContextConverter.createFlightItemContextMap(_,_)
        reqRespContext.getTransformPosRequestToProtoStatus()==ResponseStatus.FAILED
        reqRespContext.getRequestInfo()!=null
    }

    def "send processRequest - channel-id is empty "() {
        given:
        def reqRespContext=getRequestResponseContext("AA")

        when:
        classUnderTest.processRequest(reqRespContext)

        then:
        0 * classUnderTest.getTransformationResponse(_,_) >> getSuccessTransformationResponse()
        0 * flightItemReqResContextConverter.createFlightItemContextMap(_,_)
        reqRespContext.getTransformPosRequestToProtoStatus()==null
    }

    def "send processRequest - client info is null"() {
        given:
        def reqRespContext=getRequestResponseContext("AA")
        reqRespContext.setClientInfo(null)

        when:
        classUnderTest.processRequest(reqRespContext)

        then:
        0 * classUnderTest.getTransformationResponse(_,_) >> getSuccessTransformationResponse()
        0 * flightItemReqResContextConverter.createFlightItemContextMap(_,_)
        reqRespContext.getTransformPosRequestToProtoStatus()==null
    }

    def "send setViewServiceCallTimeout"() {
        when:
        classUnderTest.setTransformationServiceCallTimeout(1000)
        def res=classUnderTest.getTransformationServiceCallTimeout()
        then:
        res==1000
    }

    def getRequestResponseContext(String airlineCode){

        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setAirlineCode(airlineCode)
        flightDetails.setFlightNumber("123")
        flightDetails.setScheduledDepartureDate(LocalDate.parse("2020-08-20").toString())
        flightDetails.setReservationBookingDesignator("Y")
        flightDetails.setDepartureAirportCode("AUH")
        flightDetails.setArrivalAirportCode("DFW")

        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()
        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.RESERVATION.toString())
        getAirSeatMapRQ.setFlightInfo(List.of(flightDetails))

        ClientInfo clientInfo= ClientInfo.newBuilder()
                .setAgencyCode("AC")
                .setRequester(airlineCode=="I0"?"CID":"")
                .setRequesterType(RequesterType.GDS)
                .setClientContext("CC")
                .addEprKeywords("EPR1").addEprKeywords("EPR2")
                .build()

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setRequestVersion("1")
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)
        requestResponseContext.setClientInfo(clientInfo)

        return requestResponseContext
    }

    def getSuccessTransformationResponse(){

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode("I0")
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()

        PaxSegmentInfo paxSegmentInfo= PaxSegmentInfo.newBuilder().setSegmentInfo(segmentInfo).build()

        SeatmapRequest seatmapRequest=SeatmapRequest.newBuilder()
                .addPaxSegmentInfo(paxSegmentInfo)
                .setRequestInfo(requestInfo)
                .build()

        InputRequest outputResponse = InputRequest.newBuilder()
                .setSeatMapRequest(seatmapRequest)
                .build()

        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getSuccessResponse())
                .setOutputResponse(outputResponse)
                .build()

        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build()
    }

    def getFailedTransformationResponse(){
        SeatMapOutputReqResponse seatMapOutputReqResponse = SeatMapOutputReqResponse.newBuilder()
                .setResponseInfo(getFailedResponse())
                .build();

        return TransformReqResponse.newBuilder()
                .setSeatMapOutputReqResponse(seatMapOutputReqResponse)
                .build();
    }

    def getSuccessResponse(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.SUCCESS)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .build()
    }

    def getFailedResponse(){
        return ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setReceivedTimestamp(Instant.now().toString())
                .setResponseTimestamp(Instant.now().toString())
                .addErrorMessages(getProtoErrorMessage())
                .build()
    }

    def getProtoErrorMessage(){

        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("123")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("APPLICATION")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("test")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }

}

