package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.ErrorMessageListBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.exception.ServiceTimeOutException
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.utility.ServiceTimeoutUtil
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.common.protobuf.*
import com.sabre.seats.connectivity.protobuf.ConnectivityConfiguration
import com.sabre.seats.connectivity.protobuf.ConnectivityConfigurationResponse
import com.sabre.seats.error.protobuf.Description
import com.sabre.seats.error.protobuf.ErrorMessage
import com.sabre.seats.error.protobuf.MessageCode
import io.grpc.ManagedChannelBuilder
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class ConnectivityServiceTest extends Specification {

    def classUnderTest = Spy(ConnectivityService)
    ErrorMessageListBuilder errorMessageListBuilder = Mock(ErrorMessageListBuilder.class)
    def serviceTimeoutUtil = Mock(ServiceTimeoutUtil.class)
    def connectivityServiceChannel = ManagedChannelBuilder.forTarget("localhost").usePlaintext().build()

    def setup() {
        ReflectionTestUtils.setField(classUnderTest, "errorMessageListBuilder", errorMessageListBuilder)
        ReflectionTestUtils.setField(classUnderTest, "connectivityServiceCallTimeout", 5000)
        ReflectionTestUtils.setField(classUnderTest, "connectivityServiceChannel", connectivityServiceChannel)
        ReflectionTestUtils.setField(classUnderTest, "serviceTimeoutUtil", serviceTimeoutUtil)
        ReflectionTestUtils.setField(classUnderTest, "connectivityServiceVersion", "1")
    }


    def "send processFlightItem"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * classUnderTest.getConnectivityResponse(_,_) >> getSuccessResponse(serviceRequestResponseContext)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityResponseStatus()==ResponseStatus.SUCCESS
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityConfiguration()!=null
    }

    def "send processFlightItem - AuthResp is failed"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(ResponseStatus.FAILED)
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)
        then:
        0 * classUnderTest.getConnectivityResponse(_,_)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityResponseStatus()==null
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityConfiguration()==null

        when:
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(ResponseStatus.NOT_OFFLOADED)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).setSupplier(null)
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)
        then:
        0 * classUnderTest.getConnectivityResponse(_,_)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityResponseStatus()==null
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityConfiguration()==null

        when:
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).setAuthorizationResponseStatus(null)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).setSupplier(null)
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)
        then:
        0 * classUnderTest.getConnectivityResponse(_,_)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityResponseStatus()==null
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityConfiguration()==null
    }

    def "send processFlightItem - connection timeout exception"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * errorMessageListBuilder.getConnectivityExceptionResponse (_) >> getConnectivityExceptionResponse()
        1 * serviceTimeoutUtil.setServiceDown(_)
        thrown(ServiceTimeOutException.class)
    }

    def "send processFlightItem -unknown exception"() {
        given:
        def serviceRequestResponseContext = getRequestResponseContext("I0")

        when:
        classUnderTest.processFlightItem(serviceRequestResponseContext, 1)

        then:
        1 * classUnderTest.getConnectivityResponse(_,_) >> {throw new Exception("test-error")}
        1 * errorMessageListBuilder.getConnectivityExceptionResponse (_) >> getConnectivityExceptionResponse()
        0 * serviceTimeoutUtil.setServiceDown(_)
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityResponseStatus()==ResponseStatus.FAILED
        serviceRequestResponseContext.getFlightItemReqResContextMap().get(1).getConnectivityConfiguration()==null
    }

    def "send setConnectivityServiceCallTimeout"() {
        when:
        classUnderTest.setConnectivityServiceCallTimeout(1000)
        def res=classUnderTest.getConnectivityServiceCallTimeout()
        then:
        res==1000
    }

    def getRequestResponseContext(String airlineCode){

        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setAirlineCode(airlineCode)
        flightDetails.setFlightNumber("123")
        flightDetails.setScheduledDepartureDate(LocalDate.parse("2020-08-20").toString())
        flightDetails.setReservationBookingDesignator("Y")
        flightDetails.setDepartureAirportCode("AUH")
        flightDetails.setArrivalAirportCode("DFW")

        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()
        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.RESERVATION.toString())
        getAirSeatMapRQ.setFlightInfo(List.of(flightDetails))

        ClientInfo clientInfo= ClientInfo.newBuilder()
                .setAgencyCode("AC")
                .setRequester("CID")
                .setRequesterType(RequesterType.GDS)
                .setClientContext("CC")
                .addEprKeywords("EPR1").addEprKeywords("EPR2")
                .build()

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setRequestVersion("1")
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)
        requestResponseContext.setClientInfo(clientInfo)
        requestResponseContext.setRequestInfo(requestInfo)
        requestResponseContext.getFlightItemReqResContextMap().put(1,getFlightItemReqResContext(airlineCode))

        return requestResponseContext
    }

    def getFlightItemReqResContext(String airlineCode){
        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode(airlineCode)
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()


        FlightItemReqResContext flightItemReqResContext = new FlightItemReqResContext()
        flightItemReqResContext.setSegmentInfo(segmentInfo)
        flightItemReqResContext.setAuthorizationResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setSupplier(Supplier.newBuilder().build())

        return flightItemReqResContext
    }

    def getSuccessResponse(WebServiceRequestResponseContext requestResponseContext){
        FlightItemReqResContext flightItemReqResContext=requestResponseContext.getFlightItemReqResContextMap().get(1)

        ResponseInfo responseInfoSuccess=ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.SUCCESS)
                .setReceivedTimestamp(requestResponseContext.getRequestInfo().getTimestamp())
                .setResponseTimestamp(Instant.now().toString())
                .build()

        ConnectivityConfiguration connectivityConfiguration = ConnectivityConfiguration.newBuilder()
                .setApiVersion("1")
                .setMessageFormat(MessageFormat.JSON)
                .setConnectivityType("Mock Connection")
                .setConnectivityDestination("http://localhost:8080/v1/seatscore/seatmap")
                .build()

        return ConnectivityConfigurationResponse.newBuilder()
                .setSeatAction(SeatAction.SEAT_VIEW)
                .setSupplier(flightItemReqResContext.getSegmentInfo().getFlightInfo().getAirlineCode())
                .setSupplierType(flightItemReqResContext.getSegmentInfo().getSupplierType())
                .setResponseInfo(responseInfoSuccess)
                .setConnectivityConfiguration(connectivityConfiguration)
                .build()
    }

    def getConnectivityExceptionResponse(){

        ResponseInfo responseInfo=ResponseInfo.newBuilder()
                .setResponseStatus(ResponseStatus.FAILED)
                .setResponseTimestamp(Instant.now().toString())
                .addErrorMessages(getProtoErrorMessage()).build()

        return ConnectivityConfigurationResponse.newBuilder()
                .setResponseInfo(responseInfo)
                .build();
    }

    def getProtoErrorMessage(){

        List<MessageCode> messageCodeList = new ArrayList<>()
        MessageCode messageCode =  MessageCode.newBuilder()
                .setCode("123")
                .setCodeContext("IATAErrorCode").build()
        messageCodeList.add(messageCode)

        ErrorMessage errorMessage = ErrorMessage.newBuilder()
                .setType("APPLICATION")
                .setDescription(Description.newBuilder()
                        .setLang("UTF-11111")
                        .setMessage("test")
                        .build())
                .addAllErrorCode(messageCodeList)
                .build()

        return errorMessage
    }
}
