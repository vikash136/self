package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.seats.seatmap.orchestrationsvc.webservice.builder.AirSeatMapResponseBuilder
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.FlightItemReqResContext
import com.sabre.seats.seatmap.orchestrationsvc.webservice.model.request.WebServiceRequestResponseContext
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.AirSeatMapRequest
import com.sabre.seats.air.seatmap.web.model.flightseatmap.v1.FlightCriteriaRequest
import com.sabre.seats.common.protobuf.*
import spock.lang.Specification

import java.time.Instant
import java.time.LocalDate

class TestGrpcServiceTest extends Specification {

    def jwtDecoderService= Mock(JWTDecoderService.class)
    def transformerAirSeatMapRQToAuthorizationService = Mock(TransformerAirSeatMapRQToAuthorizationService.class)
    def authorizationService=Mock(AuthorizationService.class)
    def connectivityToCoreTransformerService=Mock(TransformerConnectivityToSupplierService.class)
    def connectivityService = Mock(ConnectivityService.class)
    def seatmapSupplierService =Mock(SeatmapSupplierService.class)
    def transformerCoreSeatMapToViewService=Mock(TransformerSupplierToViewService.class)
    def viewService=Mock(ViewService.class)
    def transformerResponseToPOSService =Mock(TransformerResponseToPOSService.class)
    def airSeatMapResponseBuilder = Mock(AirSeatMapResponseBuilder.class)
    def classUnderTest = new TestGrpcService()

    def setup() {
        classUnderTest.jwtDecoderService=jwtDecoderService
        classUnderTest.transformerAirSeatMapRQToAuthorizationService=transformerAirSeatMapRQToAuthorizationService
        classUnderTest.authorizationService=authorizationService
        classUnderTest.connectivityService=connectivityService
        classUnderTest.transformerConnectivityToSupplierService=connectivityToCoreTransformerService
        classUnderTest.seatmapSupplierService=seatmapSupplierService
        classUnderTest.transformerSupplierToViewService=transformerCoreSeatMapToViewService
        classUnderTest.viewService=viewService
        classUnderTest.transformerResponseToPOSService=transformerResponseToPOSService
        classUnderTest.airSeatMapResponseBuilder=airSeatMapResponseBuilder
    }

    def "test"(){
        given:
        def reqRespContext=getRequestResponseContext("I0")
        when:
        def res=classUnderTest.testGrpcService(reqRespContext)
        then:
        1 * jwtDecoderService.processRequest (_)
        1 * transformerAirSeatMapRQToAuthorizationService.processRequest(_)
        1 * authorizationService.processFlightItem(_, _)
        1 * connectivityService.processFlightItem(_, _)
        1 * connectivityToCoreTransformerService.processFlightItem(_, _)
        1 * seatmapSupplierService.processFlightItem(_, _)
        1 * transformerCoreSeatMapToViewService.processFlightItem(_, _)
        1 * viewService.processFlightItem(_, _)
        1 * transformerResponseToPOSService.processRequest(_)
        1 * airSeatMapResponseBuilder.processRequest(_)
        res!=null
    }

    def "test1"(){
        given:
        def reqRespContext=getRequestResponseContext("MN")
        when:
        def res=classUnderTest.testGrpcService(reqRespContext)
        then:
        1 * jwtDecoderService.processRequest (_)
        1 * transformerAirSeatMapRQToAuthorizationService.processRequest(_)
        1 * authorizationService.processFlightItem(_, _)
        1 * connectivityService.processFlightItem(_, _)
        1 * connectivityToCoreTransformerService.processFlightItem(_, _)
        1 * seatmapSupplierService.processFlightItem(_, _)
        1 * transformerCoreSeatMapToViewService.processFlightItem(_, _)
        1 * viewService.processFlightItem(_, _)
        1 * transformerResponseToPOSService.processRequest(_)
        1 * airSeatMapResponseBuilder.processRequest(_)
        res!=null
    }

    def "test Exception"(){
        when:
        def res=classUnderTest.testGrpcService(getRequestResponseContext("I0"))
        then:
        1 * jwtDecoderService.processRequest (_) >> {throw new Exception("test")}
        0 * transformerAirSeatMapRQToAuthorizationService.processRequest(_)
        0 * authorizationService.processFlightItem(_, _)
        res!=null
    }

    def getRequestResponseContext(String airlineCode){

        FlightCriteriaRequest flightDetails = new FlightCriteriaRequest()
        flightDetails.setAirlineCode(airlineCode)
        flightDetails.setFlightNumber("123")
        flightDetails.setScheduledDepartureDate(LocalDate.parse("2020-08-20").toString())
        flightDetails.setReservationBookingDesignator("Y")
        flightDetails.setDepartureAirportCode("AUH")
        flightDetails.setArrivalAirportCode("DFW")

        AirSeatMapRequest getAirSeatMapRQ = new AirSeatMapRequest()
        getAirSeatMapRQ.setRequestDateTime(Instant.now().toString())
        getAirSeatMapRQ.setSeatMapViewType(SeatmapViewType.RESERVATION.toString())
        getAirSeatMapRQ.setFlightInfo(List.of(flightDetails))

        ClientInfo clientInfo= ClientInfo.newBuilder()
                .setAgencyCode("AC")
                .setRequester("CID")
                .setRequesterType(RequesterType.GDS)
                .setClientContext("CC")
                .addEprKeywords("EPR1").addEprKeywords("EPR2")
                .build()

        RequestInfo requestInfo= RequestInfo.newBuilder()
                .setCorrelationId("12345")
                .setTransactionId("12345")
                .setTimestamp(Instant.now().toString())
                .setVersion("1").build()

        WebServiceRequestResponseContext requestResponseContext = new WebServiceRequestResponseContext()
        requestResponseContext.setRequestVersion("1")
        requestResponseContext.setAirSeatMapRQ(getAirSeatMapRQ)
        requestResponseContext.setClientInfo(clientInfo)
        requestResponseContext.setRequestInfo(requestInfo)
        requestResponseContext.getFlightItemReqResContextMap().put(1,getFlightItemReqResContext(airlineCode))

        return requestResponseContext
    }

    def getFlightItemReqResContext(String airlineCode){
        FlightInfo flightInfo=FlightInfo.newBuilder()
                .setAirlineCode(airlineCode)
                .setDepartureAirportCode("SAT")
                .setArrivalAirportCode("DFW")
                .setFlightNumber("326")
                .setScheduledDepartureDate("2021-04-01")
                .build()

        SegmentInfo segmentInfo= SegmentInfo.newBuilder()
                .setSegmentId(1)
                .setSupplierType(SupplierType.AIR)
                .setSeatmapViewType(SeatmapViewType.RESERVATION)
                .setFlightInfo(flightInfo)
                .build()


        FlightItemReqResContext flightItemReqResContext = new FlightItemReqResContext()
        flightItemReqResContext.setSegmentInfo(segmentInfo)
        flightItemReqResContext.setAuthorizationResponseStatus(ResponseStatus.SUCCESS)
        flightItemReqResContext.setSupplier(Supplier.newBuilder().build())

        if("MN".equalsIgnoreCase(airlineCode)){
            flightItemReqResContext.setSegmentResponse(SegmentResponse.newBuilder().setResponseInfo(ResponseInfo.newBuilder().build()).build())
        } else{
            flightItemReqResContext.setSeatmapResponseFromSupplier("test")
        }
        return flightItemReqResContext
    }

}
