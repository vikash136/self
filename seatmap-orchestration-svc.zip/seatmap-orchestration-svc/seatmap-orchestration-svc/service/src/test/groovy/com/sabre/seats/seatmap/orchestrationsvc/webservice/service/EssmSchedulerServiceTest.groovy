package com.sabre.seats.seatmap.orchestrationsvc.webservice.service

import com.sabre.checkin.jwtdecoder.scheduler.ESSMScheduler
import spock.lang.Specification

class EssmSchedulerServiceTest extends Specification {

    def classUnderTest = new EssmSchedulerService()
    ESSMScheduler essmScheduler = Mock()

    def setup() {
        classUnderTest.essmScheduler = essmScheduler
        classUnderTest.appId = "SEATS:SEATMAP_ORCHESTRATION_SVC"
        classUnderTest.essmBaseUrl = "https://essmws.int.sabre.com/"
    }

    def "test schedule"() {
        given:
        def jwtDecoderRequest = classUnderTest.getJwtDecoderRequest()

        when:
        classUnderTest.schedule()

        then:
        1 * essmScheduler.schedule(jwtDecoderRequest)
    }

    def "test init"() {
        given:
        def jwtDecoderRequest = classUnderTest.getJwtDecoderRequest()

        when:
        classUnderTest.init()

        then:
        1 * essmScheduler.schedule(jwtDecoderRequest) >> true
    }

    def "test init for startup exception"() {
        given:
        def jwtDecoderRequest = classUnderTest.getJwtDecoderRequest()

        when:
        classUnderTest.init()

        then:
        1 * essmScheduler.schedule(jwtDecoderRequest) >> false
        thrown(Exception)
    }
}
