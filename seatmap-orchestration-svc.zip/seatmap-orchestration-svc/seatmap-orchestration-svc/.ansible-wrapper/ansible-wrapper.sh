#!/bin/bash

set -e

C="$(tput setaf 3)"
E="$(tput setaf 1)"
R="$(tput setaf 7)"

echo -e "${C}"

echo "  _   _  ____ ____    ____            __  __ "
echo " | \ | |/ ___|  _ \  |  _ \  _____   _\ \/ / "
echo " |  \| | |  _| |_) | | | | |/ _ \ \ / /\  /  "
echo " | |\  | |_| |  __/  | |_| |  __/\ V / /  \  "
echo " |_| \_|\____|_|     |____/ \___| \_/ /_/\_\ "

echo -e "${R}"

echo -e " e-mail:  ${C}ngp.devx@sabre.com${R}"
echo -e " JIRA:    ${C}http://ngp.sabre.com/request-support/${R}"
echo ""

function usage() {
    echo "Usage:"
    echo "  `basename "$0"` [OPTIONS]"
    echo "Options:"
    echo "  -y                  - do not ask for confirmation"
    echo "  -fb                 - force rebuild of deployment tooling in OpenShift"
    echo "  --app-config-dir    - a path to application deployment configuration directory"
    echo "  --app-version       - an application version to be deployed"
    echo "  --app-env           - a deployment environment"
    echo "  --help              - print usage"
    echo ""
}

while true;
do
  case "$1" in
    --help ) usage; exit 0;;
    * ) break ;;
  esac
done

echo
echo "............................................................."
echo -e "${C}Load configuration${R}"
echo "............................................................."
echo

CONFIG_DIR=
APPLICATION_VERSION=
APPLICATION_DEPLOYMENT_ENV=
SSH_KEY=

CONFIG_FILE="./ansible-wrapper.config"
if [[ ! -f $CONFIG_FILE ]]; then 
    echo -e "${E}ERROR!${R} There is no '$CONFIG_FILE' configuration file"
    exit 101
fi

. $CONFIG_FILE

PRE_APPROVED=false
BUILD_TOOLING=false

while true;
do
  case "$1" in
    -y ) PRE_APPROVED=true; shift 1 ;;
    -fb ) BUILD_TOOLING=true; shift 1 ;;
    --app-config-dir ) CONFIG_DIR="$2"; shift 2 ;;
    --app-version ) APPLICATION_VERSION="$2"; shift 2 ;;
    --app-env ) APPLICATION_DEPLOYMENT_ENV="$2"; shift 2 ;;
    -- ) shift; break ;;
    * ) break ;;
  esac
done

echo "Done"

echo
echo "............................................................."
echo -e "${C}Check configuration${R}"
echo "............................................................."
echo

if [[ ! -d $CONFIG_DIR ]]; then 
    echo -e "${E}ERROR!${R} There is no '$CONFIG_DIR' directory"
    exit 102
fi

if [[ ! -f $SSH_KEY ]]; then 
    echo -e "${E}ERROR!${R} There is no '$SSH_KEY' ssh key file"
    exit 103
fi

if [[ -z "${APPLICATION_VERSION}" ]]; then
    echo -e "${E}ERROR!${R} Missing application version"
    exit 104
fi

if [[ -z "${APPLICATION_DEPLOYMENT_ENV}" ]]; then
    echo -e "${E}ERROR!${R} Missing application deployment environment"
    exit 105
fi

echo "OK"

echo
echo "............................................................."
echo -e "${C}Checking OpenShift context${R}"
echo "............................................................."
echo

OPENSHIFT_USER=`oc whoami`
if [[ $OPENSHIFT_USER = "" ]]; then 
    echo -e "${E}ERROR!${R} You are not logged to OpenShift"
    exit 100
fi

OPENSHIFT_PROJECT=`oc project -q`
OPENSHIFT_TOKEN=`oc whoami -t`

echo "Done"

echo
echo "............................................................."
echo -e "Logged as:                     ${C}$OPENSHIFT_USER${R}"
echo -e "Current project:               ${C}$OPENSHIFT_PROJECT${R}"
echo -e "App deployment configuration:  ${C}$CONFIG_DIR${R}"
echo -e "App deployment environment:    ${C}$APPLICATION_DEPLOYMENT_ENV${R}"
echo -e "App version:                   ${C}$APPLICATION_VERSION${R}"
echo "............................................................."
echo

if [[ $PRE_APPROVED = true ]]; then
    echo "Deployment pre-approved"
    REPLY="y"
else
    echo "Would you like to continue with deployment?"
    read -p "Press 'y' if Yes: " -n 1 -r
    echo
fi

if [[ ! $REPLY =~ ^[y]$ ]]; then
    echo "Deployment terminated by the user"
    exit
fi

echo
echo "............................................................."
echo -e "${C}Building 'dev-deployment-ansible-wrapper' tooling${R}"
echo "............................................................."
echo

IMAGE_NAME='dev-deployment-ansible-wrapper'
IMAGE_VERSION='v2019.2.0'
IST_EXISTS=`oc get --ignore-not-found ImageStreamTag ${IMAGE_NAME}:${IMAGE_VERSION} -o name`

if [[ $IST_EXISTS = ""  ]] || [[ $BUILD_TOOLING = true ]]; then
    echo "Deleting old components"
    oc delete --ignore-not-found ImageStream ${IMAGE_NAME}

    echo "Importing base image: $IMAGE_NAME:$IMAGE_VERSION"
    oc import-image \
        ${IMAGE_NAME}:${IMAGE_VERSION} \
        --from=repository-us-west-2.teo.dev.ascint.sabrecirrus.com:9082/sabre/openshift/${IMAGE_NAME}:${IMAGE_VERSION} \
        --confirm
else
    echo "Tooling already exists. Nothing to do here..."
fi

echo
echo "............................................................."
echo -e "${C}Setting 'dev-deployment-job' job${R}"
echo "............................................................."
echo

JOB_NAME='dev-deployment-job'
JOB_DEFINITION='./dev-deployment-job/dev-deployment-job.yaml'

echo "Deleting old components"
oc delete --ignore-not-found Job ${JOB_NAME}

TIMEOUT=10
until [[ $(oc get pod -l job-name=${JOB_NAME} -o name) == "" ]];
do
    echo "Waiting for all previous job pods to be removed"
    sleep 30s
    TIMEOUT=$((TIMEOUT-1))
    if (( $TIMEOUT <= 0 )); then 
        echo -e "${E}ERROR!${R} Pods were not removed [3 Min]"
        exit 0
    fi
done

echo "Creating job: ${JOB_NAME}"
oc process -f ${JOB_DEFINITION} \
      -p NAMESPACE=${OPENSHIFT_PROJECT} \
      -p IMAGE_NAME=${IMAGE_NAME} \
      -p IMAGE_VERSION=${IMAGE_VERSION} \
      | oc apply -f -

POD_NAME=`oc get pod -l job-name=${JOB_NAME} -o name`

TIMEOUT=20
until [[ $(oc get ${POD_NAME} | grep 'Running\|Completed\|Error') != "" ]];
do
    echo "Waiting for the job ${POD_NAME} to start..."
    sleep 30s
    TIMEOUT=$((TIMEOUT-1))
    if (( $TIMEOUT <= 0 )); then 
        echo -e "${E}ERROR!${R} Pod did not strt within the timeout [6 Min]"
        exit 0
    fi
done

echo "Job started"

echo
echo "............................................................."
echo -e "${C}Inject deployment data to the job pod${R}"
echo "............................................................."
echo

oc rsync --no-perms=true \
    ${CONFIG_DIR} ${POD_NAME:4}:/home/jenkins/ansible-wrapper/

echo
echo "............................................................."
echo -e "${C}Trigger deployment${R}"
echo "............................................................."
echo

rm -rf .temp && mkdir .temp

echo "" > .temp/run-deployment.trigger

SSH_KEY_VALUE=`cat ${SSH_KEY} | base64 | tr -d '\n'`
echo "SSH_KEY_VALUE=${SSH_KEY_VALUE}" >> .temp/run-deployment.trigger
echo "OPENSHIFT_USER=${OPENSHIFT_USER}" >> .temp/run-deployment.trigger
echo "OPENSHIFT_TOKEN=${OPENSHIFT_TOKEN}" >> .temp/run-deployment.trigger
echo "OPENSHIFT_PROJECT=${OPENSHIFT_PROJECT}" >> .temp/run-deployment.trigger
echo "APPLICATION_VERSION=${APPLICATION_VERSION}" >> .temp/run-deployment.trigger
echo "APPLICATION_DEPLOYMENT_ENV=${APPLICATION_DEPLOYMENT_ENV}" >> .temp/run-deployment.trigger

cd .temp
oc rsync --no-perms=true \
    --exclude=* \
    --include=run-deployment.trigger \
    ./ ${POD_NAME:4}:/home/jenkins/ansible-wrapper/

cd .. && rm -rf .temp

echo
echo "............................................................."
echo -e "${C}Following logs of ${POD_NAME}${R}"
echo "............................................................."
echo

until [[ $(oc get ${POD_NAME} | grep 'Running') = "" ]];
do
    oc logs ${POD_NAME} --follow \
        1> >(sed "s/^/pod: [${C}*${POD_NAME: -6}${R}] > /") \
        2> >(sed "s/^/pod: [${C}*${POD_NAME: -6}${R}] > /" >&2) 
    sleep 30s
done

echo
echo "............................................................."
echo -e "${C}Done${R}"
echo "............................................................."
echo
