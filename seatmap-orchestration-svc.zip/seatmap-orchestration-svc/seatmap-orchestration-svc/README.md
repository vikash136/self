# seats-edge-cluster:seatmap-orchestration-svc

This project has been generated automatically by [NGP-Service-Initializer](https://proxy.git.sabre.com/projects/NGP-DE/repos/ngp-service-initializer/browse)

**_NOTE:_** This source code is compatible with CD pipeline version 3.0 hence Deploy your application with Armada with the following NGP dependency versions:

* CD pipeline version: 3.0

* Blue-Green-strategy com/sabre/ngp-cicd/blue-green version: 3.x.x

More information on configuration can be found [here](http://ngp.sabre.com/tech-docs/NGP-CICD/chunks/k8s/ocp_to_k8s_migration_guide.html#_strong_class_red_ngp_cd_application_deployment_configuration_strategy_changes_strong)

## Project structure

Within the project files you can find:

- Application files:
    * `service` - generic Java application
    * `acceptance-tests` - an independent Java project with acceptance tests. Project is run as one of CI pipeline steps.
    * pom.xml - parent pom file

- CICD configurations:
    * `configuration` - deployment configurations used during CI/CD pipelines execution.
    * `.jenkins` - CI pipeline configuration
    * `.mvn` - maven configuration

- Dev tools:
    * `.ansible-wrapper` - a tool for testing deployment configuration
    * ansible-wrapper.sh - convenient run script for ansible-wrapper

## Generic Java application

An application exposes following endpoints:

* `GET` /
* `GET` /hello
* `GET` /hello/`{name}`
* `GET` /smoke


## Develop locally

* Ensure NEXUS_USER and NEXUS_PASS contains token from repository.sabre.com (read FAQ below)

* Build 

```bash
# to show available build options
make

# regular build
make build
```

or 

```bash
mvn --settings .mvn/settings.xml clean install
```

* Import to Intellij Idea

     Use Maven project / module wizard.

    **IMPORTANT**: Do it after you build app locally. 

    Otherwise IDEA will try to download the dependencies itself - which will fail with `Not authorized` error - unless you have ~/.m2/settings.xml file.
    When you don't have it copy it from .mvn directory.

### FAQ

#### The repository.sabre.com requirement

Project uses https://repository.sabre.com as source of dependencies.

The https://repository.sabre.com  requires user / password authentication.

The best way to handle it is to:
- go to https://repository.sabre.com
- login as yourself (use sg0xxxxx for login)
- Go to Account / Manage your account / User Token / Access User Token 
- provide your password again
- Get user name and password of the token
- Add them to `.bashrc` as NEXUS_USER and NEXUS_PASS environment variables - so that they will be automatically available every time.
Keep them secret same way you keep secret your ssh keys.
```bash
echo 'export NEXUS_USER=tokenUserName' >> ~/.bashrc
# keep space at the beginning of the command, so that your bash history will not record the entry
 echo 'export NEXUS_PASS=tokenPass' >> ~/.bashrc
```

