package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

public enum CodeContextInPosRS {

        SEATS_PADIS("SEATS_PADIS", "IATA SPECIFIC"),
        SEATS_PADIS_GROUPING("SEATS_PADIS_GROUPING", "CARRIER SPECIFIC");

        private String value;
        private String text;

        CodeContextInPosRS(String value, String text) {
            this.value = value;
            this.text = text;
        }

        public String getValue() {
            return value;
        }

        public String getText() {
            return text;
        }
    }

