package com.sabre.cucumber.events;

import com.sabre.cucumber.state.TestContext;
import com.sabre.cucumber.utils.ServiceUtility;
import com.sabre.cucumberbase.model.global.Global;
import com.sabre.cucumberbase.services.base.HelperService;
import com.sabre.cucumberbase.services.base.RestAssuredService;
import io.cucumber.java.Before;
import io.cucumber.java.After;

public class Hooks {
    private final TestContext testContext;
    private final ServiceUtility serviceUtility;
    private final Global global;
    private final HelperService helperService;
    private static final String DATE_FORMAT = "yyyy-MM-dd";
    private static RestAssuredService restService;


    public Hooks(TestContext testContext) {
        this.testContext = testContext;
        this.global = testContext.getBaseTestContext().getGlobal();
        this.helperService = testContext.getBaseTestContext().getHelperService();
        this.serviceUtility = new ServiceUtility(testContext);
        this.restService = testContext.getBaseTestContext().getRestService();
    }


    @Before(order = 40)
    public void cucumberSetUp() throws Exception {
        //Initializing Seat Maps array lists
        testContext.setup();
        setAirlineCode();
        setFlightNumber();
    }

    private void setFlightNumber() {
        String flightNum = serviceUtility.generateTestFlightData();
        global.getDataMap().put("FLIGHT_NUMBER1",flightNum);

        String flightNum2 = serviceUtility.generateTestFlightData();
        global.getDataMap().put("FLIGHT_NUMBER2",flightNum2);

        String flightNum3 = serviceUtility.generateTestFlightData();
        global.getDataMap().put("FLIGHT_NUMBER3",flightNum3);


        String flightNum4 = serviceUtility.generateTestFlightDataThreeDigit();
        global.getDataMap().put("THREE_DIGIT_FLT_NUMBER",flightNum4);
    }

    @After(order = 40)
    public void cucumberTearDown() throws Exception {
        deleteFlightIndex();
    }

    private void setAirlineCode() throws Exception {

        String ownerAirlineCode = serviceUtility.substituteValue("testData.ownerAirlineCode");
        global.getDataMap().put("OWNER_AIRLINE_CODE",ownerAirlineCode);

        String airlineCode = serviceUtility.substituteValue("testData.airlineCode");
        global.getDataMap().put("AIRLINE_CODE",airlineCode);
    }

    private void deleteFlightIndex() throws Exception {
        String url = serviceUtility.substituteValue("testData.deleteFlightIndex") + "/" + global.getDataMap().get("OWNER_AIRLINE_CODE") + "/"+
                global.getDataMap().get("AIRLINE_CODE") + "/" + global.getDataMap().get("FLIGHT_NUMBER1") + "/" + helperService.getFutureDate(2, DATE_FORMAT);

        restService.getRequest(url);
    }

}
