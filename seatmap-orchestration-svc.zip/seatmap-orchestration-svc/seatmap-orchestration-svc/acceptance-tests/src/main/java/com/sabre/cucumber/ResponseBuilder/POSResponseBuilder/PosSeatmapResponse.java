package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

@Data
public class PosSeatmapResponse {
    private SeatmapResponseInPOS seatmapResponse;
}
