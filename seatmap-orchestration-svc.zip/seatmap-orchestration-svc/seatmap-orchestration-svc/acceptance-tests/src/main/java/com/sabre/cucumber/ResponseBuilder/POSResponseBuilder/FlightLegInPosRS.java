package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

import java.util.List;

@Data
public class FlightLegInPosRS {
    private String departureAirportCode;
    private String arrivalAirportCode;
    private String iataConfigurationCode;
    private String physicalAircraftName;
    private String physicalAircraftDescription;
    private String cabinJumpSeatCount;
    private String cockpitJumpSeatCount;
    private Boolean isAnimalAllowed;
    private Boolean isSmoking;
    private String scheduleDepartureDateTime;
    private String scheduleArrivalDateTime;
    private List<CabinInPosRS> cabins;
    //private Boolean changeofGaugeInd;
}
