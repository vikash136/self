package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

import java.util.List;

@Data
public class SeatRowsInPosRS {
    private List<OxygenmasksInPosRS> oxygenMasks;
    private List<SeatsInPosRS> seats ;
    private String rowNumber;
    private List<String> rowCharacteristics;
}
