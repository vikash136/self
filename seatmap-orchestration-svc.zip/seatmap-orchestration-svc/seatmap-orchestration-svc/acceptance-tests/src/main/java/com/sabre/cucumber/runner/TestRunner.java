package com.sabre.cucumber.runner;

import com.sabre.cucumberbase.cucumber.runner.BaseTestRunner;
import com.sabre.cucumberbase.services.base.SubstitutorService;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

@CucumberOptions(features = {"src/main/java/com/sabre/cucumber/features"},
        glue = {"com.sabre.cucumber.stepdefs", "com.sabre.cucumber.events"},
        plugin = {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
        tags = {"@sanity"})

public class TestRunner extends BaseTestRunner {

    @Parameters({"sprintId", "env", "productAre@a", "product", "component", "cucumber.options", "uapZone", "jenkinsBuild",
            "sonarQubeUri", "livereporting", "phase", "rallyIntegration", "enableWiremockServer", "jenkinsJobName"})
    @BeforeTest(alwaysRun = true)
    public void setUpTest(@Optional("Orchestration") String sprintId, @Optional("INT") String env,
                          @Optional("Orchestration") String productArea, @Optional("orchestrationService") String product,
                          @Optional("") String component, @Optional("") String tags,
                          @Optional("Blue") String uapZone, @Optional("NoBuild") String jenkinsBuild,
                          @Optional("NoSonarQubeUri") String sonarQubeUri,
                          @Optional("false") String livereporting, @Optional("DryRun") String phase,
                          @Optional("false") String rallyIntegration, @Optional("false") String enableWiremockServer,
                          @Optional("Starter_Kit_Run") String jenkinsJobName) {
        reportingMetaData.setSprintId(sprintId);
        reportingMetaData.setEnv(env);
        reportingMetaData.setProductArea(productArea);
        reportingMetaData.setProduct(product);
        reportingMetaData.setComponent(component);
        reportingMetaData.setUapZone(uapZone);
        reportingMetaData.setJenkinsBuild(jenkinsBuild);
        reportingMetaData.setSonarQubeUri(sonarQubeUri);
        reportingMetaData.setLivereporting(livereporting);
        reportingMetaData.setPhase(phase);
        reportingMetaData.setRallyIntegration(rallyIntegration);
        reportingMetaData.setEnableWiremockServer(enableWiremockServer);
        reportingMetaData.setJenkinsJob(jenkinsJobName);
        reportingMetaData.setEnv(env);

        SubstitutorService.setProduct(product);
        SubstitutorService.setEnvValue(env);
    }

}