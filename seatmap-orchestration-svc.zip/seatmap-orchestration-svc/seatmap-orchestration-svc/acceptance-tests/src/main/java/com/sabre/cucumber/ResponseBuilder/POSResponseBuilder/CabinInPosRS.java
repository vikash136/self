package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Data
public class CabinInPosRS {
    private List<SeatRowsInPosRS> seatRows;

    private CabinLayoutInPosRS cabinLayout;

    public List<SeatRowsInPosRS> getSeatRowList() {
        if (Objects.isNull(seatRows)) {
            seatRows = new ArrayList<>();
        }
        return this.seatRows;
    }
}
