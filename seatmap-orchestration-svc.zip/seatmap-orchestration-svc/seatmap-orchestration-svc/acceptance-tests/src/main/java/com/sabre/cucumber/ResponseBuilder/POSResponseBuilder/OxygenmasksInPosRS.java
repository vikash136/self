package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

@Data
public class OxygenmasksInPosRS {
    private Integer additionalMaskCount ;
    private String section;
}
