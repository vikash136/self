package com.sabre.cucumber.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sabre.cucumber.state.TestContext;
import com.sabre.cucumberbase.model.global.Global;
import com.sabre.cucumberbase.services.base.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class ServiceUtility {
    private TestContext testContext;
    private SubstitutorService substitutorService;
    private AssertionService assertionService;
    private RestAssuredService restAssuredService;
    private CouchBaseService couchBaseService;
    private JsonService jsonService;
    private Global global;
    private HelperService helperService;

    //Rest Service variables
    private Response response;
    public JsonObject object;

    String url = "";
    String endpoint = "";

    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ServiceUtility.class);
    public final String BASE_PATH = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "SeatOffload" + File.separator + "OrchestrationPayloads" + File.separator;
    private static final String INT = "int";
    private static final String DEV = "dev";
    private static final String CERT = "cert";
    private static final String DATE_FORMAT = "yyyy-MM-dd";
    private static final String MARKETING_FLIGHT = "FLIGHT_NUMBER2";
    private static final String FUNNEL_FLIGHT = "FLIGHT_NUMBER3";
    private static final String THREE_DIGIT_FLIGHT = "THREE_DIGIT_FLT_NUMBER";


    public ServiceUtility(TestContext testContext) {
        this.testContext = testContext;
        this.substitutorService = testContext.getBaseTestContext().getSubstitutorService();
        this.assertionService = testContext.getBaseTestContext().getAssertionService();
        this.restAssuredService = testContext.getBaseTestContext().getRestService();
        this.couchBaseService = testContext.getBaseTestContext().getCouchBaseService();
        this.jsonService = testContext.getBaseTestContext().getJsonService();
        this.global = testContext.getBaseTestContext().getGlobal();
        this.helperService = testContext.getBaseTestContext().getHelperService();

        //Accessor variables for base libraries
        this.response = testContext.getBaseTestContext().getRestService().response;
    }

public String getServiceUrl(String resource) throws Exception {
        String host = System.getProperty("host");

        if (host == null) {
            host = INT;
        }
        switch (host) {
            case INT:
            case DEV:
            case CERT:
                url = substitutorService.substituteValue("{testData.orchServiceURL}");
                endpoint = url + "/" + resource;
                System.out.println("Endpoint url " + endpoint);
                break;
            default:
                String port = System.getProperty("ngp.service.port");
                endpoint = "http://" + host + ":" + port + "/" + resource;
                System.out.println("Endpoint url " + endpoint);
                break;
        }
        return endpoint;
    }

    private String readFilePath(String filepath) throws IOException {

        //Generate JSON file path
        String payloadRQ = BASE_PATH + File.separator + filepath;

        //Read JSON file and convert to JSON Object
        payloadRQ = new String(Files.readAllBytes(Paths.get(payloadRQ)));
        return payloadRQ;
    }


    public String substituteValue(String data) throws Exception {
        String host = System.getProperty("host");
        String propertyFile;

        if (host == null) {
            host = INT;
        }
        switch (host) {
            case INT:
            case DEV:
            case CERT:
                propertyFile = substitutorService.substituteValue("{" + data + "}");
                break;
            default:
                propertyFile = substitutorService.substituteValueFromResourcesRoot("{" + data + "}");
                break;
        }
        return propertyFile;
    }

    public Response getServiceCall(String url) throws Exception {

        String endpoint = getServiceUrl(substituteValue(url));
        response = restAssuredService.getRequest(endpoint);
        return response;
    }

    public Response postServiceCall(String url, String timeoutValue) throws Throwable {
        //Append timeout value to end point
        String endpoint = getServiceUrl(substituteValue(url))+timeoutValue;
        Map<String, String> requestHeaders = new HashMap<>();
        response = restAssuredService.post(endpoint,requestHeaders);
        int actualStatusCode = restAssuredService.getStatusCodeFromResponse();
        int expStatusCode = Integer.parseInt("200");
        assertionService.assertThat("Verify Status code is Correct", actualStatusCode, Matchers.equalTo(expStatusCode));
        return response;
    }


    public Response setToggleForESSMService(String url, String flag) throws Exception {

        String endpoint = getServiceUrl(substituteValue(url));
        endpoint +=flag;
        LOGGER.info("changeEssmServiceState URL is :" + endpoint);
        response = restAssuredService.getRequest(endpoint);
        return  response;
    }


    public String getNewSessionToken() throws Exception {
        String newTokenGenerated = "";

        endpoint = substituteValue("testData.tokenEndPoint");
        LOGGER.info(" Post URL is :" + endpoint);
        Map<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put("Authorization", substituteValue("testData.validToken"));
        requestHeaders.put("Application-ID", "SEATS:SEATMAP_ORCHESTRATION_SVC");
        response = restAssuredService.post(endpoint, requestHeaders);
        String getAuth = response.getHeader("Authorization");
        newTokenGenerated = getAuth.substring(7);
        return newTokenGenerated;
    }

    private String replaceValuesInReqPayload(String payload) throws Exception {
        String payloadAsString = readFilePath(payload);

        global.getDataMap().put("version",helperService.getRandomNumber(2));

        payloadAsString = payloadAsString.replace("OWNER_AIRLINE_CODE", global.getDataMap().get("OWNER_AIRLINE_CODE"));
        payloadAsString = payloadAsString.replace("AIRLINE_CODE", global.getDataMap().get("AIRLINE_CODE"));
        payloadAsString = payloadAsString.replace("EFFECTIVE_DATE", helperService.getFutureDate(1, DATE_FORMAT));
        payloadAsString = payloadAsString.replace("DISCONTINUE_DATE", helperService.getFutureDate(4, DATE_FORMAT));
        payloadAsString = payloadAsString.replace("VERSION", global.getDataMap().get("version"));

        payloadAsString = payloadAsString.replace("MSG_TIMESTAMP", OffsetDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS"))+"Z");


        payloadAsString = payloadAsString.replace("AIRLINE_CODE", global.getDataMap().get("AIRLINE_CODE"));
        payloadAsString = payloadAsString.replace("TPF_AIRLINE", substituteValue("testData.TPFAirlineCode"));
        payloadAsString = payloadAsString.replace("FLIGHT_NUMBER1", global.getDataMap().get("FLIGHT_NUMBER1"));
        payloadAsString = payloadAsString.replace("FLIGHT_NUMBER2", global.getDataMap().get("FLIGHT_NUMBER2"));
        payloadAsString = payloadAsString.replace("FLIGHT_NUMBER3", global.getDataMap().get("FLIGHT_NUMBER3"));
        payloadAsString = payloadAsString.replace("THREE_DIGIT_FLT_NUMBER", global.getDataMap().get("THREE_DIGIT_FLT_NUMBER"));
        payloadAsString = payloadAsString.replace("OPERATIONAL_SUFFIX", substituteValue("testData.operationalSuffix"));
        payloadAsString = payloadAsString.replace("SECONDARY_AIRLINE", substituteValue("testData.secondaryAirlineCode"));
        payloadAsString = payloadAsString.replace("ARRIVAL_AIRPORT_CODE1", substituteValue("testData.arrivalAirportCode1"));
        payloadAsString = payloadAsString.replace("ARRIVAL_AIRPORT_CODE2", substituteValue("testData.arrivalAirportCode2"));
        payloadAsString = payloadAsString.replace("ARRIVAL_AIRPORT_CODE3", substituteValue("testData.arrivalAirportCode3"));
        payloadAsString = payloadAsString.replace("TPF_ARRIVAL_AIRPORT", substituteValue("testData.TPFarrivalAirportCode1"));
        payloadAsString = payloadAsString.replace("DEPARTURE_DATE", helperService.getFutureDate(Integer.parseInt(substituteValue("testData.noOfDays")), DATE_FORMAT));
        payloadAsString = payloadAsString.replace("DEP_DATE_24HR", helperService.getFutureDate(Integer.parseInt(substituteValue("testData.oneDay")), DATE_FORMAT));

        payloadAsString = payloadAsString.replace("CURRENT_DPR_DATE", helperService.getFutureDate(Integer.parseInt(substituteValue("testData.currentDay")), DATE_FORMAT));
        payloadAsString = payloadAsString.replace("CURRENT_DPR_TIME",  OffsetDateTime.now(ZoneOffset.UTC).plusHours(2).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"))+"Z");

        payloadAsString = payloadAsString.replace("DEPARTURE_AIRPORT_CODE1", substituteValue("testData.departureAirportCode1"));
        payloadAsString = payloadAsString.replace("DEPARTURE_AIRPORT_CODE2", substituteValue("testData.departureAirportCode2"));
        payloadAsString = payloadAsString.replace("DEPARTURE_AIRPORT_CODE3", substituteValue("testData.departureAirportCode3"));
        payloadAsString = payloadAsString.replace("DEPARTURE_AIRPORT_CODE4", substituteValue("testData.departureAirportCode4"));
        payloadAsString = payloadAsString.replace("TPF_DEPARTURE_AIRPORT", substituteValue("testData.TPFdepartureAirportCode1"));
        payloadAsString = payloadAsString.replace("RBD",substituteValue("testData.RBD"));
        payloadAsString = payloadAsString.replace("invalidRBD",substituteValue("testData.invalidRBD"));
        payloadAsString = payloadAsString.replace("unauthorizedAirlineCode",substituteValue("testData.testUnauthorizedAirlineCode"));
        payloadAsString = payloadAsString.replace("invalidCarrierCode",substituteValue("testData.invalidAirlineCode"));
        payloadAsString = payloadAsString.replace("unSupportedAirlineCode",substituteValue("testData.unSupportedAirlineCode"));

        //System.out.println("Sending Request : {}"+ payloadAsString);
        LOGGER.info("Sending Request : {}", payloadAsString);
        return payloadAsString;
    }



public Response postRequest(String payload, String url, String authToken) throws Exception {
        String endpoint = getServiceUrl(substituteValue(url));
        String payloadAsString;
        payloadAsString = replaceValuesInReqPayload(payload);
        Object obj = new JSONParser().parse(payloadAsString);
        //convert string to JSON object
        JSONObject object = (JSONObject) obj;

        String rulesEndpoint ="";
        if(url.equalsIgnoreCase("Create")) {
            rulesEndpoint = substituteValue("testData.createAgreementRules");
            response = restAssuredService.post(rulesEndpoint, object, ContentType.JSON);
        }
        else if(url.equalsIgnoreCase("Delete")) {
            rulesEndpoint = substituteValue("testData.deleteAgreementRule");
            response = restAssuredService.post(rulesEndpoint, object, ContentType.JSON);
        }
        else if(url.equalsIgnoreCase(("saveFlightIndex"))){
            rulesEndpoint = substituteValue("testData.saveFlightIndex");
            response = restAssuredService.post(rulesEndpoint, object, ContentType.JSON);
        }else
            if(url.equalsIgnoreCase("createSeatmap")){
                rulesEndpoint = substituteValue("testData.seatMapEvent");
                response = restAssuredService.post(rulesEndpoint, object, ContentType.JSON);
                checkForEventStatus();
            }
         else
            if(url.equalsIgnoreCase("createSeatmapWithSuffix")){
                rulesEndpoint = substituteValue("testData.seatMapEvent");
                response = restAssuredService.post(rulesEndpoint, object, ContentType.JSON);
                checkForEventStatusWithSuffix(substituteValue("testData.operationalSuffix"));
            }
        if(null!=authToken) {
            authToken = getAuthToken(authToken);
        }
            Map<String, String> requestHeaders = new HashMap<>();
            requestHeaders.put("securityToken", authToken);
            requestHeaders.put("x-transaction-id", "12345");
            requestHeaders.put("x-correlation-id", "testCore999");
            response = restAssuredService.post(endpoint, requestHeaders, object, ContentType.JSON);
            return response;

    }

    private boolean checkForEventStatus() throws Exception {
        int count=0;
        while(true) {
            count++;
            boolean isExitWhileLoop=true;
            response = getSeatMapCreateEventMethod(substituteValue("testData.getSeatMapCreateEvent"));
            if (getSeatmapEventStatus(count, isExitWhileLoop)) break;
        }
        return true;
    }


    private boolean checkForEventStatusWithSuffix(String operationalSuffix) throws Exception {
        int count=0;
        while(true) {
            count++;
            boolean isExitWhileLoop=true;
            response = getSeatMapCreateEventMethodWithSuffix(substituteValue("testData.getSeatMapCreateEvent"),operationalSuffix);
            if (getSeatmapEventStatus(count, isExitWhileLoop)) break;
        }
        return true;
    }

    private boolean getSeatmapEventStatus(int count, boolean isExitWhileLoop) throws InterruptedException {
        List<String> serviceStatus = restAssuredService.getElementValueAsList("status");
        System.out.println("Value received "+ serviceStatus);
        System.out.println("Value expected "+ "SUCCESS");

        if(!serviceStatus.isEmpty() && !serviceStatus.contains("FAILURE")){
            for(String s:serviceStatus){
                if(!s.equalsIgnoreCase("SUCCESS")){
                    isExitWhileLoop=false;
                    break;
                }
            }
        }
        if(isExitWhileLoop){
            return true;
        }
        if(count==20){
            throw new RuntimeException("FTS scheduler to SeatmapEP: Reached maximum attempt to create detailMap");
        }
        Thread.sleep(10000);
        return false;
    }

    public Response getSeatMapCreateEventMethod(String url) throws Exception {
        String endPoint;
        endPoint = url + "/" + global.getDataMap().get("OWNER_AIRLINE_CODE") + "/" + global.getDataMap().get("AIRLINE_CODE") + "/" + global.getDataMap().get("FLIGHT_NUMBER1") + "/" + helperService.getFutureDate(Integer.parseInt(substituteValue("testData.noOfDays")), DATE_FORMAT);
        System.out.println("End point is "+endPoint);
        return response = restAssuredService.getRequest(endPoint);
    }

    public Response getSeatMapCreateEventMethodWithSuffix(String url, String operationalSuffix) throws Exception {
        String endPoint;
        endPoint = url + "/" + global.getDataMap().get("OWNER_AIRLINE_CODE") + "/" + global.getDataMap().get("AIRLINE_CODE") + "/" + global.getDataMap().get("FLIGHT_NUMBER1") + "/" + helperService.getFutureDate(Integer.parseInt(substituteValue("testData.noOfDays")), DATE_FORMAT)+"?operationalSuffix="+operationalSuffix;
        System.out.println("End point is "+endPoint);
        return response = restAssuredService.getRequest(endPoint);
    }

    private String getAuthToken(String authToken) throws Exception {
        switch (authToken){
                    //get valid security token
            case "CREATE":
                    authToken = getNewSessionToken();
                    System.out.println(" New Token generated: " + authToken);
                    break;
                    //Expired auth token
            case "eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1MjIyMjctQUFTLUFBIiwic2NwIjpbXSwic3ViamVjdF90b2tlbl90eXBlIjoiQVRLIiwia2V5d29yZHMiOlsiQ0hHQUFBIiwiQUdZQUFBIiwiVU5WUEFSIiwiQ1JTQUdUIl0sInN1YmplY3RfdG9rZW5fY3JlYXRpb24iOiIxNjAzMTcxMTY1Iiwic3ViamVjdF90b2tlbl9leHBpcmF0aW9uIjoiMTYwMzc3NTk2NSIsImlzcyI6Imh0dHBzOi8vZXNzbXdzLmludC5zYWJyZS5jb20vIiwiZHV0eV9jb2RlcyI6WyIwIiwiMSIsIjIiLCI0IiwiNSIsIjYiLCI3IiwiOCIsIjkiLCIkIiwiIyIsIioiLCItIiwiLyJdLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDU0VBVFM6U0VBVE1BUF9PUkNIRVNUUkFUSU9OX1NWQyIsImF1ZCI6ImludC1hdWQiLCJ1aWQiOiI1MjIyMjciLCJob21lX2NpdHkiOiJIRFEiLCJuYmYiOjE2MDMxNzExNjUsImFnZW50X3NpZ24iOiJIM00iLCJkb21haW4iOiJBQSIsImV4cCI6MTYwMzE3MTQ2NSwiaWF0IjoxNjAzMTcxMTY1LCJpYXRhX251bWJlciI6Ijk5OTk5OTkiLCJzdWJqZWN0X3Rva2VuIjoiVDFSTEFRTDRJb2JnOGp4LzdBSnpKOGY2YUkvTHRvM2RrUkFSUzZoWXkvODhtWXdLaVhuTVFidjFBQURRZGtHSGFTd1FnYy9yZUE0WUVJT2ZTSThyV0dRUGZVc3pPR0ZzZDhMUm9IaEJBRjBtdFdLbmNQKzJpMjM4RWd3S1hBbWhINW42amFTZ1NHeHBKKzVpbU1ncENKNTVhVUczRkVEa2NyVm9ZQlJpQlBmZkJJY21YeU5RaUJmOWJIZE9MWHlCNlNVSnN4UC9ZcElqQWxSbDN0YU1JaW5ob08za3Q1dXZ1Wnk2S2tuM1RtYy83azlDdEY5Si9HRk1PcU5XZTNmcmJMQnNVY0dMOWhwWm9yb3poNHl0U2NJaFRzZWtldDRVejYvditmdmlES2c0WUY3OWdmcUNhVzZBMzF1Z1hKa3JTekh4aHEvWGdYV1U5ZHUyd3cqKiIsImp0aSI6IjE2MDMxNzExNjU1MDkwMDAwMDAiLCJncm91cCI6IkFBUyJ9.Amnz-f8ZBfuFfR1odKri4V_r68Y3owq6mFTeAlmteSABUsADuEpQXqAREBQsnMBXuSmr6OHKcl-gulCZoC8_dxo4ADKsLWadQYlx5jsBsettWcSy-136BBSktoEMvwILJnHSA6y5DGrPqe9iN3hNOKPZZCiINsmDaWligp1kOTC8Bcct9X1Cyp-Iy7KmEKhOa_weBDa63uH95dzKFiWQnkMXxzQ6Pq8mqMiyaHX09pee6i-Ba_u4y7aDDAS-c_sFVqvtHEYhDKykKDOBoVYPcNFubI2W5WQfT6E-eV2QgKe8FYhu3BK9zop-bUnTTbJnHAI8Tz5_ujVzs9d_kTZ5BQ":
                    System.out.println(" Expired Token : " + authToken);
                    break;
                    //corrupted auth token
            case "CORRUPTTOKEN":
                    authToken = getNewSessionToken();
                    char[] jwtTokenChars = authToken.toCharArray();
                    jwtTokenChars[4] = '?';
                    authToken = String.valueOf(jwtTokenChars);
                    System.out.println(" New Token generated: " + authToken);
                    break;

            case "EMPTYTOKEN":
                    authToken = "";
                    System.out.println(" New Token generated: " + authToken);
                    break;
            case "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMDAyLWNraS1zYWJyZSIsInNjcCI6W10sInN1YmplY3RfdG9rZW5fdHlwZSI6IkFUSyIsImtleXdvcmRzIjpbXSwiaG9tZV9wcmltZV9ob3N0IjoiKioiLCJzdWJqZWN0X3Rva2VuX2NyZWF0aW9uIjoiMTYwNzQ0NDk5NiIsInN1YmplY3RfdG9rZW5fZXhwaXJhdGlvbiI6IjE2MDgwNDk3OTYiLCJpc3MiOiJodHRwczovL2Vzc213cy5pbnQuc2FicmUuY29tLyIsImR1dHlfY29kZXMiOltdLCJsYXN0X25hbWUiOiJXZWIgQXBwIiwiY3VycmVudF9wcmltZV9ob3N0IjoiKioiLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDIiwiYXVkIjoiaW50LWF1ZCIsInVpZCI6IjEwMDIiLCJuYmYiOjE2MDc0NDQ5OTYsImRvbWFpbiI6InNhYnJlIiwiZXhwIjoxNjA3NDQ1Mjk2LCJpYXQiOjE2MDc0NDQ5OTYsInN1YmplY3RfdG9rZW4iOiJUMVJMQVFMSTQ1c1drMzIvSlphZk5XMURHN1p1MDVoN0hCQUwzVGp0OG9OUGNPbVBLVFBGeU0wb0FBRFFwQ1ZlSWpVWVpzY29SazdUMzhhdXZwbUMyQW5sK3pZQ3NWQVc0SzVXVmZsZWRoLzRvcW8zL012bzh4Z3U2dVRlZS9aSUczY1FNSXJOckRwcTBLN2lWZzNTRFhpYUxqMFhWcEJYbFdJMkRndkl1S2Z6Z211eVB2WFRJWVR6MmwwQzBCeGcwcWpMVXNGZERQOW5Rbm9ob05OK1g1MDVtbjBnWTU2VVhCUmcxcGVUSzFKU24zcmx3aFUxeGpnNHJhaUN2cWNmRjJMdEtvUnJ3N0h5R3doV1JkdC9IbXNHbjlUZHgrczdLRnpVRE9pbGNzZC85ZmxSaXdyRHVnZ2gwT0Z5Nk82L1ZTdGdGckM4R0N2NEpHdXE0USoqIiwianRpIjoiMTYwNzQ0NDk5NjMzMjAwMDAwMCIsImdyb3VwIjoiY2tpIn0.KersOOPBSAtT78GsSatDeGNJiI28qLpQhJChmf7DKm4":
                    System.out.println(" nonESSMWS security token Token : " + authToken);
                    break;
            default:
                    authToken = getNewSessionToken();
                    break;
        }
        return authToken;
    }


    public String generateTestFlightData() {
        String flightnum = "4" + helperService.getRandomNumber(3);
        List<String> testFlights = testContext.getTestFlightsCreated();

        String finalFlightnum = flightnum;
        Boolean isPresent = testFlights.stream().filter(flightList -> !flightList.isEmpty())
                .anyMatch(flightList -> flightList.equalsIgnoreCase(finalFlightnum));

        if (isPresent) {
            flightnum = helperService.getRandomNumber(4);
        }
        testContext.getTestFlightsCreated().add(flightnum);
        global.getDataMap().put("FLIGHT_NUMBER", flightnum);
        return flightnum;
    }


    public String generateTestFlightDataThreeDigit() {
        String flightnum = "2" + helperService.getRandomNumber(2);
        List<String> testFlights = testContext.getTestFlightsCreated();

        String finalFlightnum = flightnum;
        Boolean isPresent = testFlights.stream().filter(flightList -> !flightList.isEmpty())
                .anyMatch(flightList -> flightList.equalsIgnoreCase(finalFlightnum));

        if (isPresent) {
            flightnum = helperService.getRandomNumber(4);
        }
        testContext.getTestFlightsCreated().add(flightnum);
        global.getDataMap().put("FLIGHT_NUMBER", flightnum);
        return flightnum;
    }

    public Response getFlightIndex(String flightNumber) throws Exception {
    String currentDate = helperService.getFutureDate(Integer.parseInt(substituteValue("testData.noOfDays")), DATE_FORMAT);
        String endpoint = substituteValue("testData.saveFlightIndex")+ "/" + global.getDataMap().get("AIRLINE_CODE") + "/" + flightNumber + "/" + currentDate;
        System.out.println("End point is "+endpoint);
        return response = restAssuredService.getRequest(endpoint);

    }

    public void deleteTestSeatMaps(String docType, String operationalSuffix, String flightType) throws Exception {
        String id;
        String flightNumber = getFlightNumberBasedOnFlightType(flightType);

        if(docType.equalsIgnoreCase("FLIGHT_INDEX")){
            List<String> flightIndexDocumentIds = getFlightIndexIds(operationalSuffix,flightNumber, global.getDataMap().get("OWNER_AIRLINE_CODE"));
            for(String documentId : flightIndexDocumentIds){
                endpoint = getServiceUrl("deleteTestDataById") +
                        "/" + global.getDataMap().get("OWNER_AIRLINE_CODE") + "/" + documentId;

                restAssuredService.delete(endpoint);
            }
        }else{
            id =  String.join(":",global.getDataMap().get("OWNER_AIRLINE_CODE"), global.getDataMap().get("OWNER_AIRLINE_CODE"),
                    docType, flightNumber, operationalSuffix, helperService.getFutureDate(Integer.parseInt(substituteValue("testData.noOfDays")), DATE_FORMAT));
            String endpoint = getServiceUrl("deleteTestDataById") +
                    "/" + global.getDataMap().get("OWNER_AIRLINE_CODE") + "/" + id;

            restAssuredService.delete(endpoint);
        }
    }

    private String getFlightNumberBasedOnFlightType(String flightType){
        String flightNumber;
        switch (flightType){
            case MARKETING_FLIGHT :
                flightNumber = global.getDataMap().get("FLIGHT_NUMBER2");
                break;
            case FUNNEL_FLIGHT :
                flightNumber = global.getDataMap().get("FLIGHT_NUMBER3");
                break;
            case THREE_DIGIT_FLIGHT :
                flightNumber = global.getDataMap().get("THREE_DIGIT_FLT_NUMBER");
                break;
            default:
                flightNumber = global.getDataMap().get("FLIGHT_NUMBER1");
                break;
        }
        return flightNumber;
    }
    private List<String> getFlightIndexIds(String operationalSuffix, String flightNumber, String ownerAirlineCode) throws Exception {
        String endpoint;
        if(operationalSuffix.equalsIgnoreCase("NO_OP_SFX")){
            endpoint = getServiceUrl("getFlightIndexByFlightNumber") +
                    "/" + ownerAirlineCode + "/" + ownerAirlineCode + "/" + flightNumber + "/" + helperService.getFutureDate(Integer.parseInt(substituteValue("testData.noOfDays")), DATE_FORMAT);;
        }else{
            endpoint = getServiceUrl("getFlightIndexByFlightNumber") +
                    "/" + ownerAirlineCode + "/" + ownerAirlineCode + "/" + flightNumber + "/" + helperService.getFutureDate(Integer.parseInt(substituteValue("testData.noOfDays")), DATE_FORMAT) +
                    "?operationalSuffix="+operationalSuffix;
        }

        response = restAssuredService.getRequest(endpoint);
        System.out.println("response as String : "+ response.asString());
        List<String> ids = new ArrayList<>();

        if(response.asString().isEmpty()){
            LOGGER.info("No flight index created for flight = {}",flightNumber);
        }
        else if(response.asString().contains("id")){
            JsonArray ls = jsonService.getValueWithPath(response.asString(),"$[*].id");
            ls.forEach(id -> ids.add(id.getAsString()));
        }
        return ids;
    }
}


