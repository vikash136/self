package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Data
public class SeatsInPosRS {
    private List<CharacteristicsInPosRS> characteristics;
    private String columnCode ;
    private String seatStatus ;
    private List<String> passengerRestrictions;

    public List<CharacteristicsInPosRS> characteristic() {
        if(CollectionUtils.isEmpty(characteristics)) {
            characteristics = new ArrayList<>();
        }
        return characteristics;
    }
}
