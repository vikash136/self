package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

@Data
public class FacilityInPosRS {
    private LocationInPosRS location;
    private String facilityType;
}
