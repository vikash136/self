package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

@Data
public class ErrorMessageInPosRS {
    private String errorCode;
    private String descText;
    private String errorId;
    private String errorType;
}
