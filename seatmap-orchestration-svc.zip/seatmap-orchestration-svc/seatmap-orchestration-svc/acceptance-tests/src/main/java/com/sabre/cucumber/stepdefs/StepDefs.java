package com.sabre.cucumber.stepdefs;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sabre.cucumber.ResponseBuilder.POSResponseBuilder.CharacteristicsInPosRS;
import com.sabre.cucumber.ResponseBuilder.POSResponseBuilder.PosSeatmapResponse;
import com.sabre.cucumber.ResponseBuilder.POSResponseBuilder.SeatRowsInPosRS;
import com.sabre.cucumber.ResponseBuilder.POSResponseBuilder.SeatsInPosRS;
import com.sabre.cucumber.state.TestContext;
import com.sabre.cucumber.utils.ServiceUtility;
import com.sabre.cucumberbase.model.global.Global;
import com.sabre.cucumberbase.services.base.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.hamcrest.Matchers;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class StepDefs {
    private TestContext testContext;
    private AssertionService assertionService;
    private RestAssuredService restService;
    private CouchBaseService couchBaseService;
    private JsonService jsonService;
    private Global global;
    private HelperService helperService;
    private ServiceUtility svcUtility;
    private PosSeatmapResponse posSeatmapResponse;
    private static final String SEATS_PADIS = "SEATS_PADIS";

    //Rest Service variables
    private Response response;
    //
    public JsonObject jsonObject = null;
    //
    private String defaultTimeOut = "";
    private String setZeroTimeoutValue = "0";
    //
    String url = "";
    String endpoint = "";

    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(StepDefs.class);
    public final String BASE_PATH = System.getProperty("user.dir") + File.separator + "src" + File.separator + "main" + File.separator + "resources" + File.separator + "SeatOffload" + File.separator + "OrchestrationPayloads" + File.separator;


    public StepDefs(TestContext testContext) {
        this.testContext = testContext;

        this.assertionService = testContext.getBaseTestContext().getAssertionService();
        this.restService = testContext.getBaseTestContext().getRestService();
        this.couchBaseService = testContext.getBaseTestContext().getCouchBaseService();
        this.jsonService = testContext.getBaseTestContext().getJsonService();
        this.global = testContext.getBaseTestContext().getGlobal();
        this.helperService = testContext.getBaseTestContext().getHelperService();
        this.response = testContext.getBaseTestContext().getRestService().response;
        this.svcUtility = new ServiceUtility(testContext);
    }


    @Given("user wants to verify the payLoad {string} with securityToken")
    public void userWantsToVerifyThePayLoadWithValidSecurityToken(String payload) throws Exception {
        String authToken = "CREATE";
        response = svcUtility.postRequest(payload, "testData.getSeatMap", authToken);
        posSeatmapResponse = new Gson().fromJson(response.asString(), PosSeatmapResponse.class);
    }


    @Given("user wants to verify the payLoad {string} with expired securityToken")
    public void userWantsToVerifyThePayLoadWithExpiredSecurityToken(String payload) throws Exception {
        //use one expired token as input string
        String authToken = "eyJraWQiOiJST09US0VZMUNVUlJFTlQiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1MjIyMjctQUFTLUFBIiwic2NwIjpbXSwic3ViamVjdF90b2tlbl90eXBlIjoiQVRLIiwia2V5d29yZHMiOlsiQ0hHQUFBIiwiQUdZQUFBIiwiVU5WUEFSIiwiQ1JTQUdUIl0sInN1YmplY3RfdG9rZW5fY3JlYXRpb24iOiIxNjAzMTcxMTY1Iiwic3ViamVjdF90b2tlbl9leHBpcmF0aW9uIjoiMTYwMzc3NTk2NSIsImlzcyI6Imh0dHBzOi8vZXNzbXdzLmludC5zYWJyZS5jb20vIiwiZHV0eV9jb2RlcyI6WyIwIiwiMSIsIjIiLCI0IiwiNSIsIjYiLCI3IiwiOCIsIjkiLCIkIiwiIyIsIioiLCItIiwiLyJdLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDU0VBVFM6U0VBVE1BUF9PUkNIRVNUUkFUSU9OX1NWQyIsImF1ZCI6ImludC1hdWQiLCJ1aWQiOiI1MjIyMjciLCJob21lX2NpdHkiOiJIRFEiLCJuYmYiOjE2MDMxNzExNjUsImFnZW50X3NpZ24iOiJIM00iLCJkb21haW4iOiJBQSIsImV4cCI6MTYwMzE3MTQ2NSwiaWF0IjoxNjAzMTcxMTY1LCJpYXRhX251bWJlciI6Ijk5OTk5OTkiLCJzdWJqZWN0X3Rva2VuIjoiVDFSTEFRTDRJb2JnOGp4LzdBSnpKOGY2YUkvTHRvM2RrUkFSUzZoWXkvODhtWXdLaVhuTVFidjFBQURRZGtHSGFTd1FnYy9yZUE0WUVJT2ZTSThyV0dRUGZVc3pPR0ZzZDhMUm9IaEJBRjBtdFdLbmNQKzJpMjM4RWd3S1hBbWhINW42amFTZ1NHeHBKKzVpbU1ncENKNTVhVUczRkVEa2NyVm9ZQlJpQlBmZkJJY21YeU5RaUJmOWJIZE9MWHlCNlNVSnN4UC9ZcElqQWxSbDN0YU1JaW5ob08za3Q1dXZ1Wnk2S2tuM1RtYy83azlDdEY5Si9HRk1PcU5XZTNmcmJMQnNVY0dMOWhwWm9yb3poNHl0U2NJaFRzZWtldDRVejYvditmdmlES2c0WUY3OWdmcUNhVzZBMzF1Z1hKa3JTekh4aHEvWGdYV1U5ZHUyd3cqKiIsImp0aSI6IjE2MDMxNzExNjU1MDkwMDAwMDAiLCJncm91cCI6IkFBUyJ9.Amnz-f8ZBfuFfR1odKri4V_r68Y3owq6mFTeAlmteSABUsADuEpQXqAREBQsnMBXuSmr6OHKcl-gulCZoC8_dxo4ADKsLWadQYlx5jsBsettWcSy-136BBSktoEMvwILJnHSA6y5DGrPqe9iN3hNOKPZZCiINsmDaWligp1kOTC8Bcct9X1Cyp-Iy7KmEKhOa_weBDa63uH95dzKFiWQnkMXxzQ6Pq8mqMiyaHX09pee6i-Ba_u4y7aDDAS-c_sFVqvtHEYhDKykKDOBoVYPcNFubI2W5WQfT6E-eV2QgKe8FYhu3BK9zop-bUnTTbJnHAI8Tz5_ujVzs9d_kTZ5BQ";
        response = svcUtility.postRequest(payload, "testData.getSeatMap", authToken);
    }


    @And("set the toggleESSMService as {string}")
    public void setTheToggleESSMServiceAs(String flag) throws Exception {
        response = svcUtility.setToggleForESSMService("testData.essmServiceState", flag);
    }

    @Then("wait for {string} ms for scheduler to pick")
    public void waitForMsForSchedulerToPick(String configdTime) throws InterruptedException {
        Thread.sleep(Long.parseLong(configdTime));
    }

    // ---- Added for Sprint S-24 ----- starts
    @Then("log message successful payload transformation and transfer to seatmap core service")
    public void LogMessageSuccessfulPayloadTransformationAndTransferToSeatmapCoreService() {
        LOGGER.info("\n" + " ------------ POS payload request for Single-leg flight seatmap details is successfully Transformed and transferred to Seat map Core service and successfully processed to provide seatmap details -------------" + "\n");
    }

    //
    @Then("Fail ConnectivitytoTransformer connection")
    public void FailConnectivitytoTransformerConnection() throws Throwable {

        response = svcUtility.getServiceCall("testData.getServiceTimeoutTranformerService");
        // Firstly, get the Default Timeout set for Authorization to Transformer connection...
        // Store the default set Timeout temporarily ...
        defaultTimeOut = response.getBody().asString();
        LOGGER.info("****** Default set Timeout is : ******" + defaultTimeOut);
        // Next, post a http request for triggering connection timeout error ...
        response = svcUtility.postServiceCall("testData.setServiceTimeoutTransformerService", setZeroTimeoutValue);

    }


    @Then("Restore ConnectivitytoTransformer normal connection")
    public void RestoreConnectivitytoTransformerNormalConnection() throws IOException, ParseException, Throwable {

        //Restore the timeout value to default
        LOGGER.info("****** Default set Timeout is : ******" + defaultTimeOut);
        response = svcUtility.postServiceCall("testData.setServiceTimeoutTransformerService", defaultTimeOut);

    }


    @When("user wants to verify the payLoad {string} with corrupted JWTToken")
    public void userWantsToVerifyThePayLoadWithCorruptedJWTToken(String payload) throws Exception {
        String authToken = "CORRUPTTOKEN";
        response = svcUtility.postRequest(payload, "testData.getSeatMap", authToken);
    }

    @When("user wants to verify the payLoad {string} with empty JWT Token")
    public void userWantsToVerifyThePayLoadWithEmptyJWTToken(String payload) throws Exception {
        String authToken = "EMPTYTOKEN";
        response = svcUtility.postRequest(payload, "testData.getSeatMap", authToken);
    }


    @When("user wants to verify the payLoad {string} with nonESSMWS security token")
    public void userWantsToVerifyThePayLoadWithnonESSMWSsecuritytoken(String payload) throws Exception {
        // At first, get the non-essmws jwt token ....


        String authToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMDAyLWNraS1zYWJyZSIsInNjcCI6W10sInN1YmplY3RfdG9rZW5fdHlwZSI6IkFUSyIsImtleXdvcmRzIjpbXSwiaG9tZV9wcmltZV9ob3N0IjoiKioiLCJzdWJqZWN0X3Rva2VuX2NyZWF0aW9uIjoiMTYwNzQ0NDk5NiIsInN1YmplY3RfdG9rZW5fZXhwaXJhdGlvbiI6IjE2MDgwNDk3OTYiLCJpc3MiOiJodHRwczovL2Vzc213cy5pbnQuc2FicmUuY29tLyIsImR1dHlfY29kZXMiOltdLCJsYXN0X25hbWUiOiJXZWIgQXBwIiwiY3VycmVudF9wcmltZV9ob3N0IjoiKioiLCJjbGllbnRfaWQiOiJTRUFUUzpTRUFUTUFQX09SQ0hFU1RSQVRJT05fU1ZDIiwiYXVkIjoiaW50LWF1ZCIsInVpZCI6IjEwMDIiLCJuYmYiOjE2MDc0NDQ5OTYsImRvbWFpbiI6InNhYnJlIiwiZXhwIjoxNjA3NDQ1Mjk2LCJpYXQiOjE2MDc0NDQ5OTYsInN1YmplY3RfdG9rZW4iOiJUMVJMQVFMSTQ1c1drMzIvSlphZk5XMURHN1p1MDVoN0hCQUwzVGp0OG9OUGNPbVBLVFBGeU0wb0FBRFFwQ1ZlSWpVWVpzY29SazdUMzhhdXZwbUMyQW5sK3pZQ3NWQVc0SzVXVmZsZWRoLzRvcW8zL012bzh4Z3U2dVRlZS9aSUczY1FNSXJOckRwcTBLN2lWZzNTRFhpYUxqMFhWcEJYbFdJMkRndkl1S2Z6Z211eVB2WFRJWVR6MmwwQzBCeGcwcWpMVXNGZERQOW5Rbm9ob05OK1g1MDVtbjBnWTU2VVhCUmcxcGVUSzFKU24zcmx3aFUxeGpnNHJhaUN2cWNmRjJMdEtvUnJ3N0h5R3doV1JkdC9IbXNHbjlUZHgrczdLRnpVRE9pbGNzZC85ZmxSaXdyRHVnZ2gwT0Z5Nk82L1ZTdGdGckM4R0N2NEpHdXE0USoqIiwianRpIjoiMTYwNzQ0NDk5NjMzMjAwMDAwMCIsImdyb3VwIjoiY2tpIn0.KersOOPBSAtT78GsSatDeGNJiI28qLpQhJChmf7DKm4";
        response = svcUtility.postRequest(payload, "testData.getSeatMap", authToken);
    }

    //
    @Then("Fail AuthorizationtoTransformer connection")
    public void FailAuthorizationtoTransformerConnection() throws IOException, ParseException, Throwable {
        response = svcUtility.getServiceCall("testData.getServiceTimeoutAuthToTranform");
        // Firstly, get the Default Timeout set for Authorization to Transformer connection...
        // Store the default set Timeout temporarily ...
        defaultTimeOut = response.getBody().asString();
        LOGGER.info("****** Default set Timeout is : ******" + defaultTimeOut);
        // Next, post a http request for triggering connection timeout error ...
        response = svcUtility.postServiceCall("testData.setServiceTimeoutAuthToTransform", setZeroTimeoutValue);
    }

    //
    @Then("Restore AuthorizationtoTransformer normal connection")
    public void RestoreAuthorizationtoTransformerNormalConnection() throws IOException, ParseException, Throwable {
        //Restore the timeout value to default
        LOGGER.info("****** Default set Timeout is : ******" + defaultTimeOut);
        response = svcUtility.postServiceCall("testData.setServiceTimeoutAuthToTransform", defaultTimeOut);


    }

    //
    @Then("Trigger Authorization Timeout Failure")
    public void TriggerAuthorizationTimeoutFailure() throws IOException, ParseException, Throwable {

        // Firstly, get the Default Timeout set for Authorization to Transformer connection...
        response = svcUtility.getServiceCall("testData.getServiceTimeoutAuthService");

        // Store the default set Timeout temporarily ...
        defaultTimeOut = response.getBody().asString();
        LOGGER.info("****** Default set Timeout is : ******" + defaultTimeOut);
        // Nextly, post a http request for triggering connection timeout error ...
        response = svcUtility.postServiceCall("testData.setServiceTimeoutAuthService", setZeroTimeoutValue);
    }


    @Then("Restore Authorization Normal Timeout")
    public void RestoreAuthorizationNormalTimeout() throws IOException, ParseException, Throwable {
        //Restore the timeout value to default
        LOGGER.info("****** Default set Timeout is : ******" + defaultTimeOut);
        response = svcUtility.postServiceCall("testData.setServiceTimeoutAuthService", defaultTimeOut);
    }


    @Then("Trigger Connectivity Timeout Failure")
    public void TriggerConnectivityTimeoutFailure() throws IOException, ParseException, Throwable {

        // Firstly, get the Default Timeout set for Authorization to Transformer connection...
        response = svcUtility.getServiceCall("testData.getServiceTimeoutConnectivity");

        // Store the default set Timeout temporarily ...
        defaultTimeOut = response.getBody().asString();
        LOGGER.info("****** Default set Timeout is : ******" + defaultTimeOut);
        // Nextly, post a http request for triggering connection timeout error ...
        response = svcUtility.postServiceCall("testData.setServiceTimeoutConnectivity", setZeroTimeoutValue);
    }

    //
    @Then("Restore Connectivity Normal Timeout")
    public void RestoreConnectivityNormalTimeout() throws IOException, ParseException, Throwable {
        //Restore the timeout value to default
        LOGGER.info("****** Default set Timeout is : ******" + defaultTimeOut);
        response = svcUtility.postServiceCall("testData.setServiceTimeoutConnectivity", defaultTimeOut);

    }

    //
    // ---- Added for Sprint S-21 US975786  ----- Starts
    @Then("log message successful payload validation and processing from Transformer component")
    public void LogMessageSuccessfulPayloadValidationAndProcessingFromTransformerComponent() {
        LOGGER.info("\n" + " ------------  Payload validation & processing successful from Transformer component -------------" + "\n");
    }


    @Then("log message successful payload validation and processing from Authorization component")
    public void LogMessageSuccessfulPayloadValidationAndProcessingFromAuthorizationComponent() {
        LOGGER.info("\n" + " ------------  Payload validation & processing successful from Authorizer component -------------" + "\n");
    }

    // ---- Added for Sprint S-21 US975787  ----- Ends
    //
    // ---- Added for Sprint S-21 US975788  ----- Starts
    @Then("log message Authorization Processing Error for Unauthorized Requester Airline")
    public void LogMessageAuthorizationProcessingErrorForUnauthorizedRequesterAirline() {
        LOGGER.info("\n" + " ------------  Authorization Processing Error for Unauthorized Requester Airline -------------" + "\n");
    }


    @Given("post agreement rules request {string} to {string} rule")
    public void postAgreementRulesRequestToRule(String payload, String ruleType) throws Exception {
        response = svcUtility.postRequest(payload, ruleType, null);
    }

    @And("create flight index using payload {string} to {string}")
    public void createFlightIndexUsingPayloadTo(String payload, String ruleType) throws Exception {
        response = svcUtility.postRequest(payload, ruleType, null);
    }

    @And("create seatmap using seatmapEP service FTS event with request {string} to {string}")
    public void createSeatmapUsingSeatmapEPServiceFTSEventWithRequestTo(String payload, String ruleType) throws Exception {
        response = svcUtility.postRequest(payload, ruleType, null);
    }


    @And("verify {string} as {string}")
    public void verifyAs(String key, String value) {
        assertionService.assertThat("verify " + key + "value in the reponse", jsonService.getValueWithPath(response.asString(), "status"), Matchers.is(value));
    }

    @And("verify {string} in errorMessage list as {string}")
    public void verifyInErrorMessageListAs(String key, String value) throws Exception {
        assertionService.assertThat("verify " + key + "in the response as " + value, jsonService.getValueWithPath(response.asString(), svcUtility.substituteValue("testData.errorMessages") + key), Matchers.is(value));
    }

    @Then("verify errorMessage {string}")
    public void verifyErrorMessage(String errMsg) {
        String actvlResult = response.getBody().asString();
        assertionService.assertThat("verify error message from response", actvlResult, Matchers.containsString(errMsg));
    }


    @And("verify {string} in errorMessage as {string}")
    public void verifyInErrorMessageAs(String key, String value) throws Exception {
        String flightList = jsonService.getValueWithPath(response.asString(), "flightList").toString();
        if (flightList.contains("errorMessages")) {

            assertionService.assertThat("verify error code from Auth", jsonService.getValueWithPath(flightList, svcUtility.substituteValue("testData.errorMessagesArray") + key), Matchers.is(value));


        }
    }

    @And("verify {string} in errorMessage sublist IATA as {string}")
    public void verifyInErrorMessageSublistIATAAs(String key, String value) throws Exception {
        assertionService.assertThat("verify " + key + "in the response as " + value, jsonService.getValueWithPath(response.asString(), svcUtility.substituteValue("testData.errorMessagesIATA") + key), Matchers.is(value));
    }

    @And("verify {string} in errorMessage sublist internal {string}")
    public void verifyInErrorMessageSublistInternal(String key, String value) throws Exception {
        assertionService.assertThat("verify " + key + "in the response as " + value, jsonService.getValueWithPath(response.asString(), svcUtility.substituteValue("testData.errorMessagesINTERNAL") + key), Matchers.is(value));
    }


    @Then("verify {string} as {string} in response")
    public void verifyAsInResponse(String key, String value) throws Exception {
        assertionService.assertThat("verify " + key + "in the response as " + value, jsonService.getValueWithPath(response.asString(), svcUtility.substituteValue("testData.finalSeatRes") + key), Matchers.is(value));
    }

    @Then("verify {string} value under flightSeatMaps as {string}")
    public void verifyValueUnderFlightSeatMapsAs(String key, String value) throws Exception {
        assertionService.assertThat("verify " + key + "in the response as " + value, jsonService.getValueWithPath(response.asString(), svcUtility.substituteValue("testData.flightSeatMapsRes") + key), Matchers.is(value));
    }

    @Then("verify following elements and its values in the response")
    public void verifyFollowingElementsAndItsValuesInTheResponse(List<Map<String, String>> list) {

        String resBody = response.getBody().asString();

        for (Map<String, String> row : list) {
            String key = row.get("KEY");
            String expvalue = row.get("VALUE");

            String actualvalue = jsonService.getValueWithPath(resBody, key);
            assertionService.assertThat("Verify correct value is there in the response", actualvalue, Matchers.containsString(expvalue));
        }
    }

    @When("Get health status of services")
    public void getHealthStatusOfServices() throws Exception {
        //get health status for all services
        response = svcUtility.getServiceCall("testData.getAllServicesHealthStatus");
    }

    @Then("verify health state for {string}")
    public void verifyHealthStateFor(String serviceName) {
        if (response.getStatusCode() != 200) {
            assertionService.assertThat("Orchestration service is down", response.getStatusCode(), Matchers.is(200));
        }
        String status = jsonService.getValueWithPath(response.asString(), "status");
        if (status.equals("UP")) {
            LOGGER.info("Health status for seatmap retrieval services looks good");
            assertionService.assertThat("Health Status for Seatmap Retrieval Modules is :" + status, status, Matchers.is("UP"));
        } else {
            String stateForService = jsonService.getValueWithPath(response.asString(), "component." + serviceName + ".status");
            assertionService.assertThat("Health state of " + serviceName + " is DOWN", stateForService, Matchers.is("UP"));
        }
    }


    @Then("verify list of restrictionIDs {string} and {string}")
    public void verifyListOfRestrictionIDsAnd(String id1, String id2) {
        Integer i1 = Integer.valueOf(id1);
        Integer i2 = Integer.valueOf(id2);

        String resBody = response.getBody().asString();

        JsonArray actualvalue = jsonService.getValueWithPath(resBody, "seatmapResponse.flightSeatmaps[0].seatmaps[0].cabins[0].seatRows[0].seats[*].passengerRestrictions[*]");

        List<Integer> actualList = new ArrayList<>();
        for (int i = 0; i < actualvalue.size(); i++) {
            actualList.add(Integer.valueOf(actualvalue.get(i).getAsString()));
        }
        List<Integer> expectedList = new ArrayList<>(Arrays.asList(i1, i2));


        System.out.println("Actual Value from response = " + actualList);
        System.out.println("Expected Value from response = " + expectedList);
        boolean actual = true;
        boolean expected = actualList.equals(expectedList);

        assertionService.assertThat(actual, Matchers.is(expected));


    }

    @Then("verify restrictionID {string}")
    public void verifyRestrictionID(String id1) {
        Integer i1 = Integer.valueOf(id1);

        String resBody = response.getBody().asString();

        JsonArray actualvalue = jsonService.getValueWithPath(resBody, "seatmapResponse.flightSeatmaps[0].seatmaps[0].cabins[0].seatRows[0].seats[*].passengerRestrictions[*]");

        List<Integer> actualList = new ArrayList<>();

        actualList.add(Integer.valueOf(actualvalue.get(0).getAsString()));

        List<Integer> expectedList = new ArrayList<>(Arrays.asList(i1));


        System.out.println("Actual Value from response = " + actualList);
        System.out.println("Expected Value from response = " + expectedList);
        boolean actual = true;
        boolean expected = actualList.equals(expectedList);

        assertionService.assertThat(actual, Matchers.is(expected));
    }


    @Given("get flight index using for flight {string} for particular date")
    public void getFlightIndexUsingForFlightForParticularDate(String flightNumber) throws Exception {
        response = svcUtility.getFlightIndex(flightNumber);
    }

    @And("delete {string} from DB with operational suffix as {string} for {string}")
    public void deleteFromDB(String docType, String operationalSuffix, String flightType) throws Exception {
        svcUtility.deleteTestSeatMaps(docType, operationalSuffix, flightType);
    }

    @And("verify {string} passenger with id {string} is added to passengerRestrictions if seat chars are {string}")
    public void verifyPassengerIdIsAddedToIfSeatCharsAre(String passengerType, String PassengerId, String chars) {
         String[] character = chars.split(",");

        List<SeatRowsInPosRS> seatsRows = posSeatmapResponse.getSeatmapResponse().getFlightSeatMaps().get(0).getSeatmaps().get(0).getCabins().get(0).getSeatRows();

        for(SeatRowsInPosRS seatRow : seatsRows){
            List<SeatsInPosRS> seats = seatRow.getSeats();
            for(SeatsInPosRS seat : seats) {
                List<CharacteristicsInPosRS> characteristicsInPosRS = seat.getCharacteristics();
                for (CharacteristicsInPosRS characteristicInPosResponse : characteristicsInPosRS) {
                    if (characteristicInPosResponse.getCodeContext().getValue().equalsIgnoreCase(SEATS_PADIS)) {
                        if (characteristicInPosResponse.getCodes().equals(Arrays.asList(character))) {
                            List<String> passengerId = seat.getPassengerRestrictions();
                            if(passengerType.equalsIgnoreCase("single")){
                                assertionService.assertThat(String.format("Verify passenger restrictions are applied with characteristics=%s",chars), passengerId.get(0), Matchers.is(PassengerId));
                            }else if(passengerType.equalsIgnoreCase("multiple")){
                               String[] passengerIdList = PassengerId.split(",");
                               assertionService.assertThat(String.format("Verify multiple passenger restrictions are applied with characteristics=%s",chars), passengerId, Matchers.is(Arrays.asList(passengerIdList)));
                            }else{
                                assertionService.assertThat(String.format("Verify passenger restrictions not applied with characteristics=%s",chars), passengerId, Matchers.is(Matchers.empty()));
                            }
                        }
                    }
                }
            }
        }
    }

    @And("verify {string} should be {string} if the seats having {string} characteristics")
    public void verifyShouldBeIfTheSeatsHavingCharacteristics(String key, String seatStatusValue, String seatChars) {
        String[] seatChar = seatChars.split(",");

        List<SeatRowsInPosRS> seatsRows = posSeatmapResponse.getSeatmapResponse().getFlightSeatMaps().get(0).getSeatmaps().get(0).getCabins().get(0).getSeatRows();

        for(SeatRowsInPosRS seatRow : seatsRows){
            List<SeatsInPosRS> seats = seatRow.getSeats();
            for(SeatsInPosRS seat : seats) {
                List<CharacteristicsInPosRS> characteristicsInPosRS = seat.getCharacteristics();
                for (CharacteristicsInPosRS characteristicsInPosRS1 : characteristicsInPosRS) {
                    if (characteristicsInPosRS1.getCodeContext().getValue().equalsIgnoreCase(SEATS_PADIS)) {
                        if (characteristicsInPosRS1.getCodes().equals(Arrays.asList(seatChar))) {
                            String seatStatus = seat.getSeatStatus();
                            assertionService.assertThat(String.format("Verify seat status changed to occupied with characteristics=%s",seatChars), seatStatus, Matchers.is(seatStatusValue));
                        }
                    }
                }
            }
        }
    }
}


