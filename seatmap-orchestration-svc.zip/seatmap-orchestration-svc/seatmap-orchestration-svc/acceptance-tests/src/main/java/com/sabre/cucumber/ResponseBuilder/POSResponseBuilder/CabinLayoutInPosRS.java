package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

import java.util.List;

@Data
public class CabinLayoutInPosRS {
    private String cabinCode;
    private String cabinNumber;
    private List<FacilityInPosRS> facilities;
    private String firstRow;
    private String cabinCodeDescription;
    private String lastRow;
    private Integer seatCount;
    private List<String> missingRowNumbers;
    private List<SeatAlphabetInPosRS> seatAlphabetList;
    private List<String> missingSeatList;
}
