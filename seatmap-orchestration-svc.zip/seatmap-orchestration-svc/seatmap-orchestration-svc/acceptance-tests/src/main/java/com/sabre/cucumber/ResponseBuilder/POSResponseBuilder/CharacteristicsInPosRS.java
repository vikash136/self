package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Data
public class CharacteristicsInPosRS {

    private CodeContextInPosRS codeContext ;
    private List<String> codes;

    public List<String> getCode() {
        if(CollectionUtils.isEmpty(codes)){
            this.codes = new ArrayList<>();
        }
        return this.codes;
    }
}
