package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

@Data
public class WarningMessageInPosRS {
    private String warningCode;
    private String descText;
    private String warningId;
    private String warningType;
}
