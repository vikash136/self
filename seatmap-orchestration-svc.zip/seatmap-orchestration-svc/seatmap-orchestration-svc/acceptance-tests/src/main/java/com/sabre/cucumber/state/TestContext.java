package com.sabre.cucumber.state;
import com.sabre.cucumberbase.state.BaseTestContext;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Data
public class TestContext {
    private Pattern pattern1 = Pattern.compile("TD\\.(\\w+\\d*)");
    private Pattern pattern2 = Pattern.compile("\\#\\{\\@(\\w+)\\}");
    private BaseTestContext baseTestContext;
    private List<String> testFlightsCreated;
    private List<String> seatMapsCreated;
    private boolean initialized = false;


    public TestContext(BaseTestContext baseTestContext) {
        this.baseTestContext = baseTestContext;
    }

    public void setup() {
        if (!initialized) {
            seatMapsCreated = new ArrayList<>();
            testFlightsCreated=new ArrayList<>();
            initialized = true;
        }
    }

    public List<String> getSeatMapsCreated() {
        return seatMapsCreated;
    }

    public List<String> getTestFlightsCreated()
    {
        return testFlightsCreated;
    }

}
