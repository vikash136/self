package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Data
public class LocationInPosRS {

    private String endRow;
    private List<String> columnPositions;
    private String orientation;
    private String beginRow;

    public List<String> getColumnPositions() {
        if (CollectionUtils.isEmpty(columnPositions)) {
            this.columnPositions = new ArrayList<>();
        }
        return this.columnPositions;
    }
}
