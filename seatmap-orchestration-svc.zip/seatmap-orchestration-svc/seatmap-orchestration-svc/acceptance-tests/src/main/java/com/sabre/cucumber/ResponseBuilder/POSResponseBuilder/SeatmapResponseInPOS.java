package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Data
public class SeatmapResponseInPOS {
    private String transactionId;
    private String requestDateTime;
    private String version;
    private String correlationId;
    private String supplierType;
    private String status;
    private List<WarningMessageInPosRS> warningMessages;
    private List<ErrorMessageInPosRS> errorMessages;
    private List<FlightSeatMapsInRS> flightSeatmaps;

    public List<WarningMessageInPosRS> getWarningMessages() {
        if (CollectionUtils.isEmpty(warningMessages)) {
            this.warningMessages = new ArrayList<>();
        }
        return warningMessages;
    }
    public List<ErrorMessageInPosRS> getErrorMessages() {
        if (CollectionUtils.isEmpty(errorMessages)) {
            this.errorMessages = new ArrayList<>();
        }
        return errorMessages;
    }
    public List<FlightSeatMapsInRS> getFlightSeatMaps() {
        if (CollectionUtils.isEmpty(flightSeatmaps)) {
            this.flightSeatmaps = new ArrayList<>();
        }
        return flightSeatmaps;
    }

}
