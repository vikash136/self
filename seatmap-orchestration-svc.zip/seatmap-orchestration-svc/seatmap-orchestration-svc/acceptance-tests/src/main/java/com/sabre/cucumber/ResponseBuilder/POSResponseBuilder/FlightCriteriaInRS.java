package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

@Data
public class FlightCriteriaInRS {
    private String airlineCode;
    private String arrivalAirportCode;
    private String departureAirportCode;
    private String flightNumber;
    //private String reservationBookingDesignator;
    private String scheduleDepartureDate;
    //private String operationalSuffix;
}
