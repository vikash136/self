package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Data
public class FlightSeatMapsInRS {
    private FlightCriteriaInRS flightInfo;
    private List<FlightLegInPosRS> seatmaps;
    private List<WarningMessageInPosRS> warningMessages;
    private List<ErrorMessageInPosRS> errorMessages;

    public List<WarningMessageInPosRS> getWarningMessages() {
        if (CollectionUtils.isEmpty(warningMessages)) {
            this.warningMessages = new ArrayList<>();
        }
        return warningMessages;
    }
    public List<ErrorMessageInPosRS> getErrorMessages() {
        if (CollectionUtils.isEmpty(errorMessages)) {
            this.errorMessages = new ArrayList<>();
        }
        return errorMessages;
    }
}
