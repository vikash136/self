package com.sabre.cucumber.ResponseBuilder.POSResponseBuilder;

import lombok.Data;

@Data
public class SeatAlphabetInPosRS {
    private String columnCode ;
    private String position;
}
